<?php
include 'functions.php';
db_connect();
mysql_query("UPDATE users set time=1230771661;");
db_close();
//1230771661
?>