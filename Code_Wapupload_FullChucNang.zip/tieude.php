<?php
include 'config.php';
//$tieude = "Trang chủ";
echo '<title>';
echo "$tieude | $tenwap
</title>";
?>