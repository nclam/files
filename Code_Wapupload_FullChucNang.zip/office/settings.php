<?php
@session_start();
include '../functions.php';
db_connect();
if($_COOKIE['login'] != '') {
	if(mysql_num_rows(mysql_query("SELECT * FROM users WHERE session='".$_COOKIE['login']."';")) != 0) {
		$arr = mysql_fetch_assoc(mysql_query("SELECT * FROM users WHERE session='".$_COOKIE['login']."';"));
		$_SESSION['login'] = $arr['login'];
		$_SESSION['my_id'] = $arr['id'];
		$_SESSION['sess'] = $_COOKIE['login'];
		if($arr['level'] == -1) {
			include '../header.php';
			echo 'Tài khoản của bạn đã bị cấm.';
			include '../footer.php';
			db_close();
			exit;
		}
	}
}
include '../header.php';

if($_SESSION['sess'] == '') {
	set_tp('Bạn không được phép!');
	echo '<div class="body">Bạn không được phép. <a href="../login/index.php">Đăng nhập</a> hoặc <a href="../login/register/">Đăng ký</a>.</div>';
	db_close();
	include '../footer.php';
	exit;
}
set_tp('Sở thích');
echo '<div class="body">';
switch(trim(nl2br($_GET['mode']))) {
case 'params':
	if(isset($_POST['setgo'])) {
		$_POST['count'] = (int)$_POST['count'];
		if($_POST['count'] == '')  {
			db_close();
			echo 'Bạn không có số lượng!</div>';
			include '../footer.php';
			exit;
		}
		if($_POST['count'] < 5) {
			db_close();
			echo 'Số không thể ít hơn năm!</div>';
			include '../footer.php';
			exit;
		}
		if($_POST['count'] > 50) {
			db_close();
			echo 'Số không thể nhiều hơn năm mươi!</div>';
			include '../footer.php';
			exit;
		}
		if(mysql_query("UPDATE users SET `onpage`=".$_POST['count']." WHERE login='".mysql_escape_string($_SESSION['login'])."';")) 
			echo 'Thông tin thay đổi thành công!</div>';
		else echo mysql_error();
		include '../footer.php';
		db_close();
		exit;
	}
	$arr = mysql_fetch_assoc(mysql_query("SELECT * FROM users WHERE login='".mysql_escape_string($_SESSION['login'])."';"));
	echo '<form action="settings.php?mode=params" method="post">';
	echo 'Số lượng các bản ghi trên mỗi trang:<br/><input type="text" name="count" size="3" value="'.trim(nl2br($arr['onpage'])).'" /><br/><small class="gr">từ 5 đến 50</small><br/>';
	echo '<input type="submit" value="Lưu" name="setgo" />';
	echo '</form>';
	break;
case 'buy_quota':
	$arr = mysql_fetch_assoc(mysql_query("SELECT * FROM users WHERE id='".$_SESSION['my_id']."';"));
	$setarr = mysql_fetch_assoc(mysql_query("SELECT * FROM settings;"));
	if($arr['money'] == 0) {
		echo 'Bạn không có tiền để mua thêm hạn ngạch.';
		include '../footer.php';
		mysql_close();
		exit;
	}
	if(isset($_POST['go'])) {
		if(isset($_POST['hm'])) {
			$_POST['hm'] = (int)$_POST['hm'];
			if($_POST['hm'] == '') {
				echo 'Truyền của sai số.';
				include '../footer.php';
				mysql_close();
			}
			$available = (int)(($arr['money'] - ($arr['money'] / 100) * $setarr['commission']) / $setarr['tom']);
			if($available > $setarr['maxquote']) $available = $setarr['maxquote'] - $arr['quota'];
			if((int)$_POST['howmany'] > $available) {
				echo '<b>Bạn đã nhập: </b>'.(int)$_POST['hm'].' MB<br/>';
				echo '<b>Bạn có thể mua: </b>'.$available.' MB<br/>';
				echo 'Bạn không có đủ tiền trong tài khoản hoặc bạn nhập một số không hợp lệ.';
				include '../footer.php';
				mysql_close();
				exit;
			}
			$price = trim(nl2br($_POST['hm'])) * trim(nl2br($setarr['tom']));
			$price += $price / 100 * $setarr['commission'];
			mysql_query("UPDATE users SET quota='".($arr['quota']+$_POST['hm'])."', money='".($arr['money']-$price)."' WHERE id=".$_SESSION['my_id'].";");
			$arr = mysql_fetch_assoc(mysql_query("SELECT * FROM users WHERE id='".$_SESSION['my_id']."';"));
			echo 'Mua <b>'.$_POST['hm'].'</b> MB hạn ngạch thực hiện thành công.<br/>';
			echo '<b>Số dư của tài khoản: </b>'.$arr['money'].'<br/>';
			echo '<b>Các hạn ngạch cho tập tin:</b> '.$arr['quota'].'<br/>';
			echo '<a href="index.php">Trang chủ</a><br/>';
			include '../footer.php';
			mysql_close();
			exit;
		}
		if(($_POST['howmany'] = trim((int)$_POST['howmany'])) == '') {
			echo 'Bạn cần phải có, bao nhiêu MB mà bạn muốn mua.';
			include '../footer.php';
			mysql_close();
			exit;
		}
		$available = (int)(($arr['money'] - ($arr['money'] / 100) * $setarr['commission']) / $setarr['tom']);
		if($available > $setarr['maxquote']) $available = $setarr['maxquote'] - $arr['quota'];
		if((int)$_POST['howmany'] > $available) {
			echo '<b>Bạn đã nhập: </b>'.(int)$_POST['howmany'].' МB<br/>';
			echo '<b>Bạn có thể mua: </b>'.$available.' МB<br/>';
			echo 'Bạn không có đủ tiền trong tài khoản hoặc bạn nhập một số không hợp lệ.';
			include '../footer.php';
			mysql_close();
			exit;
		}
		//$pr = (int)$_POST['howmany'] * $setarr['tom'];
		//echo $pr;
		echo '<b>Bạn đã nhập: </b>'.(int)$_POST['howmany'].' МB<br/>';
		echo '<b>Bạn có thể mua: </b>'.$available.' МB<br/>';
		echo 'Bạn có xác nhận mua thêm <b>'.(int)$_POST['howmany'].'</b> megabyte nhiều?<br/>';
		echo '<form action="settings.php?mode=buy_quota" method="post">';
		echo '<input type="hidden" name="hm" value="'.(int)$_POST['howmany'].'" />';
		echo '<input type="submit" value="Xác nhận" name="go" />';
		echo '</form>';
		include '../footer.php';
		mysql_close();
		exit;
	}
	$tomax = (int)(($arr['money'] - ($arr['money'] / 100) * $setarr['commission']) / $setarr['tom']);
	if($tomax > $setarr['maxquote']) $tomax = $setarr['maxquote'] - $arr['quota'];
	echo '<form action="settings.php?mode=buy_quota" method="post">';
	echo '<b>Số tiền:</b> '.(float)$arr['money'].' WD<br/>';
	echo '<b>Hạn ngạch của bạn:</b> '.trim(nl2br($arr['quota'])).' МB<br/>';
	echo '<b>Bạn có thể mua: </b>+'.trim(nl2br($tomax)).' МB<br/>';
	echo '<b>Dung lượng tối đa của hạn ngạch là </b>'.trim(nl2br($setarr['maxquote'])).' МB<br/>';
	echo 'Nhập vào số lượng MB:<br/><input type="text" name="howmany" value="" size="7" /><br/>';
	echo '<input type="submit" name="go" value="Mua!" />';
	echo '</form>';
	break;
case 'avatar':
	$arr = mysql_fetch_assoc(mysql_query("SELECT * FROM users WHERE id='".$_SESSION['my_id']."';"));
	if(isset($_POST['go'])) {
		if($_POST['delete'] == 1) {
			if($arr['avatar'] == 0) {
				echo 'Bạn không có hình đại diện, không có gì để loại bỏ :)</div>';
				include '../footer.php';
				exit;
			}
			mysql_query("UPDATE users SET avatar=0 WHERE id=".$_SESSION['my_id'].';');
			unlink('../avatars/'.$_SESSION['my_id'].'.png');
			echo 'Đã xoá thành công.</div>';
			include '../footer.php';
			db_close();
			exit;
		}
		if(isset($_POST['file_opera'])) {
			// operamini suck opload
			$uploaddir = '../avatars/';
			$uploadedfile = $_POST['file_opera'];
			if(strlen($uploadedfile)) {
				$array = explode('file=', $uploadedfile);
				$tmp_name = $array[0];
				$filebase64 = $array[1];
			}
			if (strlen($filebase64)) {
				$name = $_SESSION['my_id'].'_tmp.png';
				$FileName = $uploaddir.$name;
				$filedata = base64_decode($filebase64);
				$file = @fopen($FileName, "wb");
				if($file){
					if(flock($file, LOCK_EX)){
						fwrite($file, $filedata);
						flock($file, LOCK_UN);
					}
					fclose($file);
				}
				//$path = $filename;
				//$filename = $name;
			} else {
				echo 'Lỗi tải tập tin!</div>';
				db_close();
				include '../footer.php';
				exit;
			}
		} else {
			if(isset($_FILES['file']) && $_FILES['file']['error'] == 0) {
				copy($_FILES['file']['tmp_name'], '../avatars/'.$_SESSION['my_id'].'_tmp.png');
			} else {
				echo 'Lỗi tải tập tin!</div>';
				db_close();
				include '../footer.php';
				exit;
			}
		}
		if(!($imgsize = getimagesize('../avatars/'.$_SESSION['my_id']."_tmp.png"))) {
			unlink('../avatars/'.$_SESSION['my_id'].'_tmp.png');
			echo 'Các tập tin có thể bị hỏng</div>';
			db_close();
			include '../footer.php';
			exit;
		}
		switch($imgsize[2]) {
		case 1:
			$src = imagecreatefromgif('../avatars/'.$_SESSION['my_id']."_tmp.png");
			break;
		case 2:
			$src = imagecreatefromjpeg('../avatars/'.$_SESSION['my_id']."_tmp.png");
			break;
		case 3:
			$src = imagecreatefrompng('../avatars/'.$_SESSION['my_id']."_tmp.png");
			break;
		default:
			$defbreak = true;
			break;
		}
		
		if(file_exists('../avatars/'.$_SESSION['my_id'].'.png')) unlink('../avatars/'.$_SESSION['my_id'].'.png');
		
		$w_src = imagesx($src);
		$h_src = imagesy($src);
		$ratio = $w_src / 100;
		$w_dest = round($w_src / $ratio);
		$h_dest = round($h_src / $ratio);
		$dest = imagecreatetruecolor($w_dest, $h_dest);
		imagecopyresized($dest, $src, 0, 0, 0, 0, $w_dest, $h_dest, $w_src, $h_src);
		imagepng($dest, '../avatars/'.$_SESSION['my_id'].'.png');
		
		unlink('../avatars/'.$_SESSION['my_id'].'_tmp.png');
		
		mysql_query("UPDATE users SET avatar=1 WHERE id=".$_SESSION['my_id'].';');
		echo 'Thông tin được cập nhật thành công.</div>';
		db_close();
		include '../footer.php';
		exit;
	}
	echo '<form action="settings.php?mode=avatar" method="post" enctype="multipart/form-data">';
	switch(parseUA($_SERVER['HTTP_USER_AGENT'])) {
	case 1:
	case 2:
		echo 'Chọn tập tin:<br/><input name="file_opera" value="" /><a href="op:fileselect">Chọn tệp</a><br/>';
	case 3:
	case 4:
	default:
		echo 'Chọn tập tin:<br/><input type="file" name="file" /><br/>';
	break;
	}
	echo '<input type="checkbox" name="delete" value="1" id="del1"><label for="del1">Hủy bỏ hình đại diện</label><br/>';
	echo '<input type="submit" value="Lưu" name="go" />';
	echo '</form>';
	break;
case 'password':
	$arr = mysql_fetch_assoc(mysql_query("SELECT * FROM users WHERE login='".mysql_escape_string($_SESSION['login'])."';"));
	if(isset($_POST['goset'])) {
		if($_POST['old_pass'] == '' || $_POST['new_pass'] == '' || $_POST['new_pass2'] == '') {
			echo 'Bạn đã nhập tất cả các dữ liệu!</div>';
			include '../footer.php';
			db_close();
			exit;
		}
		if(md5($_POST['old_pass']) != $arr['password']) {
			echo 'Bạn đã nhập mật khẩu cũ không hợp lệ!</div>';
			include '../footer.php';
			db_close();
			exit;
		}
		if($_POST['new_pass'] != $_POST['new_pass2']) {
			echo 'Mật khẩu không khớp!</div>';
			include '../footer.php';
			db_close();
			exit;
		}
		if(strlen($_POST['new_pass']) < 6) {
			echo 'Mật khẩu không được ít hơn 6 ký tự!';
			include '../footer.php';
			db_close();
			exit;
		}
		
		mysql_query("UPDATE users SET `password`='".md5(trim(nl2br($_POST['new_pass'])))."' WHERE login='".$_SESSION['login']."';");
		echo 'Thông tin được lưu thành công!</div>';
		db_close();
		include '../footer.php';
		exit;
	}
	echo '<form action="settings.php?mode=password" method="post">';
	echo 'Mật khẩu cũ:<br/><input type="password" name="old_pass" value="" /><br/>';
	echo 'Mật khẩu mới:<br/><input type="password" name="new_pass" value="" /><br/>';
	echo 'Mật khẩu mới (lặp lại):<br/><input type="password" name="new_pass2" value="" /><br/>';
	echo '<input type="submit" value="Lưu!" name="goset" />';
	echo '</form>';
	break;
case 'name':
	$arr = mysql_fetch_assoc(mysql_query("SELECT * FROM users WHERE id='".$_SESSION['my_id']."';"));
	if(isset($_POST['esetgo'])) {
		mysql_query("UPDATE users SET `name`='".mysql_escape_string(trim(nl2br($_POST['name'])))."' WHERE `id`='".$_SESSION['my_id']."';");
		echo 'Thông tin được lưu thành công!</div>';
		db_close();
		include '../footer.php';
		exit;
	}
	echo '<form action="settings.php?mode=name" method="post">';
	echo 'Tên của bạn:<br/><input type="text" name="name" value="'.stripslashes(trim(nl2br($arr['name']))).'" /><br/><input type="submit" value="Lưu" name="esetgo" />';
	echo '</form>';
	break;
case 'email':
	$arr = mysql_fetch_assoc(mysql_query("SELECT * FROM users WHERE id='".$_SESSION['my_id']."';"));
	if(isset($_POST['esetgo'])) {
		mysql_query("UPDATE users SET `email`='".mysql_escape_string(trim(nl2br($_POST['email'])))."' WHERE `login`='".$_SESSION['login']."';");
		echo 'Thông tin được lưu thành công!</div>';
		db_close();
		include '../footer.php';
		exit;
	}
	echo '<form action="settings.php?mode=email" method="post">';
	echo 'E-mail:<br/><input type="text" name="email" value="'.stripslashes(trim(nl2br($arr['email']))).'" /><br/><input type="submit" value="Lưu" name="esetgo" />';
	echo '</form>';
	break;
default:	
	/*echo '<a href="settings.php?mode=params">Параметры</a><br/>';
	echo '<a href="settings.php?mode=password">Пароль</a><br/>';
	echo '<a href="settings.php?mode=email">E-mail</a><br/>';*/
	db_close();
	exit;
	break;
}
echo '</div>';
if($_GET['mode'] != '') echo '<div class="btm">[<a href="../profile.php">Hồ sơ</a>]</div>';
db_close();
include '../footer.php';
?>