<?php 
@session_start();
include 'functions.php';
db_connect();
if($_COOKIE['login'] != '') {
	if(mysql_num_rows(mysql_query("SELECT * FROM users WHERE session='".$_COOKIE['login']."';")) != 0) {
		$arr = mysql_fetch_assoc(mysql_query("SELECT * FROM users WHERE session='".$_COOKIE['login']."';"));
		$_SESSION['login'] = $arr['login'];
		$_SESSION['my_id'] = $arr['id'];
		$_SESSION['sess'] = $_COOKIE['login'];
		if($arr['level'] == -1) {
			include 'header.php';
			echo 'Tài khoản của bạn đã bị cấm.';
			include 'footer.php';
			db_close();
			exit;
	
		}
	}
}
if(isset($_GET['exit'])) {
	if($_SESSION['sess'] == '') {
		db_close();
		header('Location: index.php');
		exit;
	}
	mysql_query("UPDATE users SET session='' WHERE login='".mysql_escape_string($_SESSION['login'])."';");
	db_close();
	unset($_SESSION['sess']);
	unset($_SESSION['login']);
	unset($_SESSION['my_id']);
	setcookie('login', '');
	header('Location: index.php');
	@session_destroy();
	exit;
}
include 'header.php';

Error_Reporting(0);

$ua=$_SERVER['HTTP_USER_AGENT']; //браузер 

$ip=$_SERVER['REMOTE_ADDR']; //ip 

$referer=$_SERVER['HTTP_REFERER'];///рефер

$dat=date("d/M/Y|H:i:s");///дата, время

$logfile=('log/log.dat'); //файл-хранилище, права 666 и выше(логи с HTML кодом)

$logfile2=('log/log2.dat'); //файл-хранилище, права 666 и выше(только логи)

$f=fopen($logfile,'a+'); //создаем/открываем 

flock($f,2); //блокируем 

fwrite($f,$all); //записываем

fclose($f); //закрываем (блокировка снимется сама)

$logal="[$ip]";

$logal.="[$dat]";

$logal.="[$ua]";

$logal.="[$referer]

";

$f=fopen($logfile2,'a+'); //создаем/открываем 

flock($f,2); //блокируем 

fwrite($f,$logal); //записываем

fclose($f); //закрываем (блокировка снимется сама)









  //////////////////////////////////////////////////////////////////////////////

 //////////////////счетчик    /////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////////////////

$ua2=$_SERVER['HTTP_USER_AGENT']; //браузер 

$ip2=$_SERVER['REMOTE_ADDR']; //ip 

$uniq=serialize(array($ip2,$ua2))."\n"; //упакованные данные

$store=('log/counter.dat'); //файл-хранилище, права 666 и выше

$offset=0*3600; //смещение по времени в секундах 

$date_now=date('d',time()+$offset); //сегодняшнее число 

$date_access=date('d',filemtime($store)+$offset); //время последней модификации файла

if ($date_now!=$date_access && file_exists($store)) 

{ unlink($store);//если даты не совпадают, то пора обнулить счетчик, удаляем файл (для директории надо выставить права 766)  

} 

if (!file_exists($store)) 

{ $hit=1; $host=1; //если файла данных не существует 

} 

else 

{$data=file($store); //получаем стоки из файла 

$data[]=$uniq; //добавляем к данным текущего юзера 

$hit=count($data); //сколько строк, столько и хитов 

$ip_ua=array();//считаем хосты  

$ip_ua[]=$uniq; //запихиваем текущего юзера 

foreach ($data as $v) 

{ if (!in_array($v,$ip_ua)) //если такой комбинации нет, то 

$ip_ua[]=$v; //увеличиваем уникальные записи 

} $host=count($ip_ua); //число уникальных строк 

}

$f=fopen($store,'a+'); //создаем/открываем 

flock($f,2); //блокируем 

fwrite($f,$uniq); //записываем упакованный массив 

fclose($f); //закрываем (блокировка снимется сама)

  //////////////////////////////////////////////////////////////////////////////////////////////////

 ///для того что бы скрипт выводил на страницу информацию о логах - раскомментируйте текст ниже:)//

//////////////////////////////////////////////////////////////////////////////////////////////////



$filerazmer=filesize('log/log2.dat');

$vsego='25';

$file=file('log/log.dat');

if (!file_exists('log/log.dat') or count($file)=='0')

{echo 'Пусто!<br/>';}

else {

if (empty($page))

{

$page=1;

}

$obsum=$page*$vsego;

$nasum=$obsum-$vsego;



for($i=$nasum; $i<$obsum; $i++)

{

if(isset($file[$i])) 

{

echo $file[$i]; //Вывод содержимого строки, в цикле

}

}

if (count($file)<=$i)

{

$endd=1;

}

$page_count=ceil(count($file)/$vsego);

if ($page==1 && $endd==1)else{

if ($page==1){}else{echo '<a href="?page='.($page-1).'">&lt;&lt;&lt; Назад</a>';}

if ($endd==1){echo '<br/>';}else{echo '<a href="?page='.($page+1).'">Далее &gt;&gt;&gt;</a><br/>';}

if ($page_count>2){

echo 'Выбор страницы (1-'.$page_count.'):<br/>

<form action="" method="get">

<input "'.$page.'">

<input type="submit" value="перейти"></form>';}}}

echo 'Хосты:'.$host.'<br/>Хиты:'.$hit.'<br/>Всего записей в log файле:'.count($file).'<br/>Размер файла:'.$filerazmer.' байт<br/>';
include "footer.php";

?>

