<?php
function repln($text) {
	return str_replace("\n", "<br/>", $text);
}
function showLP1($pages, $p)
{
	if ($pages <= 7) {
	for($i = 1; $i <= $pages; $i++) {
		if ($i == $_GET['page']) echo '<b>' . $i . "</b>";
		else
		echo '<a href="privat.php?'.$p.'&page=' . $i . '">' . $i . '</a>';
		if ($i != $pages) echo ',';
	} 
	} else {
	if ($_GET['page'] <= 2 || $_GET['page'] >= $pages-2) {
		if ($_GET['page'] == 1 || $_GET['page'] == $pages) {
		for($i = 1; $i <= 2; $i++) {
			if ($i == $_GET['page']) echo '<b>' . $i . '</b>';
			else
			echo '<a href="privat.php?'.$p.'&page=' . $i . '">' . $i . '</a>';
			if ($i != 2) echo ',';
		} 
		echo '..';
		for($i = $pages - 1; $i <= $pages; $i++) {
			if ($i == $_GET['page']) echo '<b>' . $i . '</b>';
			else
			echo '<a href="privat.php?'.$p.'&page=' . $i . '">' . $i . '</a>';
			if ($i != $pages) echo ',';
		} 
		} else {
		if ($_GET['page'] <= 2) {
			for($i = 1; $i <= $_GET['page'] + 1; $i++) {
			if ($i == $_GET['page']) echo '<b>' . $i . '</b>';
			else
				echo '<a href="privat.php?'.$p.'&page=' . $i . '">' . $i . '</a>';
			if ($i != $_GET['page'] + 1) echo ',';
			} 
			echo '..';
			for($i = $pages - 1; $i <= $pages; $i++) {
			if ($i == $_GET['page']) echo '<b>' . $i . '</b>';
			else
				echo '<a href="privat.php?'.$p.'&page=' . $i . '">' . $i . '</a>';
			if ($i != $pages) echo ',';
			} 
		} else {
			for($i = 1; $i <= 2; $i++) {
			if ($i == $_GET['page']) echo '<b>' . $i . '</b>';
			else
				echo '<a href="privat.php?'.$p.'&page=' . $i . '">' . $i . '</a>';
			if ($i != $_GET['page'] + 1) echo ',';
			} 
			echo '..';
			for($i = $_GET['page'] - 1; $i <= $pages; $i++) {
			if ($i == $_GET['page']) echo '<b>' . $i . '</b>';
			else
				echo '<a href="privat.php?'.$p.'&page=' . $i . '">' . $i . '</a>';
			if ($i != $pages) echo ',';
			} 
		} 
		} 
	} else {
		$i = 1;
		if ($_GET['page'] - 2 == 1) $p = ',';
		else $p = '..';
		echo '<a href="privat.php?'.$p.'&page=' . $i . '">' . $i . '</a>' . $p; 
		
		for($i = $_GET['page']-1; $i <= $_GET['page'] + 1; $i++) {
		if ($i == $_GET['page']) echo '<b>' . $i . '</b>';
		else
			echo '<a href="privat.php?'.$p.'&page=' . $i . '">' . $i . '</a>';
		if ($i != $_GET['page'] + 1) echo ',';
		} 
		echo '..'; 
		
		$i = $pages;
		echo '<a href="privat.php?'.$p.'&page=' . $i . '">' . $i . '</a>';
	} 
	} 
}
if(isset($_POST['delno'])) {
	header("Location: privat.php");
	exit;
}
if(isset($_POST['nogo'])) {
	header("Location: privat.php?newmsg");
	exit;
}
@session_start();
include 'functions.php';
db_connect();
if($_COOKIE['login'] != '') {
	if(mysql_num_rows(mysql_query("SELECT * FROM users WHERE session='".$_COOKIE['login']."';")) != 0) {
		$arr = mysql_fetch_assoc(mysql_query("SELECT * FROM users WHERE session='".$_COOKIE['login']."';"));
		$_SESSION['login'] = $arr['login'];
		$_SESSION['my_id'] = $arr['id'];
		$_SESSION['sess'] = $_COOKIE['login'];
		if($arr['level'] == -1) {
			include 'header.php';
			echo 'Tài khoản của bạn đã bị cấm.';
			include 'footer.php';
			db_close();
			exit;
		}
	}
}

include 'header.php';

if($_SESSION['sess'] == '') {
	set_tp('Bạn không được phép!');
	echo '<div class="body">Bạn không được phép. <a href="../login/index.php">Đăng nhập</a> hoặc <a href="../login/register/">Đăng ký</a>.</div>';
	db_close();
	include 'footer.php';
	exit;
}if($_GET['msg'] != '') {
	set_tp('Hòm thư cá nhân');
	$_GET['msg'] = (int)$_GET['msg'];
	if($_GET['msg'] == '') {
		echo '<div class="body">Неверный ID сообщения.</div>';
		include "footer.php";
		exit;
	}
	$arr = mysql_fetch_assoc(mysql_query("SELECT * FROM `privmsg` WHERE `id`=".$_GET['msg']." AND (`status`=0 OR `status`=1 OR `status`=2);"));
	if(mysql_num_rows(mysql_query("SELECT * FROM `privmsg` WHERE `id`=".$_GET['msg']." AND `status`=3;")) == 0 || $arr['to'] != $_SESSION['my_id']) {
		echo '<div class="body">Неверный ID сообщения.</div>';
		db_close();
		include "footer.php";
		exit;
	}
	// show msg here...
	$arr = mysql_fetch_assoc(mysql_query("SELECT * FROM `privmsg` WHERE `id`=".$_GET['msg']." AND (`status`=0 OR `status`=1 OR `status`=2);"));
	if($arr['status'] == 0 || $arr['status'] == 1) {

		mysql_query("UPDATE `privmsg` SET `status`=2 WHERE `id`=".$arr['id']." AND (`status`=0 OR `status`=1 OR `status`=2);");
	}
	$months = array (
		1 => "января",
		2 => "февраля",
		3 => "марта",
		4 => "апреля",
		5 => "мая",
		6 => "июня",
		7 => "июля",
		8 => "августа",
		9 => "сентября",
		10 => "октября",
		11 => "ноября",
		12 => "декабря"
	);
	$af = mysql_fetch_assoc(mysql_query("SELECT * FROM users WHERE id=".$arr['from'].';'));
	echo '<div class="body"><b>От</b>: <a href="profile.php?u='.$arr['from'].'">'.htmlspecialchars(stripslashes($af['login'])).'</a><br/>';
	echo '<b>Тема</b>: '.htmlspecialchars(stripslashes($arr['subject'])).'<br/>';
	echo '<b>Отправлено</b>: '.date("d", $arr['time'])." ".$months[date("m", $arr['time'])]." ".date("Y", $arr['time'])." г., ".date("H:i:s", $arr['time'])."<br/>";
	echo '<b>Текст: </b>'.htmlspecialchars(stripslashes(repln($arr['text']))).'<hr/>';
	echo '<a href="privat.php?newmsg&ansto='.$arr['id'].'">Ответить</a><br/>';
	echo '<a href="privat.php?del='.$arr['id'].'">Удалить</a><br/></div>';	
	include "footer.php";
	exit;
}
if($_GET['outmsg'] != '') {
	set_tp('Hộp thư đi');
	$_GET['outmsg'] = (int)$_GET['outmsg'];
	if($_GET['outmsg'] == '') {
		echo '<div class="body">Неверный ID сообщения.</div>';
		include "footer.php";
		exit;
	}
	
	$arr = @mysql_fetch_assoc(mysql_query("SELECT * FROM `privmsg` WHERE `id`=".$_GET['outmsg']." AND `status`=3;"));
	if($arr['from'] != $_SESSION['my_id'] || mysql_num_rows(mysql_query("SELECT * FROM `privmsg` WHERE `id`=".$_GET['outmsg']." AND `status`=3;")) == 0) {
		echo '<div class="body">Неверный ID сообщения.</div>';
		db_close();
		include "footer.php";
		exit;
	}
	// show msg here...
	$months = array (
		1 => "января",
		2 => "февраля",
		3 => "марта",
		4 => "апреля",
		5 => "мая",
		6 => "июня",
		7 => "июля",
		8 => "августа",
		9 => "сентября",
		10 => "октября",
		11 => "ноября",
		12 => "декабря"
	);
	$uarr = mysql_fetch_assoc(mysql_query("SELECT * FROM users WHERE id=".$arr['to'].";"));
	$arr = mysql_fetch_assoc(mysql_query("SELECT * FROM `privmsg` WHERE `id`=".$_GET['outmsg']." AND `status`=3;"));
	echo '<div class="body"><b>К</b>: <a href="profile.php?u='.$arr['to'].'">'.htmlspecialchars(stripslashes($uarr['login'])).'</a><br/>';
	echo '<b>Тема</b>: '.htmlspecialchars(stripslashes($arr['subject'])).'<br/>';
	echo '<b>Отправлено</b>: '.date("d", $arr['time'])." ".$months[date("m", $arr['time'])]." ".date("Y", $arr['time'])." г., ".date("H:i:s", $arr['time'])."<br/>";
	echo '<b>Текст: </b>'.htmlspecialchars(stripslashes(repln($arr['text'])))."<hr/>";
	echo '<a href="privat.php?delout='.$arr['id'].'">Удалить</a><br/></div>';	
	include "footer.php";
	exit;
}
if(isset($_GET['del'])) {
	set_tp('Hòm thư cá nhân');
	if(isset($_POST['delyes'])) {
		$_GET['del'] = (int)$_GET['del'];
		if($_GET['del'] == '') {
			echo '<div class="body">Неверный ID.</div>';
			include "footer.php";
			exit;
		}
		$arr = mysql_fetch_assoc(mysql_query("SELECT * FROM `privmsg` WHERE `id`=".$_GET['del']." AND (`status`=0 OR `status`=1 OR `status`=2);"));
		if(mysql_num_rows(mysql_query("SELECT * FROM `privmsg` WHERE `id`=".$_GET['del']." AND (`status`=0 OR `status`=1 OR `status`=2);")) == 0 || $arr['to'] != $_SESSION['my_id']) {
			echo '<div class="body">Неверный ID сообщения.</div>';
			db_close();
			include "footer.php";
			exit;
		}
		if(mysql_query("DELETE FROM `privmsg` WHERE `id`=".$_GET['del']." AND (`status`=0 OR `status`=1 OR `status`=2);")) {
			mysql_query("OPTIMIZE TABLE `privmsg`;");
			echo "<div class=\"body\">Сообщение успешно удалено.</div>";
		} else echo "MySQL Error: ".mysql_error();
		db_close();
		include "footer.php";
		exit;
	}
	$_GET['del'] = (int)$_GET['del'];
	if($_GET['del'] == '') {
		echo '<div class="body">Неверный ID.</div>';
		include "footer.php";
		exit;
	}
	
	$arr = mysql_fetch_assoc(mysql_query("SELECT * FROM `privmsg` WHERE `id`=".$_GET['del']." AND (`status`=0 OR `status`=1 OR `status`=2);"));
	if(mysql_num_rows(mysql_query("SELECT * FROM `privmsg` WHERE `id`=".$_GET['del']." AND (`status`=0 OR `status`=1 OR `status`=2);")) == 0 || $arr['to'] != $_SESSION['my_id']) {
		echo '<div class="body">Неверный ID сообщения.</div>';
		db_close();
		include "footer.php";
		exit;
	}
	echo '<div class="body"><form action="privat.php?del='.$_GET['del'].'" method="post">';
	echo 'Вы действительно хотите удалить сообщение?<br/><input type="submit" value="Да" name="delyes" class="input_but"> <input type="submit" value="Нет" name="delno" class="input_but"></form></div>';
	db_close();
	include "footer.php";
	exit;
}
if(isset($_GET['delout'])) {
	set_tp('Hòm thư cá nhân');
	if(isset($_POST['delyes'])) {
		$_GET['delout'] = (int)$_GET['delout'];
		if($_GET['delout'] == '') {
			echo '<div class="body">Неверный ID.</div>';
			include "footer.php";
			exit;
		}
		$arr = mysql_fetch_assoc(mysql_query("SELECT * FROM `privmsg` WHERE `id`=".$_GET['delout']." AND `status`=3;"));
		if(mysql_num_rows(mysql_query("SELECT * FROM `privmsg` WHERE `id`=".$_GET['delout']." AND `status`=3;")) == 0 || $arr['from'] != $_SESSION['my_id']) {
			echo '<div class="body">Неверный ID сообщения.</div>';
			db_close();
			include "footer.php";
			exit;
		}
		if(mysql_query("DELETE FROM `privmsg` WHERE `id`=".$_GET['delout']." AND `status`=3;")) {
			mysql_query("OPTIMIZE TABLE `privmsg`;");
			echo "<div class=\"body\">Сообщение успешно удалено.</div>";
		}
			else echo "Database error!";
		db_close();
		include "footer.php";
		exit;
	}
	$_GET['delout'] = (int)$_GET['delout'];
	if($_GET['delout'] == '') {
		echo '<div class="body">Неверный ID.</div>';
		include "footer.php";
		exit;
	}
	
	$arr = mysql_fetch_assoc(mysql_query("SELECT * FROM `privmsg` WHERE `id`=".$_GET['delout']." AND `status`=3;"));
	if(mysql_num_rows(mysql_query("SELECT * FROM `privmsg` WHERE `id`=".$_GET['delout']." AND `status`=3;")) == 0 || $arr['from'] != $_SESSION['my_id']) {
		echo '<div class="body">Неверный ID сообщения.</div>';
		db_close();
		include "footer.php";
		exit;
	}
	echo '<div class="body"><form action="privat.php?delout='.$_GET['delout'].'" method="post">';
	echo 'Вы действительно хотите удалить сообщение?<br/><input type="submit" value="Да" name="delyes" class="input_but"> <input type="submit" value="Нет" name="delno" class="input_but"></form></div>';
	db_close();
	include "footer.php";
	exit;
}
////////// ------------------------------------------- HERE ------------------------------------------------ ///////////////
if(isset($_GET['inbox'])) {
	// messages list..
	set_tp('Hộp thư đến');
	
	if(mysql_num_rows(mysql_query("SELECT * FROM `privmsg` WHERE `to`=".$_SESSION['my_id']." AND (`status`=0 OR `status`=1 OR `status`=2);")) == 0) echo 'Thư mục <b>Hộp thư đến</b> trống.';
	else
	{
		$totalmsg = mysql_num_rows(mysql_query("SELECT * FROM `privmsg` WHERE `to`=".$_SESSION['my_id']." AND (`status`=0 OR `status`=1 OR `status`=2);"));
		if(!isset($_GET['page'])) $_GET['page'] = 1;
		$_GET['page'] = (int)$_GET['page'];
		if($_GET['page'] == '' || $_GET['page'] <= 0 || $_GET['page'] > ceil($totalmsg/10)) {
			echo '<div class="body">Страницы не существует.</div>';
			db_close();
			include "footer.php";
			exit;
		}
		$pages = ceil($totalmsg / 10);
		$pstart = ($_GET['page']-1) * 10;
		$pfinish = $_GET['page'] * 10;
		if($pfinish > $totalmsg) $pfinish = $totalmsg;
		echo '<div class="body">';
		for($i = $pstart; $i < $pfinish; $i++) {
			$arr = mysql_fetch_assoc(mysql_query("SELECT * FROM `privmsg` WHERE (`to`=".$_SESSION['my_id']." AND (`status`=0 OR `status`=1 OR `status`=2)) ORDER BY `time` DESC LIMIT ".$i.",1;"));
			if($arr['status'] == 0 || $arr['status'] == 1) echo '<img src="img/letter_new.gif" alt="letter" border="0" /> ';
			else echo '<img src="img/letter.gif" alt="letter" border="0" /> ';
			$tmparr = mysql_fetch_assoc(mysql_query("SELECT * FROM users WHERE id=".$arr['from'].";"));
			echo '<a href="privat.php?msg='.$arr['id'].'">'.htmlspecialchars(stripslashes($arr['subject'])).'</a> от '.htmlspecialchars(stripslashes($tmparr['login'])).'<br/>';
		}
		echo '</div>';
		if($pages > 1) showLP1($pages, "inbox");
	}

	db_close();
	include "footer.php";
	exit;
}
if(isset($_GET['outbox'])) {
	// messages list..
	set_tp('Hộp thư đi');
	
	if(mysql_num_rows(mysql_query("SELECT * FROM `privmsg` WHERE `from`=".$_SESSION['my_id']." AND `status`=3;")) == 0) echo 'Thư mục <b>Hộp thư đi</b> trống.';
	else
	{
		$totalmsg = mysql_num_rows(mysql_query("SELECT * FROM `privmsg` WHERE `from`=".$_SESSION['my_id']." AND `status`=3;"));
		if(!isset($_GET['page'])) $_GET['page'] = 1;
		$_GET['page'] = (int)$_GET['page'];
		if($_GET['page'] == '' || $_GET['page'] <= 0 || $_GET['page'] > ceil($totalmsg/10)) {
			echo '<div class="body">Trang không tồn tại!';
			db_close();
			include "footer.php";
			exit;
		}
		$pages = ceil($totalmsg / 10);
		$pstart = ($_GET['page']-1) * 10;
		$pfinish = $_GET['page'] * 10;
		if($pfinish > $totalmsg) $pfinish = $totalmsg;
		echo '<div class="body">';
		for($i = $pstart; $i < $pfinish; $i++) {
			$arr = mysql_fetch_assoc(mysql_query("SELECT * FROM `privmsg` WHERE `from`=".$_SESSION['id']." AND `status`=3 ORDER BY `time` DESC LIMIT ".$i.",1;"));
			echo '<img src="img/letter.gif" alt="letter" border="0" /> ';
			$tmparr = mysql_fetch_assoc(mysql_query("SELECT * FROM users WHERE id=".$arr['to'].";"));
			echo '<a href="privat.php?outmsg='.$arr['id'].'">'.htmlspecialchars(stripslashes($arr['subject'])).'</a> к '.htmlspecialchars(stripslashes($tmparr['login'])).'<br/>';
		}
		echo '</div>';
		if($pages > 1) showLP1($pages, "outbox");
	}
	db_close();
	include "footer.php";
	exit;
}
if(isset($_GET['newmsg'])) {
	set_tp("Soạn tin nhắn mới");
	if($_POST['gonewmsg']) {
		if($_POST['to'] == '' || $_POST['subject'] == '' || $_POST['text'] == '') {
			echo '<div class="body">Вы ввели не все данные!</div>';
			include "footer.php";
			exit;
		}
		
		if(mysql_num_rows(mysql_query("SELECT * FROM users WHERE login='".mysql_escape_string($_POST['to'])."';")) == 0) {
			echo '<div class="body">Người dùng không tồn tại.</div>';
			db_close();
			include "footer.php";
			exit;
		}
		$arruser = mysql_fetch_assoc(mysql_query("SELECT * FROM users WHERE login='".mysql_escape_string($_POST['to'])."';"));
		
		foreach($_POST as $key=>$value) {
			$_POST[$key] = htmlspecialchars($_POST[$key]);
		}
		if(isset($_POST['trueodd']) && $_POST['trueodd'] == 1) $stat = 1;
			else $stat = 0;
		if($arruser['id'] == $_SESSION['id'] && $_POST['to4noda'] != 'da') {
			echo '<div class="body">Và bạn thực sự chắc chắn bạn muốn gửi một thông điệp đến chính bạn? :)<br/><form action="privat.php?newmsg" method="post">';
			echo '<input type="hidden" name="to" value="'.$_POST['to'].'">';
			echo '<input type="hidden" name="subject" value="'.$_POST['subject'].'">';
			echo '<input type="hidden" name="text" value="'.$_POST['text'].'">';
			echo '<input type="hidden" name="to4noda" value="da">';
			echo '<input type="submit" name="gonewmsg" value="Да" class="input_but"> <input type="submit" name="nogo" value="Нет" class="input_but"></form></div>';
		} else {
			$a = @mysql_fetch_assoc(mysql_query("SELECT MAX(id) FROM `privmsg`;"));
			if(mysql_query("INSERT INTO `privmsg` VALUES(".($a['MAX(id)'] + 1).", ".$_SESSION['my_id'].", ".$arruser['id'].", '".mysql_escape_string($_POST['subject'])."', '".mysql_escape_string($_POST['text'])."', ".time().", ".$stat.");")) {
				$a = mysql_fetch_assoc(mysql_query("SELECT MAX(id) FROM `privmsg` WHERE `status`=3;"));
				mysql_query("INSERT INTO `privmsg` VALUES(".($a['MAX(id)'] + 1).", ".$_SESSION['my_id'].", ".$arruser['id'].", '".mysql_escape_string($_POST['subject'])."', '".mysql_escape_string($_POST['text'])."', ".time().", 3)");
				echo "<div class=\"body\">Сообщение успешно отправлено.</div>";
			} else echo "MySQL Error: ".mysql_error().'';
		}
		include "footer.php";
		db_close();
		exit;
	}
	$ppto = '';
	$ppsubj = '';
	$pptext = '';
	if($_GET['ansto'] != '') {
		$_GET['ansto'] = (int)$_GET['ansto'];
		if($_GET['ansto'] == '') {
			echo '<div class="body">ID nhắn tin không hợp lệ.</div>';
			include "footer.php";
			exit;
		}
		$arr = mysql_fetch_assoc(mysql_query("SELECT * FROM `privmsg` WHERE `id`=".$_GET['ansto']." AND (`status`=0 OR `status`=1 OR `status`=2);"));
		if(mysql_num_rows(mysql_query("SELECT * FROM `privmsg` WHERE `id`=".$_GET['ansto']." AND (`status`=0 OR `status`=1 OR `status`=2);")) == 0  || $arr['to'] != $_SESSION['my_id']) {
			echo '<div class="body">Неверный ID сообщения.</div>';
			db_close();
			include "footer.php";
			exit;
		} else {
			$arrans = mysql_fetch_assoc(mysql_query("SELECT * FROM `privmsg` WHERE `id`=".$_GET['ansto']." AND (`status`=0 OR `status`=1 OR `status`=2);"));
			$arruserans = mysql_fetch_assoc(mysql_query("SELECT * FROM users WHERE id=".$arrans['from'].";"));
			$ppto = stripslashes($arruserans['login']);
			$ppsubj = "Re: ".$arrans['subject'];
			$pptext = "\n".$arrans['text'];
			$todbclose = true;
		}
	}
	if(isset($_GET['to'])) {
		$_GET['to'] = (int)$_GET['to'];
		if($_GET['to'] <= 0 || $_GET['to'] == '') {
			echo '<div class="body">Неверный ID сообщения.</div>';
			include "footer.php";
			exit;
		}
		$todbclose = true;
		if(mysql_num_rows(mysql_query("SELECT * FROM users WHERE id=".$_GET['to'].";")) == 0) {
			db_close();
			echo '<div class="body">Người dùng không tồn tại.</div>';
			include "footer.php";
			exit;
		}
		$arrus = mysql_fetch_assoc(mysql_query("SELECT * FROM users WHERE id=".$_GET['to'].";"));
		
		$ppto = stripslashes($arrus['login']);
	}
	echo '<div class="body"><form action="privat.php?newmsg" name="newmsgform" method="post" onsubmit="if(document.forms.newmsgform.to.value==\'\' || document.forms.newmsgform.subject.value==\'\' || document.forms.newmsgform.text.value==\'\') {alert(\'Вы ввели не все данные!\'); return false;}">';
	echo 'Đến:<br/><input type="text" name="to" value="'.$ppto.'" class="input_text"><br/>';
	echo 'Chủ đề:<br/><input type="text" name="subject" value="'.$ppsubj.'" class="input_text"><br/>';
	echo 'Nội dung:<br/><textarea name="text" cols="25" rows="7" class="input_text">'.$pptext.'</textarea><br/>';
	echo '<input type="submit" value="Gửi" name="gonewmsg" class="input_but"></form></div>';
	include "footer.php";
	if($todbclose) db_close();
	exit;
}

$prs = true;
set_tp('Hòm thư cá nhân');
echo '<div class="body"><a href="privat.php?inbox">Hộp thư đến</a> ['.mysql_num_rows(mysql_query("SELECT * FROM `privmsg` WHERE `to`=".$_SESSION['my_id']." AND (`status`=0 OR `status`=1);")).'/'.mysql_num_rows(mysql_query("SELECT * FROM `privmsg` WHERE `to`=".$_SESSION['my_id']." AND (`status`=0 OR `status`=1 OR `status`=2);")).']<br/>';
echo '<a href="privat.php?outbox">Hộp thư đi</a> ['.mysql_num_rows(mysql_query("SELECT * FROM `privmsg` WHERE `from`=".$_SESSION['my_id']." AND `status`=3;")).']';
echo '<hr/><a href="privat.php?newmsg">Soạn tin nhắn mới</a><br/>';
echo '</div>';
db_close();
include "footer.php";
?>
