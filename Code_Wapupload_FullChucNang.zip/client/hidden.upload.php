<?php
	include '../functions.php';
	db_connect();
	$setarr = mysql_fetch_assoc(mysql_query("SELECT * FROM settings"));
	if($_FILES['file']['size'] > 1024*1024*$setarr['maxfile']) {
		db_close();
		die('2');
	}
	if($_FILES['file']['error'] != 0 || $_FILES['file']['name'] == '') {
		db_close();
		die('3');
	}
	$rand = time().rand(0, 1000000);
	if(!checkExt($_FILES['file']['name'])) {
		db_close();
		die('1');
	}
	$time = time();
	$rand = rand(0, 1000000);
	
	$time_dir = md5($time);
	$rand_dir = md5($rand);
	
	mkdir('../files/'.$time_dir);
	chmod('../files/'.$time_dir, 0777);
	
	mkdir('../files/'.$time_dir.'/'.$rand_dir);
	chmod('../files/'.$time_dir.'/'.$rand_dir, 0777);
	
	copy($_FILES['file']['tmp_name'], '../files/'.$time_dir.'/'.$rand_dir.'/'.$_FILES['file']['name']);

	$filename = $_FILES['file']['name'];
	$path = '../files/'.$time_dir.'/'.$rand_dir.'/'.$filename;
	$yes_its_exists = 0;
	$is_image = 0;
	if(imgExt($filename)) {
		ini_set("memory_limit", $setarr['maxfile']."M"); 
		if($imgsize = getimagesize($path)) {
			$is_image = 1;
			if($imgsize[0] > 120) {
				switch($imgsize[2]) {
				case 1:
					$src = imagecreatefromgif($path);
					break;
				case 2:
					$src = imagecreatefromjpeg($path);
					break;
				case 3:
					$src = imagecreatefrompng($path);
					break;
				default:
					$defbreak = true;
					break;
				}
				if(!$defbreak) {
					$w_src = imagesx($src);
					$h_src = imagesy($src);
					$ratio = $w_src / 120;
					$w_dest = round($w_src / $ratio);
					$h_dest = round($h_src / $ratio);
					$dest = imagecreatetruecolor($w_dest, $h_dest);
					imagecopyresized($dest, $src, 0, 0, 0, 0, $w_dest, $h_dest, $w_src, $h_src);
					switch($imgsize[2]) {
					case 1:
						imagegif($dest, '../files/'.$time_dir.'/'.$rand_dir.'/preview'.image_type_to_extension($imgsize[2]));
						break;
					case 2:
						imagejpeg($dest, '../files/'.$time_dir.'/'.$rand_dir.'/preview'.image_type_to_extension($imgsize[2]));
						break;
					case 3:
						imagepng($dest, '../files/'.$time_dir.'/'.$rand_dir.'/preview'.image_type_to_extension($imgsize[2]));
						break; 
					}
					$yes_its_exists = 1;
				} 
			} else copy($path, '../files/'.$time_dir.'/'.$rand_dir.'/preview'.image_type_to_extension($imgsize[2]));
		}
	}
	$ar = mysql_fetch_assoc(mysql_query("SELECT MAX(id) FROM files;"));
	mysql_query("INSERT INTO files VALUES(".($ar['MAX(id)']+1).", 0, '".mysql_escape_string($filename)."', '".$time_dir.'/'.$rand_dir.'/'.mysql_escape_string($filename)."', '".mysql_escape_string($_SERVER['HTTP_USER_AGENT'])."', '".$_SERVER['REMOTE_ADDR']."', 0, '', '".mysql_escape_string($_POST['password'])."', '".$is_image."', '".$yes_its_exists."', '', '', '0', ".time().", '0');") or die(mysql_error());
	echo ($ar["MAX(id)"]+1);
	db_close();
?>