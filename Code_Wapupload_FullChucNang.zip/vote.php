<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html  xmlns="http://www.w3.org/1999/xhtml" lang="en" xml:lang="en">
<head>
	<title>B&#236;nh ch&#7885;n nh&#7887;</title>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<style type="text/css">
		<!--
		@import url("poll.css");
		-->
	</style>

</head>
<body>
<?
///////////////////////////////////////////////
// Example 1

// include the cf polling class file
	include('cfPolling/cf.poll.class.php');

// your poll question
	$poll_question ='B&#7841;n ngh&#297; g&#236; v&#7873; VnStart Upload?';

// In this variable you can enter the answers (voting options),
// which are selectable by the visitors.
// Each vote option gets an own variable. Example
	$answers[] = 'Tuy&#7879;t v&#7901;i$$!';
	$answers[] = 'Qu&#225; t&#7889;t^^';
	$answers[] = '&#272;&#7875; xem ti&#7871;p &#273;&#227;...';
	$answers[] = 'H&#417;i t&#7879;@@';

// Make new poll
	$new_poll = new cf_poll($poll_question,$answers);

// (Option)
// if you do not want to use cookies to log if a user has voted.
// if you are not using one_vote there is no need to use this.
//	$new_poll -> setCookieOff(); //(new 0.93)

// (Option)
// One vote per ip address (and cookies if not off)
	$new_poll -> one_vote();

// (Option)
// Number of days to run the poll for
	$new_poll -> poll_for(100);// end in 100 days
//	$new_poll -> endPollOn(02,03,2010);// (D,M,Y) the date to end the poll on (new 0.92)

// (Option)
// Set the Poll container id (used for css)
	$new_poll -> css_id('cfpoll1');

// chack to see if a vote has been cast
	$new_poll -> new_vote($_POST);

// echo/print poll to page
	echo $new_poll -> poll_html($_GET);



?>
</body>
</html>