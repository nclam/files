﻿﻿<?php
echo '<title>Cài đặt Mã nguồn Wap X.S2vn.Top</title>';
error_reporting(0);
$style = 'pro';
include 'header.php';
if(isset($_GET['deletefile'])) {
			echo 'Tập tin đã xóa thành công.';

header('Location: index.php');
			unlink('install.php');
	}
if(!$_GET['level'])
{
print "<div class='tp'>Cài đặt mã nguồn Wap Upload</div>
<form action='install.php?level=1' method='post'>
Tài khoản admin:<br>
<input name='name' type='text' value='admin'><br>
Mật khẩu:<br>
<input name='pass' type='text' value='12345'><br>
Email:<br>
<input name='mail' type='text' value='admin@s2vn.top'><br>
Máy chủ mySQL:<br>
<input name='serv' type='text' value='localhost'><br>
Tên CSDL:<br>
<input name='db' type='text' value='tên database'><br>
Tên đăng nhập CSDL:<br>
<input name='userbd' type='text' value='tên database'><br>
Mật mã CSDL:<br>
<input name='passbd' type='text' value='mật khẩu'><br>
Title wap:<br>
<input name='ten' type='text' value='X.S2vn.Top - Upload tập tin miễn phí'><br>
Tên trang web:<br>
<input name='tenshort' type='text' value='X.S2vn.Top'><br>
Địa chỉ trang web:<br>
<input name='urlw' type='text' value='http://x.s2vn.top'><br>
Theme sử dụng:<br>
<input name='theme' type='text' value='sang'><br>
<input type='submit' value='SETUP'>

</form>";
}
else
{
@chmod('config.php',0666);
$file = fopen('config.php','w');
fputs($file,'<?php
$dbhost = \''.$_POST[serv].'\';
$dbuser = \''.$_POST[userbd].'\';
$dbpasswd = \''.$_POST[passbd].'\';
$dbname = \''.$_POST[db].'\';
$style = \''.$_POST[theme].'\';
$tenwap = \''.$_POST[ten].'\';
$copy = \''.$_POST[tenshort].'\';
$diachi = \''.$_POST[urlw].'\';
define("UPLOAD_INSTALL", true);
?>') or die('Không thể viết dữ liệu đến tập tin config.php');
fclose($file);
@chmod('config.php',0644);
@chmod('files/',0777);


include 'functions.php';
db_connect();
$query = mysql_query("DROP TABLE `files`,`comments`,`complaints`,`cat`,`privmsg`,`settings` ,`users`;");

$sql='CREATE TABLE `comments` (
  `id` int(11) NOT NULL,
  `file` int(11) NOT NULL,
  `user` int(11) NOT NULL,
  `text` text character set utf8 collate utf8_unicode_ci NOT NULL,
  `time` int(11) NOT NULL,
  `ip` varchar(20) NOT NULL,
  `ua` varchar(100) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;';

$res = mysql_query($sql);
$error = mysql_error();

$sql='CREATE TABLE `complaints` (
  `id` int(11) NOT NULL,
  `user` int(11) NOT NULL,
  `text` varchar(1000) character set utf8 collate utf8_unicode_ci NOT NULL,
  `time` int(21) NOT NULL,
  `ip` varchar(1000) character set utf8 collate utf8_unicode_ci NOT NULL,
  `ua` varchar(1000) character set utf8 collate utf8_unicode_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;';

$res = mysql_query($sql);
$error = mysql_error();

$sql="CREATE TABLE `files` (
  `id` int(11) NOT NULL,
  `user` int(11) NOT NULL,
  `filename` text character set utf8 collate utf8_unicode_ci NOT NULL,
  `path` text character set utf8 collate utf8_unicode_ci NOT NULL,
  `ip` text NOT NULL,
  `ua` text NOT NULL,
  `load` int(11) NOT NULL,
  `note` text character set utf8 collate utf8_unicode_ci NOT NULL,
  `password` text NOT NULL,
  `img` int(11) NOT NULL,
  `imgpreview` int(11) NOT NULL,
  `votes` text NOT NULL,
  `uvotes` text NOT NULL,
  `price` float NOT NULL,
  `time` int(11) NOT NULL,
  `lastloadtime` int(21) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;";
$res = mysql_query($sql);
$error = mysql_error();
if($error) $er = $error.'<br>';

$sql='CREATE TABLE `privmsg` (
  `id` int(11) NOT NULL,
  `from` int(11) NOT NULL,
  `to` int(11) NOT NULL,
  `subject` text character set utf8 collate utf8_unicode_ci NOT NULL,
  `text` text character set utf8 collate utf8_unicode_ci NOT NULL,
  `time` int(11) NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;';
$res = mysql_query($sql);
$error = mysql_error();
if($error) $er .= $error.'<br>';

$sql="CREATE TABLE `settings` (
  `commission` float NOT NULL,
  `maxfile` float NOT NULL,
  `defaultusermax` int(11) NOT NULL,
  `tom` float NOT NULL,
  `maxquote` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;";
$res = mysql_query($sql);
$error = mysql_error();
if($error) $er .= $error.'<br>';

$sql="CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `login` varchar(40) character set utf8 collate utf8_unicode_ci NOT NULL,
  `password` varchar(32) NOT NULL,
  `name` varchar(20) character set utf8 collate utf8_unicode_ci NOT NULL,
  `email` varchar(100) NOT NULL,
  `time` int(25) NOT NULL,
  `onpage` int(11) NOT NULL,
  `session` varchar(32) NOT NULL,
  `money` varchar(1000) NOT NULL,
  `uploaded` varchar(1000) NOT NULL,
  `avatar` int(11) NOT NULL,
  `level` int(11) NOT NULL,
  `quota` int(11) NOT NULL,
  `lasttime` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;";
$res = mysql_query($sql);
$error = mysql_error();
if($error) $er .= $error.'<br>';
$query = mysql_query("INSERT INTO `settings` VALUES(5, 50, 60, 7, 200);");
$query = mysql_query("INSERT INTO `users` VALUES(1, '".$_POST[name]."', '".md5(trim($_POST[pass]))."', 'Admin tối cao', '".$_POST[mail]."', 1230771661, 10, 'e4771cfe72cf4b6cf870a0440c67b943', '5011.92', '18.907', 1, 2, 61, 1244038676);");

echo 'Chúc mừng bạn đã cài đặt thành công mã nguồn. hãy xóa tập tin install.php !<br/>';
echo '<a href="install.php?deletefile">Xóa tập tin install.php</a><br/>';

}

print '<div class="tp">Copyright © 2014 - <a href="http:/code.iui.vn">Mạng Chia Sẻ CODE</a></div></body></html>';
?>