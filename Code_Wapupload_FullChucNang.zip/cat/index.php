<?php
@session_start();
include '../functions.php';
db_connect();

if($_COOKIE['login'] != '') {
	if(mysql_num_rows(mysql_query("SELECT * FROM users WHERE session='".$_COOKIE['login']."';")) != 0) {
		$arr = mysql_fetch_assoc(mysql_query("SELECT * FROM users WHERE session='".$_COOKIE['login']."';"));
		$_SESSION['login'] = $arr['login'];
		$_SESSION['id'] = $arr['id'];
		$_SESSION['sess'] = $_COOKIE['login'];
		if($arr['level'] == -1) {
			include '../header.php';
			echo 'Tài khoản của bạn đã bị cấm.';
			include '../footer.php';
			db_close();
			exit;
		}
	}
}

include '../header.php';

$tieude = "Duyệt hệ thống tập tin";
include '../tieude.php';

set_tp('<img src="http://www.freeiconsweb.com/Icons/16x16_File_icons/Computer_File_064.gif"/>Duyệt hệ thống tập tin');
echo <<< END
<div class="tpanel"><form action="index.php" method="get">
<div>Loại:
<select name="ft">
<option value="0">Tất cả</option>
<option value="1">Âm nhạc</option>
<option value="2">Hình ảnh</option>
<option value="3">Phim</option>
<option value="4">Tài liệu</option>
<option value="5">Tập tin nén</option>
<option value="6">Ứng dụng java</option>
<option value="7">Ứng dụng sis</option>
<option value="8">Ứng dụng exe</option>
</select>
<input type="submit" value="Chọn" />
</div></form>
</div>
END;
if($_SESSION['sess'] != '') {
	$user_arr = mysql_fetch_assoc(mysql_query("SELECT * FROM users WHERE id=".$_SESSION['my_id'].";"));
	$onpage = $user_arr['onpage'];
} else $onpage = 10;
if(($_POST['page']=(int)$_POST['page'])!='') $_GET['page'] = $_POST['page'];
$_GET['page'] = (int)$_GET['page'];
$_GET['ft'] = (int)$_GET['ft'];
$_GET['fs'] = (int)$_GET['fs'];
if($_GET['page'] < 1 || $_GET['page'] == '') $_GET['page'] = 1;
switch($_GET['ft']) {
case 0:
	$total = mysql_num_rows(mysql_query("SELECT * FROM files;"));
	break;
case 1:
	$total = mysql_num_rows(mysql_query("SELECT * FROM files WHERE filename LIKE '%.mp3' OR filename LIKE '%.wav' OR filename LIKE '%.amr' OR filename LIKE '%.mid%';"));
	break;
case 2:
	$total = mysql_num_rows(mysql_query("SELECT * FROM files WHERE filename LIKE '%.jpg' OR filename LIKE '%.gif' OR filename LIKE '%.png' OR filename LIKE '%.bmp' OR filename LIKE '%.svg' OR filename LIKE '%.jpeg';"));
	break;
case 3:
	$total = mysql_num_rows(mysql_query("SELECT * FROM files WHERE filename LIKE '%.3gp' OR filename LIKE '%.avi' OR filename LIKE '%.mp4' OR filename LIKE '%.mpg';"));
	break;
case 4:
	$total = mysql_num_rows(mysql_query("SELECT * FROM files WHERE filename LIKE '%.doc' OR filename LIKE '%.txt' OR filename LIKE '%.odt';"));
	break;
case 5:
	$total = mysql_num_rows(mysql_query("SELECT * FROM files WHERE filename LIKE '%.zip' OR filename LIKE '%.rar' OR filename LIKE '%.7z' OR filename LIKE '%.tar%';"));
	break;
case 6:
	$total = mysql_num_rows(mysql_query("SELECT * FROM files WHERE filename LIKE '%.jad' OR filename LIKE '%.jar';"));
	break;
case 7:
	$total = mysql_num_rows(mysql_query("SELECT * FROM files WHERE filename LIKE '%.sis' OR filename LIKE '%.sisx';"));
	break;
case 8:
	$total = mysql_num_rows(mysql_query("SELECT * FROM files WHERE filename LIKE '%.exe';"));
	break;


default:
	break;
}
if($total == 0) {
	echo 'Không tìm thấy tệp tin.';
	echo '<div class="btm">[<a href="../index.php">Trang chủ</a>]</div>';
	include '../footer.php';
	db_close();
	exit;
}
//echo $total;
if(($_GET['page'] - 1) * $onpage > $total) $_GET['page'] = 1;
$first = ($_GET['page'] - 1) * $onpage;
$last = $_GET['page'] * $onpage;
if($last > $total) $last = $total;

for($i = $first; $i < $last; $i++) {
	switch($_GET['ft']) {
	case 0:
		$file = mysql_fetch_assoc(mysql_query("SELECT * FROM files ORDER BY id DESC LIMIT $i,1;"));
		break;
	case 1:
		$file = mysql_fetch_assoc(mysql_query("SELECT * FROM files WHERE filename LIKE '%.mp3' OR filename LIKE '%.wav' OR filename LIKE '%.amr' OR filename LIKE '%.mid%' ORDER BY id DESC LIMIT $i,1;"));
		break;
	case 2:
		$file = mysql_fetch_assoc(mysql_query("SELECT * FROM files WHERE filename LIKE '%.jpg' OR filename LIKE '%.gif' OR filename LIKE '%.png' OR filename LIKE '%.bmp' OR filename LIKE '%.svg' OR filename LIKE '%.jpeg' ORDER BY id DESC LIMIT $i,1;"));
		break;
	case 3:
		$file = mysql_fetch_assoc(mysql_query("SELECT * FROM files WHERE filename LIKE '%.3gp' OR filename LIKE '%.avi' OR filename LIKE '%.mp4' OR filename LIKE '%.mpg' ORDER BY id DESC LIMIT $i,1"));
		break;
	case 4:
		$file = mysql_fetch_assoc(mysql_query("SELECT * FROM files WHERE filename LIKE '%.doc' OR filename LIKE '%.txt' OR filename LIKE '%.odt' ORDER BY id DESC LIMIT $i,1"));
		break;
	case 5:
		$file = mysql_fetch_assoc(mysql_query("SELECT * FROM files WHERE filename LIKE '%.zip' OR filename LIKE '%.rar' OR filename LIKE '%.7z' OR filename LIKE '%.tar%' ORDER BY id DESC LIMIT $i,1"));
		break;
        case 6:
		$file = mysql_fetch_assoc(mysql_query("SELECT * FROM files WHERE filename LIKE '%.jad' OR filename LIKE '%.jar' ORDER BY id DESC LIMIT $i,1"));
		break;
        case 7:
		$file = mysql_fetch_assoc(mysql_query("SELECT * FROM files WHERE filename LIKE '%.sis' OR filename LIKE '%.sisx' ORDER BY id DESC LIMIT $i,1"));
		break;
        case 8:
		$file = mysql_fetch_assoc(mysql_query("SELECT * FROM files WHERE filename LIKE '%.exe' ORDER BY id DESC LIMIT $i,1"));
		break;


	default:
		break;

	}
	//$file = mysql_fetch_assoc(mysql_query("SELECT * FROM files ORDER BY id DESC LIMIT ".$i.",1;"));
include '../seo.php';
	echo '<div class="list">»<a href="../taptin-'.$file['id'].'.html">'.htmlspecialchars(stripslashes($file['filename'])).'</a> (';
	$fsize = @filesize('../files/'.$file['path']);
	if($fsize < 1024) echo $fsize.' Bytes)</div>';
	 else echo round($fsize/1024, 1).'Кb)</div>';
}
$pages = ceil($total/$onpage);
echo '</div><div class="filelist_paging">';
if($_GET['page'] > 1) echo '<a href="index.php?page='.($_GET['page']-1).'&ft='.$_GET['ft'].'">&lt;Trước.</a>';
if($_GET['page'] > 1 && $_GET['page'] < $pages) echo '|';
if($_GET['page'] < $pages) echo '<a href="index.php?page='.($_GET['page']+1).'&ft='.$_GET['ft'].'">Tiếp.&gt;</a>';
echo '';
showLP($pages, '&ft='.$_GET['ft']);
echo '</div>';
echo '</div><div class="tp">';
echo '<a href="/upload">Upload</a> | <a href="../search/">Search</a>';
echo ' | <a href="../index.php">Home</a>';
echo '</div> ';
db_close();
include '../footer.php';
?>