<?php
@session_start();
include 'functions.php';
db_connect();
if($_COOKIE['login'] != '') {
	if(mysql_num_rows(mysql_query("SELECT * FROM users WHERE session='".$_COOKIE['login']."';")) != 0) {
		$arr = mysql_fetch_assoc(mysql_query("SELECT * FROM users WHERE session='".$_COOKIE['login']."';"));
		$_SESSION['login'] = $arr['login'];
		$_SESSION['my_id'] = $arr['id'];
		$_SESSION['sess'] = $_COOKIE['login'];
	}
}

include 'header.php';
set_tp('Trình điều khiển dành cho admin');
if($_SESSION['sess'] == '') {
	echo 'Bạn không có quyền truy cập vào Admin CPanel!';
	include 'footer.php';
	db_close();
	exit;
} else {
	$_user_array = mysql_fetch_assoc(mysql_query("SELECT * FROM users WHERE id=".$_SESSION['my_id'].';'));
	if($_user_array['level'] < 2) {
		echo 'Bạn không có quyền truy cập vào phần này.';
		db_close();
		include 'footer.php';
		exit;
	}
	$show_in_admin = true;
	switch($_GET['mode']) {
	case 'users':
		if(($_GET['uid'] = (int)$_GET['uid']) != '') {
			if(mysql_num_rows(mysql_query("SELECT * FROM users WHERE id=".$_GET['uid'].';')) == 0) {
				echo 'Không tìm thấy người dùng '.$_GET['uid'].' .';
				include 'footer.php';
				db_close();
				exit;
			}
			$_user = mysql_fetch_assoc(mysql_query("SELECT * FROM users WHERE id=".$_GET['uid'].';'));
			if(isset($_POST['save'])) {
				ini_set("memory_limit", "50M");
				if($_POST['avatar'] == 1) {
					if(isset($_POST['file_opera'])) {
						// operamini suck opload
						$uploaddir = 'avatars/';
						$uploadedfile = $_POST['file_opera'];
						if(strlen($uploadedfile)) {
							$array = explode('file=', $uploadedfile);
							$tmp_name = $array[0];
							$filebase64 = $array[1];
						}
						if (strlen($filebase64)) {
							$name = $_GET['uid'].'_tmp.png';
							$FileName = $uploaddir.$name;
							$filedata = base64_decode($filebase64);
							$file = @fopen($FileName, "wb");
							if($file){
								if(flock($file, LOCK_EX)){
									fwrite($file, $filedata);
									flock($file, LOCK_UN);
								}
								fclose($file);
							}
						} elseif($_user['avatar'] == 0) {
							echo 'Lỗi tải tập tin!';
							db_close();
							include 'footer.php';
							exit;
						} else $bb = true;
					} else {
						if(isset($_FILES['file']) && $_FILES['file']['error'] == 0) {
							copy($_FILES['file']['tmp_name'], 'avatars/'.$_GET['uid'].'_tmp.png');
						} elseif($_user['avatar'] == 0) {
							echo 'Lỗi tải tập tin!';
							db_close();
							include 'footer.php';
							exit;
						} else $bb = true;
					}
					if(!$bb) {
						if(!($imgsize = getimagesize('avatars/'.$_GET['uid']."_tmp.png"))) {
							unlink('avatars/'.$_GET['uid'].'_tmp.png');
							echo 'Các tập tin có thể bị hỏng.';
							db_close();
							include 'footer.php';
							exit;
						}
						switch($imgsize[2]) {
						case 1:
							$src = imagecreatefromgif('avatars/'.$_GET['uid']."_tmp.png");
							break;
						case 2:
							$src = imagecreatefromjpeg('avatars/'.$_GET['uid']."_tmp.png");
							break;
						case 3:
							$src = imagecreatefrompng('avatars/'.$_GET['uid']."_tmp.png");
							break;
						default:
							$defbreak = true;
							break;
						}
						
						if(file_exists('avatars/'.$_GET['uid'].'.png')) unlink('avatars/'.$_GET['uid'].'.png');
						
						$w_src = imagesx($src);
						$h_src = imagesy($src);
						$ratio = $w_src / 100;
						$w_dest = round($w_src / $ratio);
						$h_dest = round($h_src / $ratio);
						$dest = imagecreatetruecolor($w_dest, $h_dest);
						imagecopyresized($dest, $src, 0, 0, 0, 0, $w_dest, $h_dest, $w_src, $h_src);
						imagepng($dest, 'avatars/'.$_GET['uid'].'.png');
						
						unlink('avatars/'.$_GET['uid'].'_tmp.png');
					}
				}
				$_POST['onpage'] = (int)$_POST['onpage'];
 				$_POST['money'] = (float)$_POST['money'];
				$_POST['quota'] = (int)$_POST['quota'];
 				$_POST['uploaded'] = (float)$_POST['uploaded'];
 				if($_POST['onpage'] == '' || $_POST['onpage'] < 1) $_POST['onpage'] = 10;
 				if($_POST['money'] == '') $_POST['money'] = 0.0;
 				if($_POST['uploaded'] == '') $_POST['uploaded'] = 0.0;
				if($_POST['quota'] == '') $_POST['quota'] = 0;
 				if($_POST['lvl'] == '') $_POST['lvl'] = 0;
 				if($_POST['login'] == '') $_POST['login'] = $_user['login'];
 				if($_POST['avatar'] == 0 && $_user['avatar'] == 1) @unlink('avatars/'.$_GET['uid'].'.png');
 				mysql_query("UPDATE users SET login='".mysql_escape_string($_POST['login'])."', email='".mysql_escape_string($_POST['email'])."', name='".mysql_escape_string($_POST['name'])."', onpage='".$_POST['onpage']."', uploaded='".$_POST['uploaded']."', quota='".$_POST['quota']."', money='".$_POST['money']."', avatar='".$_POST['avatar']."', level='".$_POST['lvl']."' WHERE id=".$_GET['uid'].";") or die(mysql_error());
 				echo 'Thông tin đã được thay đổi thành công!';
 				include 'footer.php';
 				db_close();
 				exit;	
			}
			echo '<form action="admin.php?mode=users&uid='.$_user['id'].'" method="post" enctype="multipart/form-data">';
			echo 'ID: '.$_user['id'].'<br/>';
			echo 'Tên đăng nhập:<br/><input type="text" name="login" value="'.stripslashes($_user['login']).'" /><br/>';
			echo 'Tên thật:<br/><input type="text" name="name" value="'.stripslashes($_user['name']).'" /><br/>';
			echo 'E-mail:<br/><input type="text" name="email" value="'.stripslashes($_user['email']).'" /><br/>';
			echo 'Tập tin trên trang:<br/><input type="text" name="onpage" value="'.$_user['onpage'].'" /><br/>';
			echo 'Tài sản ảo:<br/><input type="text" name="money" value="'.$_user['money'].'" /><br/>';
			echo 'Tải lên (Мb):<br/><input type="text" name="uploaded" value="'.$_user['uploaded'].'" /><br/>';
			echo 'Hạn ngạch (Мb):<br/><input type="text" name="quota" value="'.$_user['quota'].'"/><br/>';
			echo 'Avatar:<br/>';
			echo '<select name="avatar" onChange="if(this.selectedIndex==1)document.getElementById(\'hidav\').style.display=\'\';else document.getElementById(\'hidav\').style.display=\'none\'">';
			if($_user['avatar'] == 0) echo '<option value="0" selected>Tắt</option>';
				else echo '<option value="0">Tắt</option>';
			if($_user['avatar'] == 1) echo '<option value="1" selected>Trên</option>';
				else echo '<option value="1">Trên</option>';
			echo '</select><br/>';
			echo '<div id="hidav" style="display:none; padding: 5px 5px 5px 5px; background-color: #FFDEAD">';
			if($_user['avatar'] == 1) echo '<img src="avatars/'.$_user['id'].'.png" alt="" border="" /><br/>';
			switch(parseUA($_SERVER['HTTP_USER_AGENT'])) {
			case 1:
			case 2:
				echo 'Chọn tập tin:<br/><input name="file_opera" value="" /><a href="op:fileselect">Chọn tập tin</a><br/>';
			case 3:
			case 4:
			default:
				echo 'Lợi ích:<br/><input type="file" name="file" /><br/>';
			break;
			}
			echo '</div>';
			if($_user['avatar'] == 1) echo '<script type="text/javascript">document.getElementById(\'hidav\').style.display=\'\';</script>';
			echo 'Lợi ích:<br/><select name="lvl">';
			if($_user['level'] == -1) echo '<option value="-1" selected>Người bị chặn</option>'; else echo '<option value="-1">Người bị chặn</option>';
			if($_user['level'] == 0) echo '<option value="0" selected>Người dùng thông thường</option>'; else echo '<option value="0">Người dùng thông thường</option>';
			if($_user['level'] == 2) echo '<option value="2" selected>Admin</option>'; else echo '<option value="2">Admin</option>';
			echo '</select><br/><input type="submit" value="Lưu lại" name="save" />';
			echo '</form>';
			include 'footer.php';
			db_close();
			exit;
		}
		if($_GET['show'] == 'ban') {
			if(($_GET['page'] = (int)$_GET['page']) == '') $_GET['page'] = 1;
			$start = 20 * ($_GET['page'] - 1);
			$finish = 20 * $_GET['page'];
			$total = mysql_num_rows(mysql_query("SELECT * FROM users WHERE level=-1;"));
			if($total == 0) {
				echo 'Không có người dùng nào bị cấm.';
				db_close();
				include 'footer.php';
				exit;
			}
			if($finish > $total) $finish = $total;
			
			for($i = $start; $i < $finish; $i++)  {
				$user = mysql_fetch_assoc(mysql_query("SELECT * FROM users WHERE level=-1 ORDER BY id LIMIT ".$i.",1;"));
				echo '<a href="admin.php?mode=users&uid='.$user['id'].'">'.htmlspecialchars(stripslashes($user['login'])).'</a><br/>';
			}
			$pages = ceil($total/20);
			if($_GET['page'] > 1) echo '<a href="index.php?page='.($_GET['page']-1).'&ft='.$_GET['ft'].'">&lt;пред.</a>';
			if($_GET['page'] > 1 && $_GET['page'] < $pages) echo '|';
			if($_GET['page'] < $pages) echo '<a href="index.php?page='.($_GET['page']+1).'&ft='.$_GET['ft'].'">след.&gt;</a>';
			db_close();
			include 'footer.php';
			exit;
		}
		echo '<a href="admin.php?mode=users&show=ban">Danh sách người dùng bị cấm</a><hr/>';
		if(($_GET['page'] = (int)$_GET['page']) == '') $_GET['page'] = 1;
		$start = 20 * ($_GET['page'] - 1);
		$finish = 20 * $_GET['page'];
		$total = mysql_num_rows(mysql_query("SELECT * FROM users;"));
		if($total == 0) {
			echo 'Пользователей не зарегистрировано.';
			db_close();
			include 'footer.php';
			exit;
		}
		if($finish > $total) $finish = $total;
		
		for($i = $start; $i < $finish; $i++)  {
			$user = mysql_fetch_assoc(mysql_query("SELECT * FROM users ORDER BY id LIMIT ".$i.",1;"));
			echo '<a href="admin.php?mode=users&uid='.$user['id'].'">'.htmlspecialchars(stripslashes($user['login'])).'</a><br/>';
		}
		$pages = ceil($total/20);
		if($_GET['page'] > 1) echo '<a href="admin.php?mode=users&page='.($_GET['page']-1).'&ft='.$_GET['ft'].'">&lt;пред.</a>';
		if($_GET['page'] > 1 && $_GET['page'] < $pages) echo '|';
		if($_GET['page'] < $pages) echo '<a href="admin.php?mode=users&page='.($_GET['page']+1).'&ft='.$_GET['ft'].'">след.&gt;</a>';

		break;
	case 'complaints':
		if($_GET['delete'] != '') {
			$_d = explode(':', $_GET['delete']);
			if(@mysql_num_rows(mysql_query("SELECT * FROM complaints WHERE id=".$_d[0]." AND user=".$_d[1].";")) == 0) {
				echo 'Вы собираетесь удалить несуществующуу жалобу. Нехорошо это.';
				include 'footer.php';
				db_close();
				exit;
			}
			mysql_query("DELETE FROM complaints WHERE id=".$_d[0]." AND user=".$_d[1].";");
			mysql_query("OPTIMIZE TABLE complaints;");
			echo 'Жалоба успешно удалена.';
			include 'footer.php';
			db_close();
			exit;
		}
		$total = mysql_num_rows(mysql_query("SELECT * FROM complaints;"));
		echo 'Tổng số khiếu nại trong cơ sở dữ liệu: '.$total.'<br/><br/>';
		if(($_GET['page'] = (int)$_GET['page']) == '') $_GET['page'] = 1;
		$start = 20 * ($_GET['page'] - 1);
		$finish = 20 * $_GET['page'];
		if($finish > $total) $finish = $total;
		$pages = ceil($total / 20);
		for($i = $start; $i < $finish; $i++) {
			$arr = mysql_fetch_assoc(mysql_query("SELECT * FROM complaints LIMIT ".$i.",1;"));
			$file = mysql_fetch_assoc(mysql_query("SELECT * FROM files WHERE id=".$arr['id'].';'));
			$user = mysql_fetch_assoc(mysql_query("SELECT * FROM users WHERE id=".$arr['user'].';'));
			echo '<b>Tập tin:</b> <a href="index.php?id='.$file['id'].'">'.htmlspecialchars(stripslashes($file['filename'])).'</a> (ID: '.$file['id'].')<br/>';
			echo '<b>Người dùng:</b> <a href="admin.php?mode=users&uid='.$user['id'].'">'.htmlspecialchars(stripslashes($user['login'])).'</a> (ID: '.$user['id'].')<br/>';
			echo '<b>Thời gian:</b> '.date('d.m.Y H:i:s', $arr['time']).'<br/>';
			echo '<b>С какого IP:</b> '.htmlspecialchars(stripslashes($arr['ip'])).'<br/>';
			echo '<b>Trình duyệt:</b> '.htmlspecialchars(stripslashes($arr['ua'])).'<br/>';
			echo '<i>'.htmlspecialchars(stripslashes($arr['text'])).'</i><br/>';
			echo '<span style="padding-left: 10px;"></span><small><a href="admin.php?mode=complaints&delete='.$arr['id'].':'.$arr['user'].'">[Bỏ qua]</small><hr/>';
		}
		if($_GET['page'] > 1) echo '<a href="admin.php?mode=complaints&page='.($_GET['page']-1).'&">&lt;пред.</a>';
		if($_GET['page'] > 1 && $_GET['page'] < $pages) echo '|';
		if($_GET['page'] < $pages) echo '<a href="admin.php?mode=complaints&page='.($_GET['page']+1).'&">след.&gt;</a>';

		break;
	case 'settings':
		$setarr = mysql_fetch_assoc(mysql_query("SELECT * FROM settings;"));
		if(isset($_POST['setsetts'])) {
			$_POST['comm'] = (float)$_POST['comm'];
			$_POST['maxfile'] = (float)$_POST['maxfile'];
			$_POST['defum'] = (float)$_POST['defum'];
			$_POST['tom'] = (float)$_POST['tom'];
			$_POST['maxq'] = (int)$_POST['maxq'];
			if($_POST['comm'] == '') $_POST['comm'] = $setarr['comm'];
			if($_POST['maxfile'] == '') $_POST['maxfile'] = $setarr['maxfile'];
			if($_POST['defum'] == '') $_POST['defum'] = $setarr['defum'];
			if($_POST['tom'] == '') $_POST['tom'] = $setarr['tom'];
			mysql_query("UPDATE settings SET maxquote='".$_POST['maxq']."', maxfile='".$_POST['maxfile']."', commission='".$_POST['comm']."', defaultusermax='".$_POST['defum']."', tom='".$_POST['tom']."';") or die(mysql_error());
			echo 'Настройки успешно сохранены.';
			include 'footer.php';
			exit;
		}
		echo '<form action="admin.php?mode=settings" method="post">';
		echo 'Kích thước tối đa của tập tin (Мb):<br/><input type="text" name="maxfile" value="'.$setarr['maxfile'].'" /><br/>';
		echo 'Hoa hồng hệ thống (%):<br/><input type="text" name="comm" value="'.$setarr['commission'].'" /><br/>';
		echo 'Mặc định có thể tải về (Мb):<br/><input type="text" name="defum" value="'.$setarr['defaultusermax'].'" /><br/>';
		echo 'Như nhiều như bạn biết để nhân đó bằng cách mua các hạn ngạch:<br/><input type="text" name="tom" value="'.$setarr['tom'].'" /><br/>';
		echo 'Hạn mức tối đa:<br/><input type="text" name="maxq" value="'.$setarr['maxquote'].'" /><br/>';
		echo '<input type="submit" name="setsetts" value="Lưu lại" /></form>';
		include 'footer.php';
		db_close();
		exit;
	default:
		$show_in_admin = false;
		echo '<a href="admin.php?mode=users">Quản lý người dùng</a><br/>';
		echo '<a href="admin.php?mode=complaints">Xem khiếu nại</a><br/>';
		echo '<a href="admin.php?mode=settings">Cài đặt</a><br/>';
		break;
	}
	db_close();
}

include 'footer.php';
?>