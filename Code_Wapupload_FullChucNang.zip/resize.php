<?php
include 'functions.php';
if($_GET['id']){
$_GET['id'] = (int)$_GET['id'];
if($_GET['id'] == '' || $_GET['id'] == '') exit;
db_connect();
if(mysql_num_rows(mysql_query("SELECT * FROM files WHERE id=".$_GET['id'].';')) == 0) {
 db_close();
 exit;
}
$file = mysql_fetch_assoc(mysql_query("SELECT * FROM files WHERE id=".$_GET['id'].';'));
		$url='files/'.$file['path'];
header('Content-Type: image/jpg');
$h = $_GET['h'];
$w = $_GET['w'];
include 'SimpleImage.php';
$save = $url;
$image = new SimpleImage();
$image->load($save);
$image->resize($w, $h);
$image->output();

}
?>