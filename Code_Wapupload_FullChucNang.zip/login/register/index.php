<?php
@session_start();
include '../../functions.php';
db_connect();
if($_COOKIE['login'] != '') {
	if(mysql_num_rows(mysql_query("SELECT * FROM users WHERE session='".$_COOKIE['login']."';")) != 0) {
		$arr = mysql_fetch_assoc(mysql_query("SELECT * FROM users WHERE session='".$_COOKIE['login']."';"));
		$_SESSION['login'] = $arr['login'];
		$_SESSION['my_id'] = $arr['id'];
		$_SESSION['sess'] = $_COOKIE['login'];
	}
}
include '../../header.php';
set_tp('Đăng ký');

if($_SESSION['sess'] != '') {
	set_tp('oO');
	echo 'Và bạn, và do đó có thẩm quyền, nơi nào bạn đi :)';
	db_close();
	include '../footer.php';
	exit;
}
if(isset($_POST['send'])) {
	$f = false;
	$_POST['login'] = trim($_POST['login']);
	if(strlen($_POST['login']) < 3) {
		if(!$f) echo '<b><fonr color="#ff0000">Đã xảy ra lỗi:</font></b><br/>';
		$f = true;
		echo '<font color="#ff0000">Chiều dài tối thiểu nick - 3 ký tự;</font><br/>';
	}
	if(!preg_match('/[.]*[a-zA-Zа-яА-Я]+[.]*/', $_POST['login'])) {
		if(!$f) echo '<b><fonr color="#ff0000">Đã xảy ra lỗi:</font></b><br/>';
		$f = true;
		echo '<font color="#ff0000">Nick nên có ít nhất một trong những ký tự Latinh ;</font><br/>';
	}
	if($_POST['pwd2'] != $_POST['pwd']) {
		if(!$f) echo '<b><fonr color="#ff0000">Đã xảy ra lỗi:</font></b><br/>';
		$f = true;
		echo '<font color="#ff0000">Mật khẩu không khớp</font><br/>';
	}
	if(strlen($_POST['pwd']) < 6) {
		if(!$f) echo '<b><fonr color="#ff0000">Đã xảy ra lỗi:</font></b><br/>';
		$f = true;
		echo '<font color="#ff0000">Chiều dài tối thiểu mật khẩu - 6 ký tự;</font><br/>';
	}
	if($_POST['code'] != $_SESSION['securityCode']) {
		if(!$f) echo '<b><fonr color="#ff0000">Đã xảy ra lỗi:</font></b><br/>';
		$f = true;
		echo '<font color="#ff0000">Sai mã xác minh</font><br/>';
	}
	if(!$f) {
		//db_connect();
		
		$arr = mysql_fetch_assoc(mysql_query("SELECT MAX(id) FROM users;"));
		$setarr = mysql_fetch_assoc(mysql_query("SELECT * FROM settings;"));
		if(mysql_query("INSERT INTO users VALUES(".($arr["MAX(id)"]+1).", '".mysql_escape_string($_POST['login'])."', '".md5($_POST['pwd'])."', '', '".mysql_escape_string($_POST['mail'])."', ".time().", 10, '', '0.0', '0', 0, 0, ".$setarr['defaultusermax'].", 0);")) {
			echo '<div class="body"><b>Cám ơn bạn đã đăng ký!</b><br/>[<a href="../index.php">Đăng nhập</a>]</div>';
		} else echo mysql_error();
		
		db_close();
		include '../../footer.php';
		exit;
	}
}
echo '<div class="body"><b>Bạn điền thông tin phù hợp vào bản đăng ký này nhé:</b><br/>';
echo '<form action="index.php" method="post"><div>';
echo '*Tên đăng nhập:<br/><input type="text" name="login" value="" /><br/>';
echo '*Mật khẩu:<br/><input type="password" name="pwd" value="" /><br/>';
echo '<small class="gr">Từ 6 ký tự</small><br/>';
echo '*Xác nhận mật khẩu:<br/><input type="password" name="pwd2" value="" />';
echo '<br/>Địa chỉ E-mail:<br/><input type="text" name="mail" value="" />';
echo '<br/><small class="gr">Để khôi phục lại mật khẩu của bạn</small><br/>';
echo '*Nhập mã xác nhận:<br />';
echo '<img src="img.php" width="100" height="50" alt="" />';
echo '<br/><small>Gõ các ký tự từ hình trên</small><br/>';
echo '<input type="text" name="code" value="" size="5" maxlength="5" />';
echo '<br /><br/>Mình đã đọc và đồng ý với &laquo;<a href="../../help/terms/">Nội quy</a>&raquo; (không phức tạp lắm đâu)<br/>';
echo '<input type="submit" value=" Đăng ký ngay!" name="send" /><br/></div></form></div>';
include '../../footer.php';
?>