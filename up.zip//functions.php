<?php
function db_connect() {

	include 'config.php';
	if( !defined("UPLOAD_INSTALL") )
{
	header('Location: install.php');
	exit;
}
	mysql_connect($dbhost, $dbuser, $dbpasswd) or die('Could not connect to database!');
	mysql_select_db($dbname) or die('Could not connect to database!');
}

function db_close() {
	mysql_close();
}

function wapOrWeb() {
	if(isset($_SERVER["HTTP_X_OPERAMINI_FEATURES"]) || isset($_SERVER["HTTP_X_OPERAMINI_PHONE"]) || isset($_SERVER["HTTP_X_OPERAMINI_PHONE_UA"])) return 1;
	
	$s = $_SERVER['HTTP_USER_AGENT'];
	
	$_j2me = array(
	0 => "MIDP", 
			1 => "CLDC"
	);
	
	$_os = array(
			0 => "Linux",
			1 => "Windows",
			2 => "Macintosh",
			3 => "Mac OS",
			4 => "Solaris",
			5 => "NT"
	);
	
	for($i = 0; $i < sizeof($_j2me); $i++) {
		if(preg_match('/'.$_j2me[$i].'/i', $s)) return 1;
	}
	
	for($i = 0; $i < sizeof($_os); $i++) {
		if(preg_match('/'.$_os[$i].'/i', $s)) return 0;
	}
	return 1;
}

function set_tp($text) {
	echo '<div class="tp">'.$text.'</div>';
}

function getExt($name) {
	return end(explode('.', $name));
}

function getPath($filename) {
	return str_replace(end(explode("/", $filename)), '', $filename);
}

function checkExt($name) {
	$exts[] = '3gp';
	$exts[] = '7z';
	$exts[] = 'aac';
	$exts[] = 'amr';
	$exts[] = 'app';
	$exts[] = 'asf';
	$exts[] = 'asx';
	$exts[] = 'avi';
	$exts[] = 'bmp';
	$exts[] = 'bmx';
	$exts[] = 'cab';
	$exts[] = 'col';
	$exts[] = 'db';
	$exts[] = 'deb';
	$exts[] = 'ear';
	$exts[] = 'elf';
	$exts[] = 'exe';
	$exts[] = 'flv';
	$exts[] = 'gif';
	$exts[] = 'hme';
	$exts[] = 'img';
	$exts[] = 'imy';
	$exts[] = 'iso';
	$exts[] = 'jad';
	$exts[] = 'jar';
	$exts[] = 'jpeg';
	$exts[] = 'jpg';
	$exts[] = 'ldb';
	$exts[] = 'mid';
	$exts[] = 'midi';
	$exts[] = 'mmf';
	$exts[] = 'mng';
	$exts[] = 'mov';
	$exts[] = 'mp3';
	$exts[] = 'mp4';
	$exts[] = 'mpc';
	$exts[] = 'mpeg';
	$exts[] = 'mpg';
	$exts[] = 'mpn';
	$exts[] = 'msi';
	$exts[] = 'msm';
	$exts[] = 'msp';
	$exts[] = 'nth';
	$exts[] = 'ogg';
	$exts[] = 'pdf';
	$exts[] = 'png';
	$exts[] = 'ra';
	$exts[] = 'rar';
	$exts[] = 'rpm';
	$exts[] = 'rtf';
	$exts[] = 'scs';
	$exts[] = 'sdt';
	$exts[] = 'sis';
	$exts[] = 'sisx';
	$exts[] = 'srt';
	$exts[] = 'swf';
	$exts[] = 'thm';
	$exts[] = 'tsk';
	$exts[] = 'txt';
	$exts[] = 'utz';
	$exts[] = 'war';
	$exts[] = 'wav';
	$exts[] = 'wbmp';
	$exts[] = 'wmv';
	$exts[] = 'xpi';
	$exts[] = 'zip';
	$exts[] = 'tar';
	$exts[] = 'gz';
	$exts[] = 'bz2';
	$exts[] = 'jar1';
	$exts[] = 'apk';
	$exts[] = 'sql.gz';
	$exts[] = 'ico';
	
	$found = false;
	
	foreach($exts as $key=>$value) {
		if(getExt($name) == $value) {
			$found = true;
			break;
		}
	}
	
	if(!$found) return false;
	else return true;
}

function parseUA($s) {
	if(preg_match('/Opera Mini\/1/i', $s)) return 1;
	if(preg_match('/Opera Mini\/2/i', $s)) return 2;
	if(preg_match('/Opera Mini\/3/i', $s)) return 3;
	if(preg_match('/Opera Mini\/4/i', $s)) return 4;
}

function imgExt($name) {
	$exts[] = 'gif';
	$exts[] = 'png';
	$exts[] = 'jpg';
	$exts[] = 'bmp';
	$exts[] = 'ico';
	$exts[] = 'jpeg';
	
	$found = false;
	
	foreach($exts as $key=>$value) {
		if(getExt($name) == $value) {
			$found = true;
			break;
		}
	}
	
	if($found) return true;
	else return false;
}

//sai chac sai o day

function showMEM($pages, $u) {
	if($pages <= 7) {
		for($i = 1; $i <= $pages; $i++) {
			if($i == $_GET['page']) echo '<b>'.$i."</b>"; else
			echo '<a href="member.php?page='.$i.$u.'">'.$i.'</a>';
			if($i != $pages) echo ',';
		}
	}
	else
	{
		if($_GET['page'] <= 2 || $_GET['page'] >= $pages-2) {
			if($_GET['page'] == 1 || $_GET['page'] == $pages) {
			for($i = 1; $i <= 2; $i++) {
				if($i == $_GET['page']) echo '<b>'.$i.'</b>'; else
				echo '<a href="member.php?page='.$i.$u.'">'.$i.'</a>';
				if($i != 2) echo ',';
			}
			echo '..';
			for($i = $pages - 1; $i <= $pages; $i++) {
				if($i == $_GET['page']) echo '<b>'.$i.'</b>'; else
				echo '<a href="member.php?page='.$i.$u.'">'.$i.'</a>';
				if($i != $pages) echo ',';
			}
			} else {
			if($_GET['page'] <= 2) {
				for($i = 1; $i <= $_GET['page'] + 1; $i++) {
				if($i == $_GET['page']) echo '<b>'.$i.'</b>'; else
				echo '<a href="member.php?page='.$i.$u.'">'.$i.'</a>';
				if($i != $_GET['page'] + 1) echo ',';
				}
				echo '..';
				for($i = $pages - 1; $i <= $pages; $i++) {
				if($i == $_GET['page']) echo '<b>'.$i.'</b>'; else
				echo '<a href="member.php?page='.$i.$u.'">'.$i.'</a>';
				if($i != $pages) echo ',';
				}
			} else {
				for($i = 1; $i <= 2; $i++) {
				if($i == $_GET['page']) echo '<b>'.$i.'</b>'; else
				echo '<a href="member.php?page='.$i.$u.'">'.$i.'</a>';
				if($i != $_GET['page'] + 1) echo ',';
				}
				echo '..';
				for($i = $_GET['page'] - 1; $i <= $pages; $i++) {
				if($i == $_GET['page']) echo '<b>'.$i.'</b>'; else
				echo '<a href="member.php?page='.$i.$u.'">'.$i.'</a>';
				if($i != $pages) echo ',';
				}
			}
			}
		} else {
			$i = 1;
			if($_GET['page'] - 2 == 1) $p = ','; else $p = '..';
			echo '<a href="member.php?page='.$i.$u.'">'.$i.'</a>'.$p;
			
			//
			
			for($i = $_GET['page']-1; $i <= $_GET['page']+1; $i++) {
				if($i == $_GET['page']) echo '<b>'.$i.'</b>'; else
				echo '<a href="member.php?page='.$i.$u.'">'.$i.'</a>';
				if($i != $_GET['page']+1) echo ',';
			}
			echo '..';
			//
			
			$i = $pages;
			echo '<a href="member.php?page='.$i.$u.'">'.$i.'</a>';
		}
	}
}
//het sai
function get_next_file_id() {
	$arr = mysql_fetch_assoc(mysql_query("SELECT MAX(id) FROM files;"));
	return ($arr['MAX(id)']+1);
}

function showLP($pages, $u) {
	if($pages <= 7) {
		for($i = 1; $i <= $pages; $i++) {
			if($i == $_GET['page']) echo '<b>'.$i."</b>"; else
			echo '<a href="index.php?page='.$i.$u.'">'.$i.'</a>';
			if($i != $pages) echo ',';
		}
	}
	else
	{
		if($_GET['page'] <= 2 || $_GET['page'] >= $pages-2) {
			if($_GET['page'] == 1 || $_GET['page'] == $pages) {
			for($i = 1; $i <= 2; $i++) {
				if($i == $_GET['page']) echo '<b>'.$i.'</b>'; else
				echo '<a href="index.php?page='.$i.$u.'">'.$i.'</a>';
				if($i != 2) echo ',';
			}
			echo '..';
			for($i = $pages - 1; $i <= $pages; $i++) {
				if($i == $_GET['page']) echo '<b>'.$i.'</b>'; else
				echo '<a href="index.php?page='.$i.$u.'">'.$i.'</a>';
				if($i != $pages) echo ',';
			}
			} else {
			if($_GET['page'] <= 2) {
				for($i = 1; $i <= $_GET['page'] + 1; $i++) {
				if($i == $_GET['page']) echo '<b>'.$i.'</b>'; else
				echo '<a href="index.php?page='.$i.$u.'">'.$i.'</a>';
				if($i != $_GET['page'] + 1) echo ',';
				}
				echo '..';
				for($i = $pages - 1; $i <= $pages; $i++) {
				if($i == $_GET['page']) echo '<b>'.$i.'</b>'; else
				echo '<a href="index.php?page='.$i.$u.'">'.$i.'</a>';
				if($i != $pages) echo ',';
				}
			} else {
				for($i = 1; $i <= 2; $i++) {
				if($i == $_GET['page']) echo '<b>'.$i.'</b>'; else
				echo '<a href="index.php?page='.$i.$u.'">'.$i.'</a>';
				if($i != $_GET['page'] + 1) echo ',';
				}
				echo '..';
				for($i = $_GET['page'] - 1; $i <= $pages; $i++) {
				if($i == $_GET['page']) echo '<b>'.$i.'</b>'; else
				echo '<a href="index.php?page='.$i.$u.'">'.$i.'</a>';
				if($i != $pages) echo ',';
				}
			}
			}
		} else {
			$i = 1;
			if($_GET['page'] - 2 == 1) $p = ','; else $p = '..';
			echo '<a href="index.php?page='.$i.$u.'">'.$i.'</a>'.$p;
			
			//
			
			for($i = $_GET['page']-1; $i <= $_GET['page']+1; $i++) {
				if($i == $_GET['page']) echo '<b>'.$i.'</b>'; else
				echo '<a href="index.php?page='.$i.$u.'">'.$i.'</a>';
				if($i != $_GET['page']+1) echo ',';
			}
			echo '..';
			//
			
			$i = $pages;
			echo '<a href="index.php?page='.$i.$u.'">'.$i.'</a>';
		}
	}
}


function showLPF($pages, $u) {
	if($pages <= 7) {
		for($i = 1; $i <= $pages; $i++) {
			if($i == $_GET['page']) echo '<b>'.$i."</b>"; else
			echo '<a href="file.php?page='.$i.$u.'">'.$i.'</a>';
			if($i != $pages) echo ',';
		}
	}
	else
	{
		if($_GET['page'] <= 2 || $_GET['page'] >= $pages-2) {
			if($_GET['page'] == 1 || $_GET['page'] == $pages) {
			for($i = 1; $i <= 2; $i++) {
				if($i == $_GET['page']) echo '<b>'.$i.'</b>'; else
				echo '<a href="file.php?page='.$i.$u.'">'.$i.'</a>';
				if($i != 2) echo ',';
			}
			echo '..';
			for($i = $pages - 1; $i <= $pages; $i++) {
				if($i == $_GET['page']) echo '<b>'.$i.'</b>'; else
				echo '<a href="file.php?page='.$i.$u.'">'.$i.'</a>';
				if($i != $pages) echo ',';
			}
			} else {
			if($_GET['page'] <= 2) {
				for($i = 1; $i <= $_GET['page'] + 1; $i++) {
				if($i == $_GET['page']) echo '<b>'.$i.'</b>'; else
				echo '<a href="file.php?page='.$i.$u.'">'.$i.'</a>';
				if($i != $_GET['page'] + 1) echo ',';
				}
				echo '..';
				for($i = $pages - 1; $i <= $pages; $i++) {
				if($i == $_GET['page']) echo '<b>'.$i.'</b>'; else
				echo '<a href="file.php?page='.$i.$u.'">'.$i.'</a>';
				if($i != $pages) echo ',';
				}
			} else {
				for($i = 1; $i <= 2; $i++) {
				if($i == $_GET['page']) echo '<b>'.$i.'</b>'; else
				echo '<a href="file.php?page='.$i.$u.'">'.$i.'</a>';
				if($i != $_GET['page'] + 1) echo ',';
				}
				echo '..';
				for($i = $_GET['page'] - 1; $i <= $pages; $i++) {
				if($i == $_GET['page']) echo '<b>'.$i.'</b>'; else
				echo '<a href="file.php?page='.$i.$u.'">'.$i.'</a>';
				if($i != $pages) echo ',';
				}
			}
			}
		} else {
			$i = 1;
			if($_GET['page'] - 2 == 1) $p = ','; else $p = '..';
			echo '<a href="file.php?page='.$i.$u.'">'.$i.'</a>'.$p;
			
			//
			
			for($i = $_GET['page']-1; $i <= $_GET['page']+1; $i++) {
				if($i == $_GET['page']) echo '<b>'.$i.'</b>'; else
				echo '<a href="file.php?page='.$i.$u.'">'.$i.'</a>';
				if($i != $_GET['page']+1) echo ',';
			}
			echo '..';
			//
			
			$i = $pages;
			echo '<a href="file.php?page='.$i.$u.'">'.$i.'</a>';
		}
	}
}

function getWithoutPath($filename) {
	return end(explode("/", $filename));
}

function p20repl($fn) {
	return str_replace('%20', ' ', $fn);
}

//function tinh trang top file

function showTOP($pages, $u) {
	if($pages <= 7) {
		for($i = 1; $i <= $pages; $i++) {
			if($i == $_GET['page']) echo '<b>'.$i."</b>"; else
			echo '<a href="topfile.php?page='.$i.$u.'">'.$i.'</a>';
			if($i != $pages) echo ',';
		}
	}
	else
	{
		if($_GET['page'] <= 2 || $_GET['page'] >= $pages-2) {
			if($_GET['page'] == 1 || $_GET['page'] == $pages) {
			for($i = 1; $i <= 2; $i++) {
				if($i == $_GET['page']) echo '<b>'.$i.'</b>'; else
				echo '<a href="topfile.php?page='.$i.$u.'">'.$i.'</a>';
				if($i != 2) echo ',';
			}
			echo '..';
			for($i = $pages - 1; $i <= $pages; $i++) {
				if($i == $_GET['page']) echo '<b>'.$i.'</b>'; else
				echo '<a href="topfile.php?page='.$i.$u.'">'.$i.'</a>';
				if($i != $pages) echo ',';
			}
			} else {
			if($_GET['page'] <= 2) {
				for($i = 1; $i <= $_GET['page'] + 1; $i++) {
				if($i == $_GET['page']) echo '<b>'.$i.'</b>'; else
				echo '<a href="topfile.php?page='.$i.$u.'">'.$i.'</a>';
				if($i != $_GET['page'] + 1) echo ',';
				}
				echo '..';
				for($i = $pages - 1; $i <= $pages; $i++) {
				if($i == $_GET['page']) echo '<b>'.$i.'</b>'; else
				echo '<a href="topfile.php?page='.$i.$u.'">'.$i.'</a>';
				if($i != $pages) echo ',';
				}
			} else {
				for($i = 1; $i <= 2; $i++) {
				if($i == $_GET['page']) echo '<b>'.$i.'</b>'; else
				echo '<a href="topfile.php?page='.$i.$u.'">'.$i.'</a>';
				if($i != $_GET['page'] + 1) echo ',';
				}
				echo '..';
				for($i = $_GET['page'] - 1; $i <= $pages; $i++) {
				if($i == $_GET['page']) echo '<b>'.$i.'</b>'; else
				echo '<a href="topfile.php?page='.$i.$u.'">'.$i.'</a>';
				if($i != $pages) echo ',';
				}
			}
			}
		} else {
			$i = 1;
			if($_GET['page'] - 2 == 1) $p = ','; else $p = '..';
			echo '<a href="topfile.php?page='.$i.$u.'">'.$i.'</a>'.$p;
			
			//
			
			for($i = $_GET['page']-1; $i <= $_GET['page']+1; $i++) {
				if($i == $_GET['page']) echo '<b>'.$i.'</b>'; else
				echo '<a href="topfile.php?page='.$i.$u.'">'.$i.'</a>';
				if($i != $_GET['page']+1) echo ',';
			}
			echo '..';
			//
			
			$i = $pages;
			echo '<a href="topfile.php?page='.$i.$u.'">'.$i.'</a>';
		}
	}
}
//het

function getDirectorySize($path) 
{ 
  $totalsize = 0; 
  $totalcount = 0; 
  $dircount = 0; 
  if ($handle = opendir ($path)) 
  { 
    while (false !== ($file = readdir($handle))) 
    { 
      $nextpath = $path . '/' . $file; 
      if ($file != '.' && $file != '..' && !is_link ($nextpath)) 
      { 
        if (is_dir ($nextpath)) 
        { 
          $dircount++; 
          $result = getDirectorySize($nextpath); 
          $totalsize += $result['size']; 
          $totalcount += $result['count']; 
          $dircount += $result['dircount']; 
        } 
        elseif (is_file ($nextpath)) 
        { 
          $totalsize += filesize ($nextpath); 
          $totalcount++; 
        } 
      } 
    } 
  } 
  closedir ($handle); 
  $total['size'] = $totalsize; 
  $total['count'] = $totalcount; 
  $total['dircount'] = $dircount; 
  return $total; 
} 

function sizeFormat($size) 
{ 
    if($size<1024) 
    { 
        return $size." bytes"; 
    } 
    else if($size<(1024*1024)) 
    { 
        $size=round($size/1024,1); 
        return $size." KB"; 
    } 
    else if($size<(1024*1024*1024)) 
    { 
        $size=round($size/(1024*1024),1); 
        return $size." MB"; 
    } 
    else 
    { 
        $size=round($size/(1024*1024*1024),1); 
        return $size." GB"; 
    } 

}  

?>