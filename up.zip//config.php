<?php
$style = 'sang';