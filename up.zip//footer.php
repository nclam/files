<?php
//dem thoi gian load trang cuoi page
$gentime = microtime(); 
$gentime = explode(' ',$gentime); 
$gentime = $gentime[1] + $gentime[0]; 
$pg_end = $gentime; 
$totaltime = ($pg_end - $pg_start); 
$showtime = number_format($totaltime, 4, '.', ''); 
echo '</div>';
echo '<div class="tp"><center><h1>Free Wap Upload File<br>Copyright  ©  <a href="http://s2vn.top">S2vn.Top</a><br><small><font color="black">WapUpload tập tin : <a href="'.$diachi.'">'.$copy.'</a></font><br>Tải trang trong : '.$showtime.' sec</center></div></div></body></html>';

?>