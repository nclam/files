<?php
@session_start();
include '../functions.php';
db_connect();
if($_COOKIE['login'] != '') {
if(mysql_num_rows(mysql_query("SELECT * FROM users WHERE session='".$_COOKIE['login']."';")) != 0) {
$arr = mysql_fetch_assoc(mysql_query("SELECT * FROM users WHERE session='".$_COOKIE['login']."';"));
$_SESSION['login'] = $arr['login'];
$_SESSION['id'] = $arr['id'];
$_SESSION['sess'] = $_COOKIE['login'];
}
}
include '../header.php';

set_tp('Tìm kiếm tập tin');
if($_GET['query'] != '') {
$total = mysql_num_rows(mysql_query("SELECT * FROM files WHERE `filename` LIKE '%".mysql_escape_string(trim(nl2br($_GET['query'])))."%' OR `note` LIKE '%".mysql_escape_string(trim(nl2br($_GET['query'])))."%';"));
//echo $total;
if($total == 0) {
echo '<div class="list"><b>Tiếc quá</b><br/>FileUpload không thể tìm thấy tên tập tin bạn cần. Hãy <a href="/search/">Quay về</a> và thử tìm kiếm lại xem sao nhá!!</div>';
echo '<div class="tp"><a href="../upload">Upload</a> | <a href="../index.php">Home</a></div>';
db_close();
include '../footer.php';
exit;
}

echo '<div class="tp">Bạn đã tìm với từ khóa: "'.htmlspecialchars(trim(nl2br($_GET['query']))).'"</div>';
if(($_POST['page'] = (int)$_POST['page']) != '') $_GET['page'] = $_POST['page'];
if(($_GET['page'] = (int)$_GET['page']) == '' || $_GET['page'] < 1 || $_GET['page'] > ceil($total / 10)) $_GET['page'] = 1;

$s1 = ($_GET['page'] - 1) * 10;
$s2 = $_GET['page'] * 10;
if($s2 > $total) $s2 = $total;
for($i = $s1; $i < $s2; $i++) {
$file = mysql_fetch_assoc(mysql_query("SELECT * FROM files WHERE `filename` LIKE '%".mysql_escape_string($_GET['query'])."%' OR `note` LIKE '%".mysql_escape_string($_GET['query'])."%' ORDER BY id DESC LIMIT $i,1;"));
echo '<div class="list">»<a href="../'.$file['id'].'">'.$file['filename'].'</a></div>';
}

//echo '</div>';
$pages = ceil($total/10);
echo '</div><div class="filelist_paging">';
if($_GET['page'] > 1) echo '<a href="index.php?page='.($_GET['page']-1).'&query='.$_GET['query'].'">&lt;Trước.</a>';
if($_GET['page'] > 1 && $_GET['page'] < $pages) echo '|';
if($_GET['page'] < $pages) echo '<a href="index.php?page='.($_GET['page']+1).'&query='.$_GET['query'].'">Tiếp.&gt;</a>';
showLP($pages, '&query='.$_GET['query']);
echo '</div><div class="btm">';
echo '<div class="tp"><a href="../cat/">Download</a></div>';
echo '</div>';

db_close();
include '../footer.php';
exit;
}

echo '<div class="tpanel">';
echo 'Tổng số: '.mysql_num_rows(mysql_query("SELECT * FROM files;")).' Tệp</div><div class="body">';
echo '<form action="index.php" method="get">';
echo '<input type="text" name="query" value="" /><br/><input type="submit" value="Tìm kiếm!" /></form></div>';

echo '<div class="tp"><a href="../index.php">Trang chủ</a></div>';

include '../footer.php';
?>