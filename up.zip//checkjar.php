<?php
if ($_GET['id']){
$file_dir = 'files/';
$name = $file_dir.$file['path'];
    $jar=new ZipArchive();
    if($jar->open($name)===TRUE){
      $jarv=zip_open($name);
     If($jarv){
      while($entry=zip_read($jarv)){
        $title = zip_entry_name($entry);
        $size = zip_entry_filesize($entry);
        if(eregi('.class',$title)){
          $content = zip_entry_read($entry,$size);
          if(preg_match("/MessageConnection|TextMessage|setPayloadText|newMessage|setAddress/i",$content)){
            echo 'Cảnh báo: Tập <font color=red>'.$title.'</font> chứa cú pháp gửi tin nhắn !<br/>';
            $checkjar = 'sms';
          }
        }
        if(eregi('.MF',$title)){
          $content = zip_entry_read($entry,$size);
          if(preg_match("/SMSNUM/i",$content)){
            echo 'Cảnh báo: Tập <font color=red>'.$title.'</font> chứa cú pháp gửi tin nhắn !</font><br/>';
            $checkjar = 'sms';
          }
          }
    }
    $jar->close();
    
   } else {
      echo '<span style="color:red">Định dạng không hợp lệ !</span><br/>';
  }
  }  else {
      echo '<span style="color:red">Định dạng không hợp lệ !</span><br/>';
    }
if ($checkjar != 'sms'){
echo '<font color="green">Tập tin an toàn, không có sms lừa đảo và kích hoạt</font>';}
}else{echo 'Lỗi không xác định!'; }
  ?>