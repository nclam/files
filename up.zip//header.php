<? 
//top of your page 
$gentime = microtime(); 
$gentime = explode(' ',$gentime); 
$gentime = $gentime[1] + $gentime[0]; 
$pg_start = $gentime; 
?> 
<html xmlns="http://www.w3.org/1999/xhtml"><head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="copyright" content="Copyright © 2016 S2VN.TOP">
<meta http-equiv="content-language" content="vi" />
<meta name="geo.placename" content="S2VN.TOP" />
<meta name="Generator" content="S2VN.TOP"/>
<meta name="revisit-after" content="1 days">
<meta name="description" content="trang wap upload tep tin danh cho mobile, free upload file webupload, luu tru tap tin mien phi, x.s2vn.top">
<meta name="keywords" content="File upload, mobile vn,vietup,code upload,taptin.vn, wap upload free, tai len, tai len mobi, tai game, tai phan mem, download," />
<meta name="google-site-verification" content="QfcFBAg2ItQc8i7C0OV3JQydhU_8kE9VWSVlf1LD9LY" />
<meta property="og:url" content="http://x.s2vn.top" />
<meta property="og:image" content="http://nam.name.vn/publics/files/thumbnails/upload-download-buttons-vector-62647.jpg" />
<meta http-equiv="Cache-Control" content="no-cache" />
<meta property="article:tag" content="trang wap upload tep tin danh cho mobile, free upload file webupload, luu tru tap tin mien phi, " />
<meta property="fb:admins" content="zingdata" />
<link href="/style/<?php
include 'config.php';
echo $style;

?>.css" rel="stylesheet" type="text/css" />
<LINK REL="SHORTCUT ICON" HREF="/fileup.gif"> 
<link rel="alternate" type="application/rss+xml" title="RSS| Free Upload File" href="/feed.rss" />
</head>
<body>
<div class="head">

<a href="/index.php" title="Wap Upload File"><center><img src="/img/logo.png"/></center></a></div>
<div class="tp"><a href="/" rel="home" title="Upload file mobile">Home</a> | <a href="/upload/" rel="menu" title="Tai len tap tin">Upload</a> | <a href="/cat/?fs=1" rel="menu">Download</a> | <a href="/topfile.php" rel="menu">Top File</a></div>