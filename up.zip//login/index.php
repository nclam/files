<?php
@session_start();
include '../functions.php';
db_connect();
if($_COOKIE['login'] != '') {
	if(mysql_num_rows(mysql_query("SELECT * FROM users WHERE session='".$_COOKIE['login']."';")) != 0) {
		$arr = mysql_fetch_assoc(mysql_query("SELECT * FROM users WHERE session='".$_COOKIE['login']."';"));
		$_SESSION['login'] = $arr['login'];
		$_SESSION['my_id'] = $arr['id'];
		$_SESSION['sess'] = $_COOKIE['login'];
	}
}
if($_SESSION['sess'] != '') {
	set_tp('oO');
	echo 'Và bạn, và do đó có thẩm quyền, nơi nào bạn đi :)';
	db_close();
	include '../footer.php';
	exit;
}
if(isset($_POST['enter'])) {
	//db_connect();
	if(trim($_POST['login']) == '' || $_POST['pwd'] == '') {
		include '../header.php';
		set_tp('Đăng nhập');
		db_close();
		echo '<div class="body">Bạn đã nhập tất cả các dữ liệu.</div>';
		include '../footer.php';
		exit;
	}
	if(mysql_num_rows(mysql_query("SELECT * FROM users WHERE login='".mysql_escape_string($_POST['login'])."';")) == 0) {
		include '../header.php';
		set_tp('Đăng nhập');
		db_close();
		echo '<div class="body">Người này không được tìm thấy.</div>';
		include '../footer.php';
		exit;
	}
	$arr = mysql_fetch_assoc(mysql_query("SELECT * FROM users WHERE login='".mysql_escape_string($_POST['login'])."';"));
	if(md5($_POST['pwd']) != $arr['password']) {
		include '../header.php';
		db_close();
		set_tp('Đăng nhập');
		echo '<div class="body">Bạn đã nhập sai mật khẩu. Hãy thử lại.</div>';
		include '../footer.php';
		exit;
	} else {
		$session = md5(microtime().rand(0, 1111111));
		mysql_query("UPDATE users SET `session`='".$session."' WHERE id=".$arr['id'].";");
		$_SESSION['sess'] = $session;
		$_SESSION['login'] = $arr['login'];
		$_SESSION['my_id'] = $arr['id'];
		@session_destroy();
		if(isset($_POST['mem'])) setcookie('login', $session, time() + 60*60*24*365, '/');
		include '../header.php';
		set_tp('Đăng nhập');
		echo '<div class="body">Bạn đã đăng nhập thành công. Nhấn vào <a href="/index.php">đây</a> nếu trình duyệt không tự chuyển hướng';
		echo '<meta http-equiv="refresh" content="0; url=/index.php" />';
		echo '<div class="tp"><a href="../index.php">Trang chủ</a></div></div>';
		include '../footer.php';
		db_close();
		exit;
	}
}
include '../header.php';
set_tp('Nhập tên người dùng và mật khẩu của bạn hoặc <a href="register/">Đăng ký mới</a>');
echo '<div class="body">';
echo '<form action="index.php" method="post">';
echo 'Tên đăng nhập:<br/><input type="text" name="login" value="" /><br/>';
echo 'Mật khẩu:<br/><input type="password" name="pwd" value="" /><br/>';
echo '<input type="checkbox" name="mem" checked /> Nhớ mật khẩu<br/><input type="submit" value="Đăng nhập!" name="enter" />';
echo '</form></div>';
echo '<div class="tp"><a href="password/">Quên mật khẩu?</a></div>';
include '../footer.php';
?>