<?php

error_reporting(0);
@session_start();
include './functions.php';
db_connect();

if($_COOKIE['login'] != '') {
	if(mysql_num_rows(mysql_query("SELECT * FROM users WHERE session='".$_COOKIE['login']."';")) != 0) {
		$arr = mysql_fetch_assoc(mysql_query("SELECT * FROM users WHERE session='".$_COOKIE['login']."';"));
		$_SESSION['login'] = $arr['login'];
		$_SESSION['id'] = $arr['id'];
		$_SESSION['sess'] = $_COOKIE['login'];
		if($arr['level'] == -1) {
			include './header.php';
			echo 'Tài khoản của bạn đã bị cấm.';
			include './footer.php';
			db_close();
			exit;
		}
	}
}

include './header.php';

echo '<div class="tp">Top tập tin được tải nhiều nhất</div>';
if($_SESSION['sess'] != '') {
	$user_arr = mysql_fetch_assoc(mysql_query("SELECT * FROM `users` WHERE `id` = ".$_SESSION['my_id'].";"));
	$onpage = $user_arr['onpage'];
} else $onpage = 10;
if(($_POST['page']=(int)$_POST['page'])!='') $_GET['page'] = $_POST['page'];
$_GET['page'] = (int)$_GET['page'];
if($_GET['page'] < 1 || $_GET['page'] == '') $_GET['page'] = 1;
	$total = mysql_num_rows(mysql_query("SELECT * FROM `files`"));
if($total == 0) {
	echo 'Không tìm thấy tệp tin!';
	include './footer.php';
	db_close();
	exit;
}
//echo $total;
$tieude = "Top tập tin";
include 'tieude.php';
if(($_GET['page'] - 1) * $onpage > $total) $_GET['page'] = 1;
$first = ($_GET['page'] - 1) * $onpage;
$last = $_GET['page'] * $onpage;
if($last > $total) $last = $total;

for($i = $first; $i < $last; $i++) {

$file = mysql_fetch_assoc(mysql_query("SELECT * FROM `files` ORDER BY `load` DESC LIMIT $i,1;"));
$filename = str_replace('-',' ',htmlspecialchars(stripslashes($file['filename'])));
$filename = str_replace('_',' ',$filename);
include 'seo.php';

	echo '<div class="list">&raquo; <a href="/taptin-'.$file['id'].'.html">'.$filename.'</a> - '.$file['load'].' lượt tải (';
	$fsize = @filesize('./files/'.$file['path']);
	if($fsize < 1024) echo $fsize.' Bytes)</div>';
	 else echo round($fsize/1024, 1).'КB)</div>';
}
$pages = ceil($total/$onpage);
echo '<div class="filelist_paging">';
if($_GET['page'] > 1) echo '<a href="top.php?page='.($_GET['page']-1).'">&lt;&lt; Back</a> ';
if($_GET['page'] > 1 && $_GET['page'] < $pages) echo '|';
if($_GET['page'] < $pages) echo '<a href="top.php?page='.($_GET['page']+1).'">Next &gt;&gt;</a> ';

showTOP($pages);
echo '</div><div class="tp">';
echo '<a href="/upload">Upload</a> | <a href="./search.php">Search</a> | <a href="/index.php">Home</a>';
echo '</div>';
db_close();
include './footer.php';
?>