<?php
@session_start();
include 'functions.php';
db_connect();
/*if(wapOrWeb() == 0) {
	header("Location: web/index.php?".$_SERVER['QUERY_STRING']);
	exit;
}*/
//print_r($_COOKIE);
if($_COOKIE['login'] != '') {
//echo 'flag';
	if(mysql_num_rows(mysql_query("SELECT * FROM users WHERE session='".$_COOKIE['login']."';")) != 0) {
		$arr = mysql_fetch_assoc(mysql_query("SELECT * FROM users WHERE session='".$_COOKIE['login']."';"));
		$_SESSION['login'] = $arr['login'];
		$_SESSION['my_id'] = $arr['id'];
		$_SESSION['sess'] = $_COOKIE['login'];
		if($arr['level'] == -1) {
			include 'header.php';
			echo 'Tài khoản của bạn đã bị cấm.';
			include 'footer.php';
			db_close();
			exit;
		}
	}
}
if(isset($_GET['exit'])) {
	if($_SESSION['sess'] == '') {
		db_close();
		header('Location: index.php');
		exit;
	}
	mysql_query("UPDATE users SET session='' WHERE login='".mysql_escape_string($_SESSION['login'])."';");
	db_close();
	unset($_SESSION['sess']);
	unset($_SESSION['login']);
	unset($_SESSION['my_id']);
	setcookie('login', '');
	header('Location: index.php');
	@session_destroy();
	exit;
}
include 'header.php';
//print_r($_SESSION);
if(($_GET['id']=(int)$_GET['id'])!='') {
	if(mysql_num_rows(mysql_query("SELECT * FROM files WHERE id=".$_GET['id'])) == 0) {
		set_tp('Không tìm thấy file <404 error>');
		echo 'Tệp mà bạn định tải xuống không có thực. Cũng có thể là do bị người tải xuống hoặc admin xóa.';
		echo '<div class="tp"><a href="../search">Search</a> | <a href="../index.php">Home</a></div>';
		include 'footer.php';
		db_close();
		exit;
	}
	
	$file = mysql_fetch_assoc(mysql_query("SELECT * FROM files WHERE id=".$_GET['id'].";"));
	if($_SESSION['sess'] != '') $user_me = mysql_fetch_assoc(mysql_query("SELECT level FROM users WHERE id=".$_SESSION['my_id'].";"));
	if($_SESSION['sess'] != '') {
		$arr = mysql_fetch_assoc(mysql_query("SELECT * FROM users WHERE login='".mysql_escape_string($_SESSION['login'])."';"));
		$ui = $arr['id'];
	}
	if($file['user'] == $arr['id']) $this_is_mine = true;
$tieude = ' '.htmlspecialchars(stripslashes($file['filename'])).' ';
include 'tieude.php';

	set_tp('<img src="http://www.freeiconsweb.com/Icons/16x16_File_icons/Computer_File_053.gif">Tập tin «'.htmlspecialchars(stripslashes($file['filename'])).'»');
	
	if(isset($_GET['editpassword']) && ($this_is_mine || $user_me['level'] == 2)) {
		if(isset($_POST['go'])) {
			//if($_POST['pwd'] != '') $_POST['pwd'] = md5($_POST['pwd']);
			$_POST['price'] = (float)$_POST['price'];
			if(($_POST['price'] == '' || $_POST['price'] < 0) && $_POST['price'] != 0) $_POST['price'] = 0;
			if(mysql_query("UPDATE files SET `password`='".$_POST['pwd']."', `price`='".$_POST['price']."' WHERE id=".$_GET['id'].";"))
				echo 'Thông tin thay đổi thành công!';
			else echo mysql_error();
			db_close();
			include 'footer.php';
			exit;
		}
		echo '<form action="index.php?id='.$file['id'].'&editpassword" method="post">';
		echo 'Mật khẩu:<br/><input type="text" name="pwd" value="'.stripslashes($file['password']).'" /><br/>';
		echo 'Giá bán (0 - không mua bán):<br/><input type="text" name="price" value="'.$file['price'].'" /><br/>';
		echo '<input type="submit" value="Lưu!" name="go" /></form>';
		db_close();
		include 'footer.php';
		exit;
	}
	
	if(isset($_GET['editdesc']) && ($this_is_mine || $user_me['level'] == 2)) {
		if(isset($_POST['go'])) {
			if(mysql_query("UPDATE files SET `note`='".mysql_escape_string($_POST['desc'])."' WHERE id=".$_GET['id'].";"))
				echo 'Thông tin thay đổi thành công!';
			else echo mysql_error();
			db_close();
			include 'footer.php';
			exit;
		}
		echo '<form action="index.php?id='.$file['id'].'&editdesc" method="post">';
		echo 'Mô tả:<br/><input type="text" name="desc" value="'.stripslashes($file['note']).'" /><br/><input type="submit" value="Lưu!" name="go" /></form>';
		db_close();
		include 'footer.php';
		exit;
	}
	
	if(isset($_GET['deletefile']) && ($this_is_mine || $user_me['level'] == 2)) {
		if(mysql_query("DELETE FROM files WHERE id=".$file['id'].';')) {

function remove_directory($dir) {
if ($handle = opendir("$dir")) {
while (false !== ($item = readdir($handle))) {
if ($item != "." && $item != "..") {
if (is_dir("$dir/$item")) {
remove_directory("$dir/$item");
} else {
unlink("$dir/$item");
}
}
}
closedir($handle);
rmdir($dir);
}
}

			$dir_file = explode('/', getPath(stripslashes($file['path'])));
			remove_directory("files/".trim($dir_file[0]));
			echo 'Tập tin đã xóa thành công.';
		}
		else echo mysql_error();
		db_close();
		include 'footer.php';
		exit;
	}
	
	if(isset($_GET['addcomplaint']) && !$this_is_mine && $_SESSION['sess'] != '') {
		if(mysql_num_rows(mysql_query("SELECT * FROM complaints WHERE id=".$file['id']." AND user=".$_SESSION['my_id'].";")) > 0) {
			echo 'Bạn có một trái khiếu nại về tập tin này.';
			include 'footer.php';
			db_close();
			exit;
		}
		if(isset($_POST['go_c'])) {
			if(trim($_POST['comlttext']) == '') {
				echo 'Bạn không cần phải có văn bản khiếu nại!';
				include 'footer.php';
				db_close();
				exit;
			}
			mysql_query("INSERT INTO complaints VALUES(".$file['id'].", ".$_SESSION['my_id'].", '".mysql_escape_string($_POST['comlttext'])."', '".time()."', '".$_SERVER['REMOTE_ADDR']."', '".$_SERVER['HTTP_USER_AGENT']."');");
			echo 'khiếu nại đã được thêm vào tập tin.';
			include 'footer.php';
			db_close();
			exit;
		}
		echo '<form action="index.php?id='.$file['id'].'&addcomplaint" method="post">';
		echo 'Khiếu nại:<br/><textarea name="comlttext" cols="25" rows="4"></textarea><br/>';
		echo '<input type="submit" value="Báo cáo vi phạm!" name="go_c"></form>';
		include 'footer.php';
		db_close();
		exit;
	}
	
	if(isset($_POST['ok_ass'])) {
		if($_SESSION['sess'] != '' && $file['user'] != $_SESSION['my_id']) {
			if(in_array($_SESSION['my_id'], explode('|', $file['uvotes']))) {
				echo '<div class="body">Bạn đã bầu chọn cho các tập tin này.</div>';
				db_close();
				include 'footer.php';
				exit;
			}
			mysql_query("UPDATE files SET `votes`='".$file['votes'].(int)$_POST['a'].'|'."', `uvotes`='".$file['uvotes'].$_SESSION['my_id'].'|'."' WHERE id=".$file['id'].";") or die (mysql_error());
			echo '<div class="body">Phiếu bầu của bạn đã được bổ sung thành công.</div>';
		} else {
			echo '<div class="body"><font color="#ff0000">Bạn không thể bình chọn cho tập tin này.</font></div>';
		}
		db_close();
		include 'footer.php';
		exit;
	}
	
	if(isset($_GET['buy']) && $_SESSION['sess'] != '') {
		$user = mysql_fetch_assoc(mysql_query("SELECT * FROM users WHERE id=".$_SESSION['my_id'].";"));
		$setarr = mysql_fetch_assoc(mysql_query("SELECT * FROM settings;"));
		if(isset($_GET['yes'])) {
			if((float)$user['money'] < (float)$file['price']) {
				echo '<font color="#ff0000">Bạn không có đủ tiền để mua mật khẩu.</font>';
			} else {
				$m = (float)$file['price'] + (float)$file['price'] * ($setarr['commission'] / 100);
				mysql_query("UPDATE users SET `money`='".($user['money']-$m)."' WHERE id=".$_SESSION['my_id']);
				$user = mysql_fetch_assoc(mysql_query("SELECT * FROM users WHERE id=".$_SESSION['my_id'].";"));
				echo '<div class="body">';
				echo '<b>Mật khẩu</b> vào tập tin <i>'.htmlspecialchars(stripslashes($file['filename'])).'</i> :<br/><input type="text" value="'.stripslashes($file['password']).'" size="15" /><br/><br/>';
				echo '<b>Số dư trong ngân hàng: </b>'.$user['money'].' WD<br/>';
				echo '</div>';
				db_close();
				include 'footer.php';
				exit;
			}
		}
		echo '<div class="body"><b>Tiền: </b>'.$user['money'].' WD<br/>';
		echo '<b>Giá mật khẩu:</b> '.$file['price'].' WD<br/>';
		if((float)$user['money'] < (float)$file['price']) {
			echo '<font color="#ff0000">Bạn không có đủ tiền để mua mật khẩu.</font>';
		} else {
			echo '<br/>';
			echo 'Bạn có xác nhận mua hàng của mật khẩu cho tập tin <b>'.htmlspecialchars(stripslashes($file['filename'])).'</b>? Các Ủy Ban là '.$setarr['commission'].'%.<br/>';
			echo '<b>[<a href="index.php?id='.$file['id'].'&buy&yes" title="Tôi đồng ý(а)" >Có</a>] [<a href="index.php?id='.$file['id'].'"title="Không đồng ý">Không</a>]</b>';
		}
		echo '</div>';
		db_close();
		include 'footer.php';
		exit;
	}
	
	if($_POST['password'] == '' && $file['password'] != '' && !$this_is_mine && $user_me['level'] < 2) {
		echo '<div class="tpanel">Tập tin được bảo vệ bằng mật khẩu<br/></div>';
		echo '<div class="body">';
		if($file['price'] != 0 && $_SESSION['sess'] != '')
			echo 'Giá mật khẩu: '.$file['price'].' WD. <a href="index.php?id='.$file['id'].'&buy">Mua Mật khẩu</a><br/><br/>';
		echo 'Mật khẩu:<br/><form action="index.php?id='.$_GET['id'].'" method="post"><input type="password" value="" name="password" /><br/><input type="submit" value="OK" /></form></div>';
	} else {
		if($_POST['password'] != $file['password'] && $file['password'] != '' && !$this_is_mine && $user_me['level'] < 2) {
			echo '<div class="tpanel">Tập tin được bảo vệ bằng mật khẩu<br/></div>Mật khẩu không hợp lệ<br/>';
			echo '<a href="index.php?id='.$_GET['id'].'" >Thử lại</a>';
		} else {
			$_SESSION['load_'.$_GET['id']] = '777';
$extension = pathinfo($file['filename']);
		$ext = strtolower($extension['extension']);
//if($_SESSION['sess'] == '') {
//echo '<div class="glist"><form action="/login" method="post"><input
//type="submit" value="Mời đăng nhập"> ('.round(filesize('files/'.$file['path'])/1024, 1).'kb)</form></div>';
//include 'ad.php';}
//else {


if($ext == 'exe' OR $ext == 'bat' OR $ext == 'pif' OR $ext == 'msi'){
echo '<div class="list"><font color="red" size="2"><b>Chú ý:</b> Đây là file thực thi trên PC, tải về file này PC của bạn có thể bị nhiễm virus, trojan, keylogger,... Hãy cẩn thận đấy!</font></div>';}
			if($ext == 'zip' OR $ext == 'rar' OR $ext == '7z' OR $ext == 'sql.gz' OR $ext == 'gz' OR $ext == 'tar')
echo '<div class="list"><form method="post" action="http://wobzip.org" enctype="multipart/form-data"><input type="hidden" name="Upload[url]" value="http://x.s2vn.top/files/'.getPath(stripslashes($file['path'])).''.htmlspecialchars(stripslashes($file['filename'])).'" /> <b>Thao tác :</b><input type="submit" class="subm" name="yt0" value="Giải nén!" /> </div>';
			if($ext == 'jar') {
echo '<div class="list">'; include 'checkjar.php';
echo '</div><div class="list"><b>Convert : </b><a href="/jar_jad.php?id='.$file['id'].'">[Tải .jad]</a> - <a href="/jar_jad.php?file='.$file['id'].'">[Tải _jar]</a></div>'; 
}

  			if($ext == 'mp3' OR $ext == 'wav' OR $ext=='mid' OR $ext=='midi' OR $ext=='ogg' OR $ext=='ac3' ) {
			echo'<div class="list" style="text-align:center;"><audio controls><source src="'.$diachi.'/files/'.getPath(stripslashes($file['path'])).''.htmlspecialchars(stripslashes($file['filename'])).'" type="audio/mpeg"></audio></div>';
			}if($ext == 'mp4' OR $ext == '3gpp' OR $ext=='mpg' OR $ext=='mpeg' OR $ext=='avi' OR $ext=='flv' OR $ext=='3gp') {
			echo'<div class="list" style="text-align:center;"><video width="auto" height="auto" autoplay><source src="'.$diachi.'/files/'.getPath(stripslashes($file['path'])).''.htmlspecialchars(stripslashes($file['filename'])).'" type="video/mp4">Your browser does not support the video tag.</video></div> ';
			}if($file['img'] == 1) {
			echo '<div class="list" style="text-align:center;">';

				echo '<img border="0" alt="preview" src="files/'.getPath(stripslashes($file['path'])).'preview.'.str_replace('jpg', 'jpeg', getExt($file['filename'])).'" /></div>';
				$imgs = getimagesize('files/'.$file['path']);
			}
			if($user_me['level'] == 2 && $file['password'] != '') {
				echo '<div style="padding: 5px 5px 5px 5px; background-color: #ffdead;">IP: '.$file['ip'].'<br/>';
				echo 'User-Agent: '.htmlspecialchars(stripslashes($file['ua'])).'<br/>';
				echo 'Mật khẩu: '.htmlspecialchars(stripslashes($file['password'])).'</div>';
			}
			echo '<div class="list" style="text-align:center;"><br><a style="text-align:center;font-size:15px;background-color:red;color:#fff;padding:10px;border-radius: 6px;" href="download.php?id='.$_GET['id'].'">Tải xuống</a></div><div class="mpanel1">';
echo '<div class="tp">Thông tin</div>';
			if($file['img'] == 1)
				echo '<div class="list"><form action="/resize.php" method="get"><b>Ảnh:</b><input type="hidden" name="id" value="'.$_GET['id'].'" /><input type="text" name="w" size="2" value="'.$imgs[0].'"/>x<input type="text" name="h" size="2" value="'.$imgs[1].'"/><input type="submit" value="Resize"/></form></div>';
			echo '<div class="list"><b>Tải xuống</b>:  '.$file['load'].' lần</div><div class="list"><b>Mã số tập tin</b>: '.$file['id'].'</div><div class="list"><b>Ngày upload: </b> '.date('d.m.Y H:i:s', $file['time']).'</div>';
			if($file['lastloadtime'] != 0) echo '<div class="list"><b>Mới tải về: </b>'.date('d.m.Y H:i:s', $file['lastloadtime']).'</div>';
			if(trim($file['note']) != '')
				echo '<div class="list"><b>Mô tả:</b><br/>'.htmlspecialchars(stripslashes($file['note'])).'</div>';
			if($file['user'] != 0) {
				$arr = mysql_fetch_assoc(mysql_query("SELECT * FROM users WHERE id=".$file['user'].';'));
				echo '<div class="list"><b>Upload bởi: </b><a href="profile.php?id='.$arr['id'].'">'.htmlspecialchars(stripslashes($arr['login'])).'</a></div>';
			}
			if($file['user'] != $_SESSION['my_id'] && $_SESSION['sess'] != '') {
				if(!in_array($_SESSION['my_id'], explode('|', $file['uvotes']))) {
					echo '<div class="list"><b>Đánh giá:</b><br/>';
					echo '<form action="index.php?id='.$file['id'].'&" method="post"><input type="radio" name="a" value="1" />1<input type="radio" name="a" value="2" />2<input type="radio" name="a" value="3" />3<input type="radio" name="a" value="4" />4<input type="radio" name="a" value="5" checked />5<br/><input type="submit" value="OK" name="ok_ass" /></form>';
				}
			}
			$votes = explode('|', $file['votes']);
			$count = 0;
			$sum = 0;
			for($i = 0; $i < sizeof($votes); $i++) {
				if($votes[$i] == '') continue;
				$sum += (int)$votes[$i];
				$count++;
			}
			if($count > 0) $middle = round($sum / $count, 2);
				else $middle = 0;
			echo '<div class="list"><b>Đánh giá: </b>'.$middle.' (lượt: '.$count.')</div></div>';
			echo '</div>';
			echo '<div class="list">»<a href="comments.php?id='.$file['id'].'">Bình luận ('.mysql_num_rows(mysql_query("SELECT * FROM comments WHERE file=".$file['id'].';')).')</a></div>';



//mem file
/*
if($file['user'] != 0) {
echo '<div class="tp"><b>Các tập tin khác của '.htmlspecialchars(stripslashes($arr['login'])).':</b></div><div class="list">';
$memfile = mysql_num_rows(mysql_query("SELECT * FROM files WHERE user=".$arr['id'].";"));
 if($memfile > 10) $memfile = 10;
     for($i = 0; $i < $total; $i++) {
	$memfile1 = mysql_fetch_assoc(mysql_query("SELECT * FROM files ORDER BY time DESC LIMIT ".$i.',1;'));

echo $memfile1;
}*/

//mem file
echo '<div class="tp">Chia sẻ tập tin</div><div class="list" style="text-align:center;"><span class="row more">
<label>
<!-- Facebook -->
<a href="http://www.facebook.com/sharer.php?u='.$diachi.'/'.$_GET['id'].'" target="_blank" title="share facebook"><img src="http://nam.name.vn/publics/images/facebook.png" alt="faceboook"></a>

<!-- Twitter -->
<a href="http://twitter.com/share?url='.$diachi.'/'.$_GET['id'].'&text=Simple Share Buttons" target="_blank" title="share twitter"><img src="http://nam.name.vn/publics/images/twitter.png" alt="twitter"></a>

<!-- Google+ -->
<a href="https://plus.google.com/share?url='.$diachi.'/'.$_GET['id'].'" target="_blank" title="share google plus"><img src="http://nam.name.vn/publics/images/google.png" alt="google"></a></label> 
</span></div>';
			echo '<div class="list">URL: <br><input type="text" value="'.$diachi.'/'.$_GET['id'].'" size="30"/></div>';
			echo '<div class="list">Link trực tiếp: <br><input type="text" value="'.$diachi.'/files/'.getPath(stripslashes($file['path'])).''.htmlspecialchars(stripslashes($file['filename'])).'" size="30"/></div>';
			if($file['img'] == 1)
			echo '<div class="list">Nhúng hình vô 4rum: <br><input type="text" value="[URL='.$diachi.'/'.$_GET['id'].'][IMG]'.$diachi.'/files/'.getPath(stripslashes($file['path'])).''.htmlspecialchars(stripslashes($file['filename'])).'[/IMG][/URL]" size="30"/></div>';
			echo '<div class="list">Mã nhúng BBCODE: <br><input type="text" value="[URL='.$diachi.'/'.$_GET['id'].']Tải xuống '.htmlspecialchars(stripslashes($file['filename'])).' ('.round(filesize('files/'.$file['path'])/1024, 1).'kb)[/URL]" size="30"/></div>';
			echo '<div class="list">Mã nhúng HTML: <br><input type="text" value="&lt;a href=&quot;'.$diachi.'/'.$_GET['id'].'&quot;&gt;Tải xuống '.htmlspecialchars(stripslashes($file['filename'])).' ('.round(filesize('files/'.$file['path'])/1024, 1).'kb)&lt;/a&gt;" size="30"/></div>';

//y kien
			if($this_is_mine || $user_me['level'] == 2) {
                                echo '<div class="tp">Bảng điều khiển</div>';
				echo '<div class="list">»<a href="index.php?id='.$file['id'].'&editpassword">Đổi mật khẩu</a></div>';
				echo '<div class="list">»<a href="index.php?id='.$file['id'].'&editdesc">Sửa Mô tả</a></div>';
				echo '<div class="list">»<a href="index.php?id='.$file['id'].'&deletefile">Xóa file</a></div>';
			}
			$compls = mysql_num_rows(mysql_query("SELECT * FROM complaints WHERE id=".$file['id'].";"));
			if(!$this_is_mine && $user_me['level'] != 2 && $_SESSION['sess'] != '') echo '<div class="list">»<a href="index.php?id='.$_GET['id'].'&addcomplaint">Báo cáo tập tin vi phạm</a></div>';
			if($user_me['level'] == 2) echo '<div class="list">»<a href="admin.php?mode=complaints&id='.$file['id'].'">Khiếu nại: <b>'.$compls.'</b></a></div>';
			else echo '<div class="list">»Khiếu nại: <b>'.$compls.'</b></div>';
		}
	}
	echo '<div class="tp"><a href="upload">Upload</a> | <a href="index.php">Home</a></div>';
	db_close();
	include 'footer.php';
	exit;
}


	$setarr = mysql_fetch_assoc(mysql_query("SELECT * FROM settings;"));
$tieude = "Trang chủ";
include 'tieude.php';
if($_SESSION['sess'] == '') {
echo '<div class="tp">Chào bạn <a href="office/">'.htmlspecialchars($_SESSION['login']).'</a>! Chúc bạn 1 ngày vui vẻ!</div>';
echo '<div class="tp">Upload nhanh</div><div class="glist">[<a href="login/" title="Login">Đăng nhập</a>] hoặc ';
	echo '[<a href="login/register/">Đăng ký</a>] để sử dụng đầy đủ chức năng của X.S2vn.Top</div><div class="list"><h1>Wap upload tập tin<h1> <h2>Upload và chia sẻ tập tin nhanh nhất miễn phí</h2> Chọn file muốn <b>upload</b> hoặc chia sẻ và nhấn vào upload, bạn có thể thêm mô tả của tập tin và cài mật khẩu cho file, <b>wap upload</b> x.s2vn.top hỗ trợ upload nhiều định dạng khác nhau từ game, dụng cho tới nhạc, video và file nén. <br/><font color=blue>"Bạn có thể Uploads file _jar hoặc .jar1, Hệ thống của chúng tôi sẽ giúp bạn chuyển sang .jar"</font></div>';
	echo '<div class="list"><form action="/upload/index.php" method="post" enctype="multipart/form-data"><!--<input type="radio" name="fileupl" value="f" id="fuid" type="hidden" checked><label for="fuid">Từ máy:</label>-->File: <input type="file" name="file" /><br/>Captcha: <input type="text" value="" name="seccode" /><img src="/upload/img.php" alt="code" border="0" /><br><input type="submit" name="send" value="Upload!" /></form></div>';
         } else {
	$_user_array = mysql_fetch_assoc(mysql_query("SELECT * FROM users WHERE id=".$_SESSION['my_id'].';'));
	echo '<div class="tp">Chào <a href="office/">'.htmlspecialchars($_SESSION['login']).'</a> - <a href="/index.php?exit">Đăng xuất</a></div><div class="glist" style="text-align: justify;">Tiền: '.$arr['money'].'$<br>»<a href="/office/file.php">File</a> | <a href="/profile.php">Profile</a> | <a href="/privat.php">PM</a> '.mysql_num_rows(mysql_query("SELECT * FROM `privmsg` WHERE `to`=".$_SESSION['my_id']." AND (`status`=0 OR `status`=1);")).'/'.mysql_num_rows(mysql_query("SELECT * FROM `privmsg` WHERE `to`=".$_SESSION['my_id']." AND (`status`=0 OR `status`=1 OR `status`=2);")).'';
	if($_user_array['level'] == 2)
		echo ' | <a href="admin.php">Admin</a>';

echo'</div></div>';
	echo '<div class="tp">Upload nhanh (<font color="red"><b>Max '.$setarr['maxfile'].'Mb</b></font>)</div><form action="/upload/index.php" method="post" enctype="multipart/form-data"><div class="list"><input type="radio" name="fileupl" value="f" id="fuid" checked><label for="fuid">Từ máy:</label><br/><input type="file" name="file" /></div><div class="list"><input type="radio" name="fileupl" value="u" id="uuid"><label for="uuid">Từ URL:</label><br/><input type="text" name="url" value="http://" /></div><div class="list"><input type="submit" name="send" value="Upload!" /></form></div>'; }

$today = mktime(0, 0, 0, (int)date('m'), (int)date('d'), (int)date('Y'));
echo '<div class="tp">Tệp tin mới (<b>+<font color="red">'.mysql_num_rows(mysql_query("SELECT * FROM files WHERE time>".$today.";")).'</font></b>)</div>';
     $total = mysql_num_rows(mysql_query("SELECT * FROM files;"));
     if($total > 20) $total = 20;
     for($i = 0; $i < $total; $i++) {
	$arr = mysql_fetch_assoc(mysql_query("SELECT * FROM files ORDER BY time DESC LIMIT ".$i.',1;'));

echo '<div class="list">';
include 'seo.php';

echo '»<a href="/taptin-'.$arr['id'].'.html">'.htmlspecialchars(stripslashes($arr['filename'])).'</a></div>';
include "log.php";
     }

echo ' ';
echo '<div class="tp"><a href="search/">Tìm kiếm tập tin</a></div><div class="list"><form action="/search/index.php?query=$query" method="get">Tìm kiếm : <input type="text" name="query" value="" size="8"/><input type="submit" value="Tìm!" /></form></div>';
echo'<div class="tp">Tìm theo ID</div><div class="list">Đến nhanh trang download file qua Mã số tập tin!<br/><form action="/index.php" method="get">ID:<input type="number" name="id" maxlength="4" value="" size="4"/><input type="submit" value="Tìm" /></form></div>';
echo '<!--Giup do-->';
echo '<div class="tp"><a href="/help/">Giúp đỡ</a></div>';
echo '<div class="list"><a href="help/?t=gen">Thông tin</a> | ';
echo '<a href="help/terms/">Nội quy</a></div><div/>';

echo '</div>';
$today = mktime(0, 0, 0, (int)date('m'), (int)date('d'), (int)date('Y'));
//echo $today;
//echo ' '.date('d.m.Y H i s');

$path="./files/"; 
$ar=getDirectorySize($path); 

echo '<div class="tp">Thống kê</div><div class="list">
Tổng số tập tin: <b>'.mysql_num_rows(mysql_query("SELECT * FROM files;")).'</b></div>';

INCLUDE 'calculate.directory.class.php';
$directory = './files/'; 
$size_in = 'MB';
$decimals = 2;
$directory_size = NEW Directory_Calculator;
$directory_size->size_in = $size_in;
$directory_size->decimals = $decimals;
$array = $directory_size->size($directory); 

echo "<div class=\"list\">Tổng dung lượng: <b>".$array['size']." ".$size_in."</b></div>"; 
echo '<div class="list">Đăng hôm nay: <b>'.mysql_num_rows(mysql_query("SELECT * FROM files WHERE time>".$today.";")).'</b></div>
<div class="list">Số thành viên: <b><a href="member.php">'.mysql_num_rows(mysql_query("SELECT * FROM users;")).'</a></b></div>
';






/* Code nay de xem xem la co bao nhieu ng ol tai wap ban */
/*by tranxuanthang */

        $data="online.dat";
        $time=time();
        $past_time=time()-600;

        $readdata=fopen($data,"r") or die("Không thể mở file $data , bạn cần tạo 1 file $data lên máy chủ.");
        $data_array=file($data);
        fclose($readdata);

        if (getenv('HTTP_X_FORWARDED_FOR'))
               $user = getenv('HTTP_X_FORWARDED_FOR');
        else
             $user = getenv('REMOTE_ADDR');

        $d=count($data_array);
        for($i=0;$i<$d;$i++)
                {
               list($live_user,$last_time)=explode("::","$data_array[$i]");
               if($live_user!=""&&$last_time!=""):
               if($last_time<$past_time):
                        $live_user="";
                        $last_time="";
                endif;
                if($live_user!=""&&$last_time!="")
                        {
                        if($user==$live_user)
                                {
                                $online_array[]="$user::$time\r\n";
                                }
                        else
                                $online_array[]="$live_user::$last_time";
                        }
                endif;
                }

        if(isset($online_array)):
        foreach($online_array as $i=>$str)
                {
                if($str=="$user::$time\r\n")
                        {
                        $ok=$i;
                        break;
                        }
                }
        foreach($online_array as $j=>$str)
                {
                if($ok==$j) { $online_array[$ok]="$user::$time\r\n"; break;}
                }
       endif;

        $writedata=fopen($data,"w") or die("Không thể viết lên file $data , yêu cầu chmod $data thành 777");
        flock($writedata,2);
        if($online_array=="") $online_array[]="$user::$time\r\n";
        foreach($online_array as $str)
                fputs($writedata,"$str");
        flock($writedata,3);
        fclose($writedata);

        $readdata=fopen($data,"r") or die("Không thể đọc file $data , bạn phải chmod $data thành 777");
        $data_array=file($data);
        fclose($readdata);
        $online=count($data_array);
echo '<div class="list">';
        echo "Trực tuyến: <b>$online</b> bạn";
//het ol
echo '</div></div>';




echo '</div>';
db_close();
include 'footer.php';
?>