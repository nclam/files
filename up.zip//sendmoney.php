<?php
@session_start();
include 'functions.php';
db_connect();
if($_COOKIE['login'] != '') {
	if(mysql_num_rows(mysql_query("SELECT * FROM users WHERE session='".$_COOKIE['login']."';")) != 0) {
		$arr = mysql_fetch_assoc(mysql_query("SELECT * FROM users WHERE session='".$_COOKIE['login']."';"));
		$_SESSION['login'] = $arr['login'];
		$_SESSION['my_id'] = $arr['id'];
		$_SESSION['sess'] = $_COOKIE['login'];
		if($arr['level'] == -1) {
			include 'header.php';
			echo 'Tài khoản của bạn đã bị cấm.';
			include 'footer.php';
			db_close();
			exit;
		}
	}
}

include 'header.php';

if($_SESSION['sess'] == '') {
	set_tp('Bạn không được phép!');
	echo '<div class="body">Bạn không được phép. <a href="login/index.php">Đăng nhập</a> hoặc <a href="login/register/">Đăng ký</a>.</div>';
	db_close();
	include 'footer.php';
	exit;
}

$_GET['to'] = (int)$_GET['to'];

if($_GET['to'] == '' || mysql_num_rows(mysql_query("SELECT * FROM users WHERE id=".$_GET['to'].";")) == 0) {
	set_tp('Lỗi!');
	echo '<div class="body">ID người dùng không hợp lệ.</div>';
	db_close();
	include 'footer.php';
	exit;
}
$userto = mysql_fetch_assoc(mysql_query("SELECT * FROM users WHERE id=".$_GET['to'].';'));
$me = mysql_fetch_assoc(mysql_query("SELECT * FROM users WHERE id=".$_SESSION['my_id'].";"));
$settings_array = mysql_fetch_assoc(mysql_query("SELECT * FROM settings;"));
if($me['money'] <= 0) {
	set_tp('Lỗi!');
	echo '<div class="body">Bạn không có đủ tiền.</div>';
	db_close();
	include 'footer.php';
	exit;
}

set_tp('Gửi tiền');
if(isset($_POST['send'])) {
	$_POST['how_many'] = (float)$_POST['how_many'];
	if($_POST['how_many'] == '' || $_POST['how_many'] <= 0) {
		echo '<div class="body">';
		echo 'Bạn chưa nhập hoặc nhập một giá trị không đúng.</div>';
		db_close();
		include 'footer.php';
		exit;
	}
	
	$hm = round($_POST['how_many'] + ($_POST['how_many'] * ($settings_array['commission'] / 100)), 3);
	$hm_w = round((float)$_POST['how_many'], 3);
	if($hm > $me['money']) {
		echo '<div class="body">Thiếu tiền trong tài khoản.<br/>';
		echo 'Bạn phải có: '.$hm.' WD<br/>Trên tài khoản: '.$me['money'].' WD<br/></div>';
		include 'footer.php';
		db_close();
		exit;
	}
	
	$to_user = mysql_fetch_assoc(mysql_query("SELECT * FROM users WHERE id=".$_GET['to'].";"));
	$me_user = mysql_fetch_assoc(mysql_query("SELECT * FROM users WHERE id=".$_SESSION['my_id'].";"));
	
	mysql_query("UPDATE users SET `money`='".($me_user['money']-$hm)."' WHERE id=".$_SESSION['my_id'].";");
	mysql_query("UPDATE users SET `money`='".($to_user['money']+$hm_w)."' WHERE id=".$_GET['to'].";");
	
	$me_user = mysql_fetch_assoc(mysql_query("SELECT * FROM users WHERE id=".$_SESSION['my_id'].";"));
	
	echo 'Chuyển '.$hm_w.' WD thành viên '.htmlspecialchars(stripslashes($to_user['login'])).'thực hiện thành công. Còn lại trong tài khoản : '.$me_user['money'].'<br/>';
	include 'footer.php';
	db_close();
	exit;
}
echo '<div class="body">';
echo '<b>Tiền ngân hàng: </b>'.$me['money'].' WD<br/>';
echo '<b>Tới: </b>'.htmlspecialchars(stripslashes($userto['login'])).'<br/>';
echo '<b>Số lượng</b> (Ủy Ban: '.$settings_array['commission'].'%):<br/>';
echo '<form action="sendmoney.php?to='.$_GET['to'].'" method="post">';
echo '<input type="text" name="how_many" size="10" /><br/><input type="submit" value="Gửi!" name="send" /></form>';
echo '</div>';

include 'footer.php';
db_close();
?>