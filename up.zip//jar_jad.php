<?php
include 'functions.php';


if ($_GET['file']){
$_GET['file'] = (int)$_GET['file'];
if($_GET['file'] == '' || $_GET['file'] == '') exit;
db_connect();
if(mysql_num_rows(mysql_query("SELECT * FROM files WHERE id=".$_GET['file'].';')) == 0) {
 db_close();
 exit;
}
$file = mysql_fetch_assoc(mysql_query("SELECT * FROM files WHERE id=".$_GET['file'].';'));
$file_dir = 'files/';
$taptin = $file_dir.$file['path'];
$fp = fopen($taptin, "rb");
$size = filesize($taptin);
header('Content-type:application/octet-stream');
$namez = str_replace('.jar', '_jar', $file['filename']);
header('Content-disposition: attachment;filename="'.$namez.'"');
header('Content-length: '.$size);
fpassthru($fp);
fclose($fp);
}elseif($_GET['id']){
$_GET['id'] = (int)$_GET['id'];
if($_GET['id'] == '' || $_GET['id'] == '') exit;
db_connect();
if(mysql_num_rows(mysql_query("SELECT * FROM files WHERE id=".$_GET['id'].';')) == 0) {
 db_close();
 exit;
}
$file = mysql_fetch_assoc(mysql_query("SELECT * FROM files WHERE id=".$_GET['id'].';'));
		header("content-type:text/vnd.sun.j2me.app-descriptor;charset=utf-8");
                header("Content-Disposition: attachment; filename=\"file.jad\"");
		$url='files/'.$file['path'];
		$url2='http://x.s2vn.top/'.$url;
		$fsize = filesize($url);
		$fileget = 'META-INF/MANIFEST.MF';
		$zip = new ZipArchive;
		$newline="MIDlet-Jar-Size: ".$fsize."\nMIDlet-Jar-URL: ".$url2."";
		if ($zip->open($url)===TRUE) {
			$oldfile = $zip->getFromName($fileget);
			$oldfile=$newline."\n".$oldfile; 
			echo ''.$oldfile.'';
		}
}
?>