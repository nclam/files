<?php
@session_start();
include '../functions.php';
db_connect();
if($_COOKIE['login'] != '') {
	if(mysql_num_rows(mysql_query("SELECT * FROM users WHERE session='".$_COOKIE['login']."';")) != 0) {
		$arr = mysql_fetch_assoc(mysql_query("SELECT * FROM users WHERE session='".$_COOKIE['login']."';"));
		$_SESSION['login'] = $arr['login'];
		$_SESSION['my_id'] = $arr['id'];
		$_SESSION['sess'] = $_COOKIE['login'];
		if($arr['level'] == -1) {
			include '../header.php';
			echo 'Tài khoản của bạn đã bị cấm.';
			include '../footer.php';
			db_close();
			exit;
		}
	}
}
include '../header.php';

if($_SESSION['sess'] == '') {
	set_tp('Bạn không được phép!');
	echo '<div class="body">Bạn không được phép. <a href="../login/index.php">Dăng nhập</a> hoặc <a href="../login/register/">Đăng ký</a>.</div>';
	db_close();
	include '../footer.php';
	exit;
}

set_tp('Tập tin của tôi');

echo <<< END
<div class="tpanel"><form action="file.php" method="get">
<div>Loại: 
<select name="ft">
<option value="0">Tất cả</option>
<option value="1">MP3</option>
<option value="2">Hình ảnh</option>
<option value="3">3GP</option>
<option value="4">Ứng dụng</option>
<option value="5">Văn bản</option>
<option value="6">Zip,Rar</option>
</select><input type="submit" value="Chọn" />
</div></form>
</div>
<div class="list">
END;

if($_SESSION['sess'] != '') {
	$user_arr = mysql_fetch_assoc(mysql_query("SELECT * FROM users WHERE id=".$_SESSION['my_id'].";"));
	$onpage = $user_arr['onpage'];
} else $onpage = 10;

if(($_POST['page']=(int)$_POST['page'])!='') $_GET['page'] = $_POST['page'];
$_GET['page'] = (int)$_GET['page'];
$_GET['ft'] = (int)$_GET['ft'];
$_GET['fs'] = (int)$_GET['fs'];
if($_GET['page'] < 1 || $_GET['page'] == '') $_GET['page'] = 1;
$arr = mysql_fetch_assoc(mysql_query("SELECT * FROM users WHERE login='".mysql_escape_string($_SESSION['login'])."';"));
$userid = $arr['id'];
echo 'Tổng số tập tin: <b>'.mysql_num_rows(mysql_query("SELECT * FROM files WHERE user=".$userid.";")).'</b></div>';
switch($_GET['ft']) {
case 0:
	$total = mysql_num_rows(mysql_query("SELECT * FROM files WHERE user=".$userid.";"));
	break;
case 1:
	$total = mysql_num_rows(mysql_query("SELECT * FROM files WHERE user=".$userid." AND (filename LIKE '%.mp3' OR filename LIKE '%.wav' OR filename LIKE '%.amr' OR filename LIKE '%.mid%');"));
	break;
case 2:
	$total = mysql_num_rows(mysql_query("SELECT * FROM files WHERE user=".$userid." AND (filename LIKE '%.jpg' OR filename LIKE '%.gif' OR filename LIKE '%.png' OR filename LIKE '%.bmp' OR filename LIKE '%.svg' OR filename LIKE '%.jpeg');"));
	break;
case 3:
	$total = mysql_num_rows(mysql_query("SELECT * FROM files WHERE user=".$userid." AND (filename LIKE '%.3gp' OR filename LIKE '%.avi' OR filename LIKE '%.mp4' OR filename LIKE '%.mpg');"));
	break;
case 4:
	$total = mysql_num_rows(mysql_query("SELECT * FROM files WHERE user=".$userid." AND (filename LIKE '%.jad' OR filename LIKE '%.jar' OR filename LIKE '%.sis' OR filename LIKE '%.exe');"));
	break;
case 5:
	$total = mysql_num_rows(mysql_query("SELECT * FROM files WHERE user=".$userid." AND (filename LIKE '%.doc' OR filename LIKE '%.txt' OR filename LIKE '%.odt');"));
	break;
case 6:
	$total = mysql_num_rows(mysql_query("SELECT * FROM files WHERE user=".$userid." AND (filename LIKE '%.zip' OR filename LIKE '%.rar' OR filename LIKE '%.7z' OR filename LIKE '%.tar%');"));
	break;
default:
	break;
}
if($total == 0) {
	echo 'Không tìm thấy tệp tin.';
	echo '</div><div class="btm">[<a href="../index.php">Trang chủ</a>]</div>';
	include '../footer.php';
	db_close();
	exit;
}
//echo $total;
if(($_GET['page'] - 1) * $onpage > $total) $_GET['page'] = 1;
$first = ($_GET['page'] - 1) * $onpage;
$last = $_GET['page'] * $onpage;
if($last > $total) $last = $total;

for($i = $first; $i < $last; $i++) {
	switch($_GET['ft']) {
	case 0:
		$file = mysql_fetch_assoc(mysql_query("SELECT * FROM files WHERE user=".$userid." ORDER BY id DESC LIMIT $i,1;"));
		break;
	case 1:
		$file = mysql_fetch_assoc(mysql_query("SELECT * FROM files WHERE user=".$userid." AND (filename LIKE '%.mp3' OR filename LIKE '%.wav' OR filename LIKE '%.amr' OR filename LIKE '%.mid%') ORDER BY id DESC LIMIT $i,1;"));
		break;
	case 2:
		$file = mysql_fetch_assoc(mysql_query("SELECT * FROM files WHERE user=".$userid." AND (filename LIKE '%.jpg' OR filename LIKE '%.gif' OR filename LIKE '%.png' OR filename LIKE '%.bmp' OR filename LIKE '%.svg' OR filename LIKE '%.jpeg') ORDER BY id DESC LIMIT $i,1;"));
		break;
	case 3:
		$file = mysql_fetch_assoc(mysql_query("SELECT * FROM files WHERE user=".$userid." AND (filename LIKE '%.3gp' OR filename LIKE '%.avi' OR filename LIKE '%.mp4' OR filename LIKE '%.mpg') ORDER BY id DESC LIMIT $i,1"));
		break;
	case 4:
		$file = mysql_fetch_assoc(mysql_query("SELECT * FROM files WHERE user=".$userid." AND (filename LIKE '%.jad' OR filename LIKE '%.jar' OR filename LIKE '%.sis' OR filename LIKE '%.exe') ORDER BY id DESC LIMIT $i,1"));
		break;
	case 5:
		$file = mysql_fetch_assoc(mysql_query("SELECT * FROM files WHERE user=".$userid." AND (filename LIKE '%.doc' OR filename LIKE '%.txt' OR filename LIKE '%.odt') ORDER BY id DESC LIMIT $i,1"));
		break;
	case 6:
		$file = mysql_fetch_assoc(mysql_query("SELECT * FROM files WHERE user=".$userid." AND (filename LIKE '%.zip' OR filename LIKE '%.rar' OR filename LIKE '%.7z' OR filename LIKE '%.tar%') ORDER BY id DESC LIMIT $i,1"));
		break;
	default:
		break;

	}
	echo '<div class="list"> • <a href="../index.php?id='.stripslashes($file['id']).'">'.htmlspecialchars(stripslashes($file['filename'])).'</a> (';
	$fsize = @filesize('../files/'.stripslashes($file['path']));
	if($fsize < 1024) echo $fsize.' Bytes)</div>';
	 else echo round($fsize/1024, 1).'Кb)</div>';
}
$pages = ceil($total/$onpage);
echo '</div><div class="filelist_paging">';
if($_GET['page'] > 1) echo '<a href="file.php?page='.($_GET['page']-1).'&ft='.$_GET['ft'].'">&lt;Trước.</a>';
if($_GET['page'] > 1 && $_GET['page'] < $pages) echo '|';
if($_GET['page'] < $pages) echo '<a href="file.php?page='.($_GET['page']+1).'&ft='.$_GET['ft'].'">Tiếp.&gt;</a>';
showLPF($pages, '&ft='.$_GET['ft']);
echo '</div></div><div class="btm">';
echo '[<a href="../search/">Tìm kiếm</a>]';
echo '[<a href="../index.php">Trang chủ</a>]';
echo '</div>';


db_close();
include '../footer.php';
?>