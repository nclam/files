<?php
@session_start();
include '../functions.php';
db_connect();
if($_COOKIE['login'] != '') {
	if(mysql_num_rows(mysql_query("SELECT * FROM users WHERE session='".$_COOKIE['login']."';")) != 0) {
		$arr = mysql_fetch_assoc(mysql_query("SELECT * FROM users WHERE session='".$_COOKIE['login']."';"));
		$_SESSION['login'] = $arr['login'];
		$_SESSION['my_id'] = $arr['id'];
		$_SESSION['sess'] = $_COOKIE['login'];
		if($arr['level'] == -1) {
			include '../header.php';
			echo 'Tài khoản của bạn đã bị cấm.';
			include '../footer.php';
			db_close();
			exit;
		}
	}
}

include '../header.php';

if($_SESSION['sess'] == '') {
	set_tp('Bạn không được phép!');
	echo '<div class="body">Bạn không được phép. <a href="../login/index.php">Đăng nhập</a> hoặc <a href="../login/register/">Đăng ký</a>.</div>';
	db_close();
	include '../footer.php';
	exit;
}

set_tp('Tài khoản của tôi');

$arr = mysql_fetch_assoc(mysql_query("SELECT * FROM users WHERE id=".$_SESSION['my_id'].';'));

echo '<div class="tpanel"><b>[<a href="../upload/">Upload</a>]</b></div>';
echo '<div class="body">';
echo '<b>Ngân hàng:</b> '.trim(nl2br($arr['money'])).' WD<br/>';
echo '<b>Bạn tải:</b> '.trim(nl2br($arr['uploaded'])).' Мб<br/>';
echo '<b>Phạm vi cho tập tin:</b> '.trim(nl2br($arr['quota'])).' MB <a href="/office/settings.php?mode=buy_quota">[Cài đặt]</a><br/><br/>';
echo '<a href="file.php">Tập tin của tôi<br/>';
echo '<a href="../profile.php">Hồ Sơ</a><br/>';
echo '<a href="../privat.php">Tin nhắn riêng</a><br/>';
echo '<a href="../cat/">Danh mục</a><br/>';
echo '<a href="../search/">Tìn kiếm</a><br/></div>';
//echo '<div class="mpanel"><a href="settings.php">Cài đặt Admin</a></div>';
echo '<div class="btm">';
echo '[<a href="../index.php">Trang chủ</a>]';
echo '[<a href="../help/">Giúp đỡ</a>]';
echo '[<a href="../index.php?exit">Thoát</a>]';
echo '</div>';
echo '</div>';

include '../footer.php';
?>