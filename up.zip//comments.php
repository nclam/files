<?php
@session_start();
include 'functions.php';
db_connect();
if($_COOKIE['login'] != '') {
	if(mysql_num_rows(mysql_query("SELECT * FROM users WHERE session='".$_COOKIE['login']."';")) != 0) {
		$arr = mysql_fetch_assoc(mysql_query("SELECT * FROM users WHERE session='".$_COOKIE['login']."';"));
		$_SESSION['login'] = $arr['login'];
		$_SESSION['my_id'] = $arr['id'];
		$_SESSION['sess'] = $_COOKIE['login'];
		if($arr['level'] == -1) {
			include 'header.php';
			echo 'Tài khoản của bạn đã bị cấm.';
			include 'footer.php';
			db_close();
			exit;
		}
	}
}
include 'header.php';
$_GET['id'] = (int)$_GET['id'];
if(mysql_num_rows(mysql_query("SELECT * FROM files WHERE id='".$_GET['id']."';")) == 0) {
	set_tp('Lỗi');
	echo '<div class="body">Tệp ID không hợp lệ.</div>';
	include 'footer.php';
	db_close();
	exit;
}
$file_info = mysql_fetch_assoc(mysql_query("SELECT * FROM files WHERE id=".$_GET['id'].";"));
set_tp('Các ý kiến: '.htmlspecialchars(stripslashes($file_info['filename'])));
if(isset($_POST['add'])) {
	if($_SESSION['sess'] == '') {
		echo '<div class="body">Chỉ <a href="login/">Đăng nhập</a> người dùng mới có thể để lại ý kiến!</div>';
		include 'footer.php';
		db_close();
		exit;
	}
	if(trim($_POST['comtext']) == '') {
		echo '<div class="body">Bạn chưa nhập văn bản.<br/><a href="comments.php?id='.$_GET['id'].'">Làm lại</a></div>';
		db_close();
		include 'footer.php';
		exit;
	}
	$tmp = mysql_fetch_assoc(mysql_query("SELECT MAX(id) FROM comments WHERE file=".$_GET['id'].";"));
	mysql_query("INSERT INTO comments VALUES(".($tmp["MAX(id)"]+1).", ".$_GET['id'].", ".$_SESSION['my_id'].", '".trim(mysql_real_escape_string($_POST['comtext']))."', ".time().", '".$_SERVER['REMOTE_ADDR']."', '".$_SERVER['HTTP_USER_AGENT']."');") or die(mysql_error());
	echo '<div class="body">Ý kiến được thêm vào thành công.<br/><a href="comments.php?id='.$_GET['id'].'">Quay lại để xem ý kiến</a></div>';
	db_close();
	include 'footer.php';
	exit;
}
$total = mysql_num_rows(mysql_query("SELECT * FROM comments WHERE file=".$_GET['id'].";"));
if($total == 0) {
	echo '<div class="body">Các ý kiến không có.</div>';
} else {
	echo '<div class="body">';
	for($i = 0; $i < $total; $i++) {
		$com = mysql_fetch_assoc(mysql_query("SELECT * FROM comments WHERE file=".$_GET['id']." ORDER BY time DESC LIMIT $i,1;"));
		$user = mysql_fetch_assoc(mysql_query("SELECT * FROM users WHERE id=".$com['user'].";"));
		echo '<a href="profile.php?id='.$user['id'].'">'.htmlspecialchars(stripslashes($user['login'])).'</a> ('.date('d.m.Y H:i:s', time()).')<br/>';
		echo htmlspecialchars(stripslashes($com['text'])).'<hr/>';
	}
	echo '</div>';
}
if($_SESSION['sess'] != '') {
	echo '<div class="mpanel">';
	echo '<b>Thêm Thảo luận</b><br/><form action="comments.php?id='.$_GET['id'].'" method="post">';
	echo '<textarea name="comtext" rows="4" cols="25"></textarea>';
	echo '<br/><input type="submit" value="Thêm!" name="add" />';
	echo '</form>';
	echo '</div>';
} else echo 'Chỉ <a href="login/">Đăng nhập</a> Mới được tham gia!';
db_close();
include 'footer.php';
?>