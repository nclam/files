<?php
@session_start();
include '../functions.php';
db_connect();
if($_COOKIE['login'] != '') {
//echo 'flag';
	if(mysql_num_rows(mysql_query("SELECT * FROM users WHERE session='".$_COOKIE['login']."';")) != 0) {
		$arr = mysql_fetch_assoc(mysql_query("SELECT * FROM users WHERE session='".$_COOKIE['login']."';"));
		$_SESSION['login'] = $arr['login'];
		$_SESSION['my_id'] = $arr['id'];
		$_SESSION['sess'] = $_COOKIE['login'];
		if($arr['level'] == -1) {
			include '../header.php';
			echo 'Tài khoản của bạn đã bị cấm.';
			include '../footer.php';
			db_close();
			exit;
		}
	}
}
include '../header.php';

set_tp('<img src="http://www.freeiconsweb.com/Icons/16x16_File_icons/Computer_File_001.gif"/>Tải lên tệp tin');
if($_SESSION['sess'] != '') {
	$arr = mysql_fetch_assoc(mysql_query("SELECT * FROM users WHERE id=".$_SESSION['my_id'].";"));
	if(time() - 15 <= $arr['lasttime']) {
		echo '<div class="list<font color="#aa0000">Bạn chỉ có thể tải lên một tập tin trong 15 giây. Vẫn: '.(15 - (time() - $arr['lasttime'])).' giây</font></div>';
		include '../footer.php';
		mysql_close();
		exit;
	}
}
if(isset($_POST['send'])) {
	if($_SESSION['sess'] == '') {
		if($_SESSION['securityCode'] == '') $_SESSION['securityCode'] = md5(time());
		if($_POST['seccode'] != $_SESSION['securityCode']) {
			echo 'Nhập Sai mã số.';
			include '../footer.php';
			exit;
		}
	}
	//ini_set('upload_max_filesize', '100M');
	$setarr = mysql_fetch_assoc(mysql_query("SELECT * FROM settings;"));
	if($_POST['fileupl'] == '') $_POST['fileupl'] = 'f';
	if($_POST['fileupl'] == 'f') {
		if(isset($_POST['file_opera'])) {
			$time = time();
			$rand = rand(0, 1000000);
			
			$time_dir = md5($time);
			$rand_dir = md5($rand);
			
			mkdir('../files/'.$time_dir);
			chmod('../files/'.$time_dir, 0777);
			
			mkdir('../files/'.$time_dir.'/'.$rand_dir);
			chmod('../files/'.$time_dir.'/'.$rand_dir, 0777);
			$uploaddir = '../files/'.$time_dir.'/'.$rand_dir.'/';
			$uploadedfile = $_POST['file_opera'];
			if(strlen($uploadedfile)) {
				if($_SESSION['sess'] == '') $maxf = $setarr['maxfile'];
					else {
						$myarr = mysql_fetch_assoc(mysql_query("SELECT * FROM users WHERE id=".$_SESSION['my_id'].';'));
						$maxf = trim(nl2br($myarr['quota']));
					}
				if(strlen($uploadedfile) > 1024*1024*$maxf) { 
					echo 'Tập tin này lớn hơn '.$maxf.' МB.'; 
					db_close();
					include '../footer.php';
					exit;
				}
				$array = explode('file=', $uploadedfile);
				$tmp_name = $array[0];
				$filebase64 = $array[1];
			}
			if (strlen($filebase64)) {
				$name = trim(nl2br($tmp_name));
				if(!checkExt($name)) {
					echo '<div class="list"><span class="attention">Định dạng tập tin không được cho phép! Để tải lên tập tin này, bạn cần nén tập tin thành zip, rar,...</span></div>';
					include '../footer.php';
					db_close();
					exit;
				}
				$FileName = $uploaddir.$name;
				$filedata = base64_decode($filebase64);
				$file = @fopen($FileName, "wb");
				if($file){
					if(flock($file, LOCK_EX)){
						fwrite($file, $filedata);
						flock($file, LOCK_UN);
					}
					fclose($file);
				}
				$path = $filename;
				$filename = $name;
			}
		} elseif(isset($_FILES['file']) &&
$_FILES['file']['error'] == 0) {
$_FILES['file']['name'] =
str_replace('_jar','.jar', $_FILES
['file']['name']);

$_FILES['file']['name'] =
str_replace('.jar1','.jar', $_FILES
['file']['name']);

if(!checkExt($_FILES['file']
['name'])) {
echo '
class="attention">Định dạng tập tin không được cho phép! Để tải lên tập tin này, bạn cần nén tập tin thành zip, rar,...
';
include '../footer.php';
db_close();
exit;

			} else {
				
				if($_SESSION['sess'] == '') $maxf = $setarr['maxfile'];
					else {
						$myarr = mysql_fetch_assoc(mysql_query("SELECT * FROM users WHERE id=".$_SESSION['my_id'].';'));
						$maxf = $myarr['quota'];
					}
				if($_FILES['file']['size'] > 1024*1024*$maxf) {
					echo 'Tập tin này lớn hơn '.$maxf.' MB.'; 
					db_close();
					include '../footer.php';
					exit;
				}
				$time = time();
				$rand = rand(0, 1000000);
				
				$time_dir = md5($time);
				$rand_dir = md5($rand);
				
				mkdir('../files/'.$time_dir);
				chmod('../files/'.$time_dir, 0777);
				
				mkdir('../files/'.$time_dir.'/'.$rand_dir);
				chmod('../files/'.$time_dir.'/'.$rand_dir, 0777);
				
				copy($_FILES['file']['tmp_name'], '../files/'.$time_dir.'/'.$rand_dir.'/'.$_FILES['file']['name']);
			
				$filename = $_FILES['file']['name'];
				$path = '../files/'.$time_dir.'/'.$rand_dir.'/'.$_FILES['file']['name'];
				
			}	
		} else {
			echo '<span class="attention">Lỗi tải tập tin: '.$_FILES['file']['error'].'</span><br/>';
			db_close();
			include '../footer.php';
			exit;
		}
	} elseif($_POST['fileupl'] == 'u') {
		//$_POST['url'] = p20repl($_POST['url']);
		if($_POST['url'] == '') {
			echo 'Bạn không cần phải có một liên kết đến tập tin!';
			db_close();
			include '../footer.php';
			exit;
		}
		$f = @fopen($_POST['url'], 'r');
		if(!$f) {
			echo 'Liên kết Tập tin  <b>'.htmlspecialchars(stripslashes($_POST['url'])).'</b> không có sẵn. Nó có thể đã bị xóa hoặc bạn nhập một đường dẫn không đúng.</b>';
			include '../footer.php';
			db_close();
			exit;
		}
		if(!checkExt($_POST['url'])) {
			echo '<span class="attention">Định dạng tệp tin bị cấm</span><br/>';
			include '../footer.php';
			db_close();
			exit;
		}
		while($c = fread($f, 1024)) $filedata .= $c;
		if($_SESSION['sess'] == '') $maxf = $setarr['maxfile'];
			else {
				$myarr = mysql_fetch_assoc(mysql_query("SELECT * FROM users WHERE id=".$_SESSION['my_id'].';'));
				$maxf = trim(nl2br($myarr['quota']));
			}
		if(strlen($filedata) > 1024*1024*$maxf) {
			echo 'Tập tin này lớn hơn <b>'.$maxf.' MB</b>.';
			fclose($f);
			include '../footer.php';
			db_close();
			exit;
		}
		fclose($f);
		$_POST['url'] = p20repl($_POST['url']);
		$time = time();
		$rand = rand(0, 1000000);
		
		$time_dir = md5($time);
		$rand_dir = md5($rand);
		
		mkdir('../files/'.$time_dir);
		chmod('../files/'.$time_dir, 0777);
		
		mkdir('../files/'.$time_dir.'/'.$rand_dir);
		chmod('../files/'.$time_dir.'/'.$rand_dir, 0777);
		
		file_put_contents('../files/'.$time_dir.'/'.$rand_dir.'/'.getWithoutPath($_POST['url']), $filedata);
	
		$filename = getWithoutPath($_POST['url']);
		$path = '../files/'.$time_dir.'/'.$rand_dir.'/'.getWithoutPath($_POST['url']);
	}
	//echo '123123';
	$yes_its_exists = 0;
	$is_image = 0;
	if(imgExt($filename)) {
		if($_SESSION['sess'] == '') $maxf = $setarr['maxfile'];
			else {
				$myarr = mysql_fetch_assoc(mysql_query("SELECT * FROM users WHERE id=".$_SESSION['my_id'].';'));
				$maxf = $myarr['quota'];
			}
		if($maxf > 10) ini_set("memory_limit", $maxf."M"); 
		if($imgsize = getimagesize($path)) {
			$is_image = 1;
			if($imgsize[0] > 120) {
				switch($imgsize[2]) {
				case 1:
					$src = imagecreatefromgif($path);
					break;
				case 2:
					$src = imagecreatefromjpeg($path);
					break;
				case 3:
					$src = imagecreatefrompng($path);
					break;
				default:
					$defbreak = true;
					break;
				}
				if(!$defbreak) {
					$w_src = imagesx($src);
					$h_src = imagesy($src);
					$ratio = $w_src / 120;
					$w_dest = round($w_src / $ratio);
					$h_dest = round($h_src / $ratio);
					$dest = imagecreatetruecolor($w_dest, $h_dest);
					imagecopyresized($dest, $src, 0, 0, 0, 0, $w_dest, $h_dest, $w_src, $h_src);
					switch($imgsize[2]) {
					case 1:
						imagegif($dest, '../files/'.$time_dir.'/'.$rand_dir.'/preview'.image_type_to_extension($imgsize[2]));
						break;
					case 2:
						imagejpeg($dest, '../files/'.$time_dir.'/'.$rand_dir.'/preview'.image_type_to_extension($imgsize[2]));
						break;
					case 3:
						imagepng($dest, '../files/'.$time_dir.'/'.$rand_dir.'/preview'.image_type_to_extension($imgsize[2]));
						break; 
					}
					$yes_its_exists = 1;
				} 
			} else copy($path, '../files/'.$time_dir.'/'.$rand_dir.'/preview'.image_type_to_extension($imgsize[2]));
		}
	}
	//echo '123';
	$id = get_next_file_id();
	if($_SESSION['sess'] != '') {
		$arr = mysql_fetch_assoc(mysql_query("SELECT * FROM users WHERE login='".mysql_escape_string($_SESSION['login'])."';"));
		$userid = $arr['id'];
		$fss = (float)(@filesize($path) / (1024 * 1024));
		$vd = $fss + (float)$arr['money'];
		$vd = round($vd, 3);
		mysql_query("UPDATE users SET `lasttime`='".time()."', `money`='".$vd."', `uploaded`='".((float)$arr['uploaded']+(float)round($fss, 3))."' WHERE id=".$_SESSION['my_id'].';') or die(mysql_error());
	} else 	$userid = 0;
	if($_POST['password'] != '') {
		$_POST['price'] = (float)$_POST['price'];
		if(((float)$_POST['price'] == '' || (float)$_POST['price'] < 0) && $_POST['price'] != 0) {
			$cdef = true;
			$_price = 0;
		} else {
			$_price = round($_POST['price'], 3);
			$cdef = false;
		}
	} else $_price = '0.0';
	//echo $filename;exit;
	mysql_query("INSERT INTO files VALUES(".$id.", ".$userid.", '".mysql_escape_string($filename)."', '".$time_dir.'/'.$rand_dir.'/'.mysql_escape_string($filename)."', '".mysql_escape_string($_SERVER['HTTP_USER_AGENT'])."', '".$_SERVER['REMOTE_ADDR']."', 0, '".mysql_escape_string($_POST['desc'])."', '".$_POST['password']."', '".$is_image."', '".$yes_its_exists."', '', '', '".$_price."', ".time().", '0');") or die(mysql_error());
	$tieude = "Tải lên thành công";
        include '../tieude.php';
	echo '<div class="glist"><img src="http://mackie.wapsite.me/images/Accept.png">Tải lên tập tin thành công!</div><br/>';
	if($cdef && $_POST['password'] != '')
		echo '<div class="list">Bạn đã không được chỉ định hoặc chỉ định giá bất hợp pháp của mật khẩu. Mức giá được thiết lập theo mặc định (0 - không phải để bán).</div><br/>';
        include '../seo.php';

	echo '<div class="list">Bạn đã tải lên thành công tệp tin <a href="/taptin-'.$id.'.html">'.$filename.'</a></div>';
	echo '<div class="list">»<a href="/taptin-'.$id.'.html">Tới tập tin vừa up</a></div>';
	echo '<div class="list">»<a href="index.php">Upload thêm</a><br/></div>';
	echo 'Liên kết:<br/><input type="text" value="'.$diachi.'/taptin-'.$id.'.html" /><br/>';
	echo '<div class="tp"><a href="../index.php">Trang chủ</a></div>';
	
	db_close();
	include '../footer.php';
	
	exit;
}

echo '<div class="body">';
$tieude = "Tập tin mới";
include '../tieude.php';
echo '<form action="index.php" method="post" enctype="multipart/form-data">';
if($_SESSION['sess'] != '') echo '<div class="list"><input type="radio" name="fileupl" value="f" id="fuid" checked><label for="fuid">Từ máy:</label><br/>';
switch(parseUA($_SERVER['HTTP_USER_AGENT'])) {
case 1:
case 2:
	echo '';
	if($_SESSION['sess'] == '') echo 'Tệp:<br/>';
	echo '<input name="file_opera" value="" /><a href="op:fileselect">Chọn tệp</a></div>';
case 3:
case 4:
default:
	echo '';
	if($_SESSION['sess'] == '') echo 'Tệp:<br/>';
	echo '<input type="file" name="file" /></div>';
	break;
}
if($_SESSION['sess'] != '') echo '<div class="list"><input type="radio" name="fileupl" value="u" id="uuid"><label for="uuid">Từ URL:</label><br/><input type="text" name="url" value="http://" /></div>';
echo '<div class="list">Mô tả cho tập tin:<br/><textarea type="text" name="desc" value="" /></textarea></div>';
echo '<div class="list">Mật khẩu cho tập tin:<br/><input type="passwords" name="password" value="" /></div>';
if($_SESSION['sess'] != '') echo '<div class="list">Giá mật khẩu: (0 - ko bán)<br/><input type="text" name="price" value="0" size="4" /> (<a href="../help/index.php?t=passprices">Thông tin</a>)<br/>';
if($_SESSION['sess'] == '') echo '<div class="list">Nhập số từ hình:<br/><input type="text" value="" name="seccode" /><br/><img src="img.php" alt="code" border="0" /></div>';
	$setarr = mysql_fetch_assoc(mysql_query("SELECT * FROM settings;"));
echo '<input type="submit" name="send" value="Upload!" />(<font color="red"><b>Max '.$setarr['maxfile'].'Mb</b></font>)<br/></div></form></div>';
echo '<div class="tp"><a href="/cat/">Download</a> | <a href="../index.php">Home</a></div>';
include '../footer.php';
?>