<?php
@session_start();
include 'functions.php';
$_GET['id'] = (int)$_GET['id'];
if($_GET['id'] == '' || $_GET['id'] == '') exit;
db_connect();
if(mysql_num_rows(mysql_query("SELECT * FROM files WHERE id=".$_GET['id'].';')) == 0) {
 db_close();
 exit;
}
$file = mysql_fetch_assoc(mysql_query("SELECT * FROM files WHERE id=".$_GET['id'].';'));
if($_SESSION['user'] != '') $user_me = mysql_fetch_assoc(mysql_query("SELECT level FROM users WHERE id=".$_SESSION['my_id'].";"));
if($_SESSION['load_'.$_GET['id']] != '777' && $file['password'] != '' && $user_me['level'] < 2) {
 db_close();
 header("Location: index.php?id=".$_GET['id']);
 exit;
} else {
 mysql_query("UPDATE files SET `lastloadtime`='".time()."', `load`=".($file['load']+1)." WHERE id=".$_GET['id'].";") or die(mysql_error());
 db_close();
$file_dir = 'files/';
$taptin = $file_dir.$file['path'];
$fp = fopen($taptin, "rb");
$size = filesize($taptin);
header('Content-type:application/octet-stream');
header('Content-disposition: attachment;filename="'.$file['filename'].'"');
header('Content-length: '.$size);
fpassthru($fp);
fclose($fp);
 exit;
}
?>