<?php
@session_start();
include 'functions.php';
db_connect();
if($_COOKIE['login'] != '') {
	if(mysql_num_rows(mysql_query("SELECT * FROM users WHERE session='".$_COOKIE['login']."';")) != 0) {
		$arr = mysql_fetch_assoc(mysql_query("SELECT * FROM users WHERE session='".$_COOKIE['login']."';"));
		$_SESSION['login'] = $arr['login'];
		$_SESSION['my_id'] = $arr['id'];
		$_SESSION['sess'] = $_COOKIE['login'];
		if($arr['level'] == -1) {
			include 'header.php';
			echo 'Tài khoản của bạn đã bị cấm.';
			include 'footer.php';
			db_close();
			exit;
		}
	}
}

include 'header.php';

$_GET['id'] = (int)$_GET['id'];
if($_GET['id'] == '' && $_SESSION['sess'] == '') {
	set_tp('Bạn không được phép!');
	echo '<div class="body">Bạn không được phép. <a href="login/index.php">Đăng nhập</a> hoặc <a href="login/register/">Đăng ký</a>.</div>';
	db_close();
	include 'footer.php';
	exit;
}

if($_GET['id'] == '') $the_user = $_SESSION['my_id'];
	else $the_user = $_GET['id'];

$uu = mysql_fetch_assoc(mysql_query("SELECT * FROM users WHERE id=".$the_user.';'));
if($uu['name'] == '') $uu['name'] = 'Không xác định';
set_tp('Xem Hồ sơ: '.htmlspecialchars(stripslashes($uu['login'])));
echo '<div class="body">';
echo '<b>Đăng nhập: </b>'.htmlspecialchars(stripslashes($uu['login'])).'<br/>';
if($uu['avatar'] == 1) echo '<b>Avatar: </b><br/><img src="avatars/'.$uu['id'].'.png" alt="" border="0" style="padding: 5px 5px 5px 5px;" /><br/>';
echo '<b>Tên thật: </b>'.htmlspecialchars(stripslashes($uu['name'])).'<br/>';
echo '<b>Đăng ký ngày: </b>'.date('d.m.Y H:i:s', $uu['time']).'<br/>';
echo '<b>Số lượng các tập tin: </b>'.mysql_num_rows(mysql_query("SELECT * FROM files WHERE user=".$uu['id'].";")).'<br/>';
echo '<b>Tổng dung lượng: </b>'.$uu['uploaded'].' Мb<br/>';
echo '<b>Tiền: </b>'.$uu['money'].' WD<br/>';
echo '<b>Max. kích thước cho một tập tin: </b>'.$uu['quota'].' Мb<br/>';
echo '<b>E-mail: </b>'.htmlspecialchars(stripslashes($uu['email'])).'<br/><hr/>';

if($_SESSION['sess'] != '' && $uu['id'] != $_SESSION['my_id']) {
	echo '<a href="sendmoney.php?to='.$uu['id'].'">Gửi cho tiền</a><br/>';
	echo '<a href="privat.php?newmsg&to='.$uu['id'].'">Gửi tin nhắn</a><br/>';
}

if($_SESSION['my_id'] == $the_user) {
	echo '<a href="office/settings.php?mode=name">Sửa đổi tên</a><br/>';
	echo '<a href="office/settings.php?mode=email">Sửa đổ e-mail</a><br/>';
	echo '<a href="office/settings.php?mode=avatar">Sửa đổ avatar</a><br/>';
	echo '<a href="office/settings.php?mode=buy_quota">Mua hạn ngạch</a><br/>';
	echo '<a href="office/settings.php?mode=password">Thay đổi mật khẩu</a><br/>';
	echo '<a href="office/settings.php?mode=params">Cài đặt cá nhân</a><br/>';
}

echo '</div>';

include 'footer.php';
db_close();
?>