<?php
include '../../header.php';
include '../../functions.php';
set_tp('Trợ giúp');
echo '<div class="body"><b>Trợ giúp</b><br/>
Bạn không thể đăng tải các tập tin có chứa các thông tin bất hợp pháp hoặc có hại, cũng như các thông tin 
trái với luật pháp của việt nam. Những tập tin này sẽ được gỡ bỏ mà không cần báo trước.<br/><br/>
Các tập tin được lưu giữ vĩnh viễn. Dịch vụ lưu trữ tập tin này được xem là tốt nhất.<br/>

Kích thước tối đa lên đến - 50MB.<br/>
<br/></div>';
echo '<div class="btm">[<a href="../../login/register/">Đăng ký</a>]';
echo '</div>';
include '../../footer.php';
?>