<?php
include '../functions.php';
db_connect();
if($_COOKIE['login'] != '') {
//echo 'flag';
	if(mysql_num_rows(mysql_query("SELECT * FROM users WHERE session='".$_COOKIE['login']."';")) != 0) {
		$arr = mysql_fetch_assoc(mysql_query("SELECT * FROM users WHERE session='".$_COOKIE['login']."';"));
		$_SESSION['login'] = $arr['login'];
		$_SESSION['my_id'] = $arr['id'];
		$_SESSION['sess'] = $_COOKIE['login'];
		if($arr['level'] == -1) {
			include '../header.php';
			echo 'Tài khoản của bạn đã bị cấm.';
			include '../footer.php';
			db_close();
			exit;
		}
	}
}
include '../header.php';
set_tp('Giúp đỡ');
switch($_GET['t']) {
case 'gen':
	$setarr = mysql_fetch_assoc(mysql_query("SELECT * FROM settings;"));
	echo '
	<div class="tp">Thông tin về wap</b></div>
	<div class="list">'.$copy.' - là một Chương trình lưu trữ tập tin miễn phí cho điện thoại di động.<br/>
	Những đặc tính:<br/>
	
	-Upload từ máy tính / điện thoại;<br/>
	-Khả năng upload từ Opera Mini;<br/>
	-Kích thước tập tin tối đa - '.$setarr['maxfile'].'MB<br/>
	-Tập tin được bảo vệ bằng mật khẩu.<br/>
	-Tính năng mua mật khẩu bằng tiền ngân hàng .và còn nhiều tính năng hay nữa.
	</div><div class="tp"><a href="index.php">Home</a></div></div>';
	break;
case 'gen.start':
	echo '<div class="body"><b>Bắt đầu từ đâu?</b><br/>
	Bạn có thể upload tập tin ngay lập tức mà không cần đăng ký.<br/>
	<br/>[<a href="index.php">Quay lại</a>]<br/></div>';
	break;
case 'passprices':
	echo '<div class="body">
	Đối với tất cả các tập tin upload, bạn nhận được số tiền WD. Một trong những megabyte dữ liệu upload tài khoản của bạn được cộng 1 WD. Tiền kia bạn có thể dùng để mua mật khẩu của các tập tin khác, nếu tập tin đó có mật khẩu bạn có thể mua :D.<br/>
	Bạn cũng có thể đặt giá cho mật khẩu của bạn (Nếu để là 0 thì tập tin đó không thể mua).
	</div>';
	break;
case 'gen.reg':
	echo '<div class="body"><b>Đăng ký</b><br/>
	Đăng ký được yêu cầu để:<br/>
	-Nhìn thấy danh sách các tập tin của bạn đã upload;<br/>
	-Thay đổi mật khẩu, và một mô tả cho tập tin;<br/>
	-Giao tiếp với các thành viên tham gia khác;<br/>
	<br/>[<a href="index.php">Quay lại</a>]<br/></div>';
	break;
case 'gen.ext':
	echo '<div class="body"><b>Sẵn sàng các định dạng</b><br/>
	Upload được hầu hết các định dạng, ngoại trừ một số file trong đó tôi sẽ không nói :D.<br/>Kích thước tối đa tập tin: <b>50МB</b>.<br/><br/>[<a href="index.php">Quay lại
	</a>]<br/></div>';
	break;
default:
	echo '<div class="bhead"><b>Câu hỏi thường gặp</b></div>';
	echo '<div class="body"><a href="index.php?t=gen">Thông tin về wap</a><br/>';
	echo '<a href="index.php?t=gen.start">Tôi phải bắt đầu từ đâu?</a><br/>';
	echo '<a href="index.php?t=gen.reg">Đăng ký để làm gì</a><br/>';
	echo '<a href="index.php?t=gen.ext">Cho phép các định dạng tập tin nào</a><br/></div>';
	echo '<div class="btm">[<a href="../login/register/">Đăng ký</a>]';
	break;
}
echo '</div>';
db_close();
include '../footer.php';
?>