<form role="search" method="get" id="searchform" action="<?php echo esc_url( home_url( '/' ) ); ?>">
    <div>
		<input type="text" class="search-input" placeholder="<?php echo penci_get_setting( 'penci_trans_type_and_hit' ); ?>" name="s" id="s" />
	 </div>
</form>