<!-- Start Code Tags title -->
<script type="text/javascript">
var th=document.title;
tags=th.split(" ");
for (var i=0;i<tags.length;i++)
{
document.write('<a href=" http://google.com.vn/search?sitesearch=vinajohn&q='+tags [i]+'">'+tags[i]+'</a>, ');
}
</script>
<!-- End Code Tags title -->