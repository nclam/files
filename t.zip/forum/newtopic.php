<?php
define('_IN_JOHNCMS', 1);
$textl = 'Gửi bài viết mới';
require_once ("../incfiles/core.php");
require_once ("../incfiles/head.php");
if ($id && $id != $user_id) {
$req = mysql_query("SELECT * FROM `users` WHERE `id` = '$id' LIMIT 1");
if (mysql_num_rows($req)) {
$user = mysql_fetch_assoc($req);
}

}
else {
$id = false;
$user = $datauser;
}

if(!$user_id){
require('../incfiles/head.php');
echo functions::display_error($lng['access_guest_forbidden']);
require('../incfiles/end.php');
exit;
}

$req = mysql_query("SELECT `id`, `text`, `soft` FROM `forum` WHERE `type`='f' ORDER BY `realid`");
while ($res = mysql_fetch_array($req)) {
echo'<div class="phdr">';
$count = mysql_result(mysql_query("SELECT COUNT(*) FROM `forum` WHERE `type`='r' and `refid`='" . $res['id'] . "'"), 0);
echo $res['text'];
echo '</div>';
$vnit = $res['id'];
$req1 = mysql_query("SELECT `id`, `text`, `soft` FROM `forum` WHERE `type`='r' AND `refid`='$vnit' ORDER BY `realid`");
while ($res1 = mysql_fetch_assoc($req1)) {
echo'<div class="list1">';
echo '<font color="red">- </font><a href="/forum/index.php?act=nt&id=' . $res1['id'] . '" title="' . $res1['text'] . '">' . $res1['text'] . '</a>';
echo '</div>';
++$i;

}
++$i;
}
require_once ("../incfiles/end.php");
?>