<?php
 /*
 * @package     nguyencaolam.ga
 * @link        https://nguyencaolam.ga
 * @copyright   Copyright (C) 2015-2016 Kenh10s.
 * @Mod         Lâm Nguyễn
 * @Coder       Gazenwagen 
 */

defined('_IN_JOHNCMS') or die('Error: restricted access');

$headmod = isset($headmod) ? mysql_real_escape_string($headmod) : '';
$textl = isset($textl) ? $textl : $set['copyright'];
$textl=html_entity_decode($textl,ENT_QUOTES,'UTF-8'); ////fix lỗi font title

echo'<!DOCTYPE html>' .
    "\n" . '<html lang="vn">' . //' . core::$lng_iso . '//
    "\n" . '<head>' .
    "\n" . '<meta charset="utf-8">' .
    "\n" . '<meta http-equiv="X-UA-Compatible" content="IE=edge">' .
    "\n" . '<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=2.0, user-scalable=yes">' .
    "\n" . '<meta name="HandheldFriendly" content="true">' .
    "\n" . '<meta name="MobileOptimized" content="width">' .
    "\n" . '<meta content="yes" name="apple-mobile-web-app-capable">' .
    "\n" . '<meta name="Generator" content="nguyencaolam.ga, http://kenh10s.om">' .
    (!empty($set['meta_key']) ? "\n" . '<meta name="keywords" content="' . $set['meta_key'] . '">' : '') .
    (!empty($set['meta_desc']) ? "\n" . '<meta name="description" content="' . $set['meta_desc'] . '">' : '') .
    "\n" . '<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">
<link rel="stylesheet" href="http://nguyencaolam.ga/theme/selemet/style.css?chauhuynh=nguyencaolam.ga">
<link href="http://nguyencaolam.ga/css/bootstrap.min.css" rel="stylesheet">
<link href="http://nguyencaolam.ga/css/bootstrap-theme.min.css" rel="stylesheet">
<link href="http://nguyencaolam.ga/css/sb-admin.css" rel="stylesheet">
<link href="http://nguyencaolam.ga/css/plugins/morris.css" rel="stylesheet">
<link href="http://nguyencaolam.ga/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
<script src="http://nguyencaolam.ga/js/jquery.js"></script>
<script src="http://nguyencaolam.ga/js/bootstrap.min.js"></script>
<script src="http://nguyencaolam.ga/js/plugins/morris/raphael.min.js"></script>
<script src="http://nguyencaolam.ga/js/plugins/morris/morris.min.js"></script>
<script src="http://nguyencaolam.ga/js/plugins/morris/morris-data.js"></script>
<script type="text/javascript" src="/pages/jquery.js"></script>
<script type="text/javascript" src="http://ajax.microsoft.com/ajax/jquery.validate/1.7/jquery.validate.min.js"></script><script type="text/javascript" src="http://ajax.microsoft.com/ajax/jquery.validate/1.7/jquery.validate.min.js"></script>' .
	"\n" . '<script type="text/javascript" src="/pages/jquery.js"></script>' .	
	"\n" . '<script type="text/javascript" src="http://ajax.microsoft.com/ajax/jquery.validate/1.7/jquery.validate.min.js"></script>'.
    "\n" . '<link rel="shortcut icon" href="' . $set['homeurl'] . '/favicon.ico">' .
    "\n" . '<link rel="alternate" type="application/rss+xml" title="RSS | ' . $lng['site_news'] . '" href="' . $set['homeurl'] . '/rss/rss.php">' .
    "\n" . '<title>' . $textl . ' - nguyencaolam.ga</title>' .
    "\n" . '<script type="text/javascript" src="http://ajax.microsoft.com/ajax/jquery.validate/1.7/jquery.validate.min.js"></script>' .
    "\n" . '</head><body>' . core::display_core_errors();

if ($user_id){
?>
<script type="text/javascript">
function showLoading(){
document.getElementById('btnSubmit1').style.display='none';
document.getElementById('btnSubmit2').style.display='inline-block';
document.getElementById('loading').style.display='block';
return true;
}
</script>

<?php
}
/*
-----------------------------------------------------------------
nguyencaolam.ga
-----------------------------------------------------------------
*/
$cms_ads = array();
if (!isset($_GET['err']) && $act != '404' && $headmod != 'admin') {
    $view = $user_id ? 2 : 1;
    $layout = ($headmod == 'mainpage' && !$act) ? 1 : 2;
    $req = mysql_query("SELECT * FROM `cms_ads` WHERE `to` = '0' AND (`layout` = '$layout' or `layout` = '0') AND (`view` = '$view' or `view` = '0') ORDER BY  `mesto` ASC");
    if (mysql_num_rows($req)) {
        while (($res = mysql_fetch_assoc($req)) !== FALSE) {
            $name = explode("|", $res['name']);
            $name = htmlentities($name[mt_rand(0, (count($name) - 1))], ENT_QUOTES, 'UTF-8');
            if (!empty($res['color'])) $name = '<span style="color:#' . $res['color'] . '">' . $name . '</span>';
            // Если было задано начертание шрифта, то применяем
            $font = $res['bold'] ? 'font-weight: bold;' : FALSE;
            $font .= $res['italic'] ? ' font-style:italic;' : FALSE;
            $font .= $res['underline'] ? ' text-decoration:underline;' : FALSE;
            if ($font) $name = '<span style="' . $font . '">' . $name . '</span>';
            @$cms_ads[$res['type']] .= '<a href="' . ($res['show'] ? functions::checkout($res['link']) : $set['homeurl'] . '/go.php?id=' . $res['id']) . '">' . $name . '</a><br/>';
            if (($res['day'] != 0 && time() >= ($res['time'] + $res['day'] * 3600 * 24)) || ($res['count_link'] != 0 && $res['count'] >= $res['count_link']))
                mysql_query("UPDATE `cms_ads` SET `to` = '1'  WHERE `id` = '" . $res['id'] . "'");
        }
    }
}

/*
-----------------------------------------------------------------
nguyencaolam.ga
-----------------------------------------------------------------
*/
if (isset($cms_ads[0])) echo $cms_ads[0];

/*
-----------------------------------------------------------------
nguyencaolam.ga
-----------------------------------------------------------------
*/

echo'<div class="header">
	<a href="/"><center><img src="https://nguyencaolam.ga/publics/images/logo1.png" alt="nguyencaolam.ga" style="margin:5px"></center></a>
	</div><div class="list"><center><form action="http://google.com/search" method="get">
<input name="sitesearch" value="NguyenCaoLam.Ga" type="hidden">
            <input class="timkiem" type="tim" placeholder="Tìm Kiếm Nhanh" name="q" value="" style="width:300px"/>
            <input class="timkiem" type="submit" value="Tìm Kiếm" style="padding:10px 30px;border-radius:20px"/>
    </form></center></div>';
/*
-----------------------------------------------------------------
nguyencaolam.ga
-----------------------------------------------------------------
*/







if($rights >= 9) {
echo '• <a href="/panel"><i class="fa fa-user"></i> Admin Panel </a> ';
}