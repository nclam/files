<?php

 /*
 * @package     NguyenCaoLam.Ga
 * @link        https://NguyenCaoLam.ga
 * @copyright   Copyright (C) 2015-2016 Lâm Nguyễn
 * @Mod         Lâm Nguyễn
 * @Coder       Gazenwagen 
 */



defined('_IN_JOHNCMS') or die('Error: restricted access');

// Рекламный блок сайта
if (!empty($cms_ads[2])) {
    echo '<div class="gmenu">' . $cms_ads[2] . '</div>';
}

echo '<div class="phdr"> Trang Chủ </div>';
echo'
</div></div><div class="footer" style="padding:30px"><center><font color="red"> NguyenCaoLam.Ga </font>
<br/>&copy; <a href="/">Design : Lâm Nguyễn </a></center></div></div></div></body></html>';