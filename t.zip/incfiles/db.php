<?php

defined('_IN_JOHNCMS') or die ('Error: restricted access');

$db_host = 'localhost';
$db_name = 'truyen';
$db_user = 'truyen';
$db_pass = '0934455404';