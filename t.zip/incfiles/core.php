<?php


 /*
 * @package     Kenh10s.Com
 * @link        https://kenh10s.com
 * @copyright   Copyright (C) 2015-2016 Kenh10s.
 * @Mod         Châu Huỳnh
 * @Coder       Gazenwagen 
 */



defined('_IN_JOHNCMS') or die('Error: restricted access');
//Error_Reporting(E_ALL & ~E_NOTICE);
ini_set('session.use_trans_sid', '0');
ini_set('arg_separator.output', '&amp;');
ini_set('display_errors', 'Off');
date_default_timezone_set('UTC');
mb_internal_encoding('UTF-8');

// Корневая папка
define('ROOTPATH', dirname(dirname(__FILE__)) . DIRECTORY_SEPARATOR);

/*
-----------------------------------------------------------------
Автозагрузка Классов
-----------------------------------------------------------------
*/
spl_autoload_register('autoload');
function autoload($name)
{
    $file = ROOTPATH . 'incfiles/classes/' . $name . '.php';
    if (file_exists($file))
        require_once($file);
}

/*
-----------------------------------------------------------------
Инициализируем Ядро системы
-----------------------------------------------------------------
*/
new core;

/*
-----------------------------------------------------------------
Получаем системные переменные для совместимости со старыми модулями
-----------------------------------------------------------------
*/
$rootpath = ROOTPATH;
$ip = core::$ip; // Адрес IP
$agn = core::$user_agent; // User Agent
$set = core::$system_set; // Системные настройки
$lng = core::$lng; // Фразы языка
$is_mobile = core::$is_mobile; // Определение мобильного браузера
$home = $set['homeurl']; // Домашняя страница

/*
-----------------------------------------------------------------
Получаем пользовательские переменные
-----------------------------------------------------------------
*/
$user_id = core::$user_id; // Идентификатор пользователя
$rights = core::$user_rights; // Права доступа
$datauser = core::$user_data; // Все данные пользователя
$set_user = core::$user_set; // Пользовательские настройки
$ban = core::$user_ban; // Бан
$login = isset($datauser['name']) ? $datauser['name'] : false;
$kmess = $set_user['kmess'] > 4 && $set_user['kmess'] < 10 ? $set_user['kmess'] : 10;

function validate_referer()
{
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') return;
    if (@!empty($_SERVER['HTTP_REFERER'])) {
        $ref = parse_url(@$_SERVER['HTTP_REFERER']);
        if ($_SERVER['HTTP_HOST'] === $ref['host']) return;
    }
    die('Invalid request');
}

if ($rights) {
    validate_referer();
}

/*
-----------------------------------------------------------------
Получаем и фильтруем основные переменные для системы
-----------------------------------------------------------------
*/
$id = isset($_REQUEST['id']) ? abs(intval($_REQUEST['id'])) : false;
$user = isset($_REQUEST['user']) ? abs(intval($_REQUEST['user'])) : false;
$act = isset($_REQUEST['act']) ? trim($_REQUEST['act']) : '';
$mod = isset($_REQUEST['mod']) ? trim($_REQUEST['mod']) : '';
$do = isset($_REQUEST['do']) ? trim($_REQUEST['do']) : false;
$page = isset($_REQUEST['page']) && $_REQUEST['page'] > 0 ? intval($_REQUEST['page']) : 1;
$start = isset($_REQUEST['page']) ? $page * $kmess - $kmess : (isset($_GET['start']) ? abs(intval($_GET['start'])) : 0);
$headmod = isset($headmod) ? $headmod : '';

/*
-----------------------------------------------------------------
Закрытие сайта / редирект гостей на страницу ожидания
-----------------------------------------------------------------
*/
if ((core::$system_set['site_access'] == 0 || core::$system_set['site_access'] == 1) && $headmod != 'login' && !core::$user_id) {
    header('Location: ' . core::$system_set['homeurl'] . '/closed.php');
}

/*
-----------------------------------------------------------------
Буфферизация вывода
-----------------------------------------------------------------
*/
if ($set['gzip'] && @extension_loaded('zlib')) {
    @ini_set('zlib.output_compression_level', 3);
    ob_start('ob_gzhandler');
} else {
    ob_start();
}

function nick($id, $mod = false){
$ban = mysql_result(mysql_query("SELECT COUNT(*) FROM `cms_ban_users` WHERE `user_id` = '" . $id . "' AND `ban_time` > '" . time() . "'"), 0);
$user = mysql_fetch_array(mysql_query("SELECT * FROM `users` WHERE `id` = '" . $id . "'"));
if ($id) $vip_shop = mysql_result(mysql_query("SELECT COUNT(*) FROM `shop_options` WHERE `vip` = 1 AND `user_id` = $id"), 0);
if ($id) $bold_shop = mysql_result(mysql_query("SELECT COUNT(*) FROM `shop_options` WHERE `bold` = 1 AND `user_id` = $id"), 0);


if($ban > 0) {
$out .= '<span style="color:#000000">'.($mod == 1 ? '<small>' : '').'<s>' . $user['name'] . '</s>'.($mod == 1 ? '</small>' : '').'</span>';
} else {
if($user['rights'] == 100) {$font = '<span style="text-shadow: 0px 0px 6px rgb(255, 0, 153), 0px 0px 5px rgb(255, 0, 153), 0px 0px 5px rgb(255, 0, 153);" color="#ffffff">';}
if($user['rights'] == 0) 
if($user['rights'] == 1) {$font = '<span style="color:#000000">';}
if($user['rights'] == 2) {$font = '<span style="color:#b903f3">';}
if($user['rights'] == 3) {$font = '<span style="color:#008000">';}
if($user['rights'] == 4) {$font = '<span style="color:#D2691E">';}
if($user['rights'] == 5) {$font = '<span style="color:#770000">';}
if($user['rights'] == 6) {$font = '<span style="color:#0000FF">';}
if($user['rights'] == 7) {$font = '<span style="color:#ff0000"><b>';}
if($user['rights'] == 9) {$font = '<span style="color:#ff0000"><b>';}
if($user['rights'] == 10) {$font = '<span style="color:#red">';}
if($user['name'] == Quandaik){$font = '<span style="color:##FF66C2"><b>';}
if($user['dayb'] == date('j', time()) && $user['monthb'] == date('n', time())) {$sn = '<img src="/images/cookie.png">';}
$out .= ($vip_shop == 1 ? '<img src="/images/vip.png" alt="VIP"/>'.($user['rights'] == 0 ? '<span style="color:#963360">' : $font).'' : $font).' '.($bold_shop == 1 ? '<b>' : '').'' . $user['name'] . '</b>'.($bold_shop == 1 ? '</b>' : '').'</span>';
}
return $out;
}
function rand_color($text) {
$color = array();
$color[] = '<font color="000011">';
$color[] = '<font color="000022">';
$color[] = '<font color="000044">';
$color[] = '<font color="000055">';
$color[] = '<font color="000077">';
$color[] = '<font color="000088">';
$color[] = '<font color="000099">';
$color[] = '<font color="0000AA">';
$color[] = '<font color="0000BB">';
$color[] = '<font color="0000CC">';
$color[] = '<font color="0000DD">';
$color[] = '<font color="0000EE">';
$color[] = '<font color="0000FF">';
$color[] = '<font color="001100">';
$color[] = '<font color="002200">';
$color[] = '<font color="003300">';
$color[] = '<font color="004400">';
$color[] = '<font color="005500">';
$color[] = '<font color="006600">';
$color[] = '<font color="007700">';
$color[] = '<font color="008800">';
$color[] = '<font color="009900">';
$color[] = '<font color="00AA00">';
$color[] = '<font color="00BB00">';
$color[] = '<font color="00CC00">';
$color[] = '<font color="00DD00">';
$color[] = '<font color="00EE00">';
$color[] = '<font color="00FF00">';
$color[] = '<font color="000033">';
$color[] = '<font color="000066">';
$color[] = '<font color="000099">';
$color[] = '<font color="0000CC">';
$color[] = '<font color="0000FF">';
$color[] = '<font color="330000">';
$color[] = '<font color="330033">';
$color[] = '<font color="330066">';
$color[] = '<font color="330099">';
$color[] = '<font color="3300CC">';
$color[] = '<font color="3300FF">';
$color[] = '<font color="660000">';
$color[] = '<font color="660033">';
$color[] = '<font color="660066">';
$color[] = '<font color="660099">';
$color[] = '<font color="6600CC">';
$color[] = '<font color="6600FF">';
$color[] = '<font color="990000">';
$color[] = '<font color="990033">';
$color[] = '<font color="990066">';
$color[] = '<font color="990099">';
$color[] = '<font color="9900CC">';
$color[] = '<font color="9900FF">';
$color[] = '<font color="CC0000">';
$color[] = '<font color="CC0033">';
$color[] = '<font color="CC0066">';
$color[] = '<font color="CC0099">';
$color[] = '<font color="CC00CC">';
$color[] = '<font color="CC00FF">';
$color[] = '<font color="FF0000">';
$color[] = '<font color="FF0033">';
$color[] = '<font color="FF0066">';
$color[] = '<font color="FF0099">';
$color[] = '<font color="FF00CC">';
$color[] = '<font color="FF00FF">';
$color[] = '<font color="003300">';
$color[] = '<font color="003333">';
$color[] = '<font color="003366">';
$color[] = '<font color="003399">';
$color[] = '<font color="0033CC">';
$color[] = '<font color="FF3333">';
$color[] = '<font color="0033FF">';
$color[] = '<font color="333300">';
$color[] = '<font color="333333">';
$color[] = '<font color="333366">';
$color[] = '<font color="333399">';
$color[] = '<font color="3333CC">';
$color[] = '<font color="3333FF">';
$color[] = '<font color="663300">';
$color[] = '<font color="663333">';
$color[] = '<font color="663366">';
$color[] = '<font color="663399">';
$color[] = '<font color="6633CC">';
$color[] = '<font color="6633FF">';
$color[] = '<font color="993300">';
$color[] = '<font color="993333">';
$color[] = '<font color="993366">';
$color[] = '<font color="993399">';
$color[] = '<font color="9933CC">';
$color[] = '<font color="9933FF">';
$color[] = '<font color="CC3300">';
$color[] = '<font color="CC3333">';
$color[] = '<font color="CC3366">';
$color[] = '<font color="CC3399">';
$color[] = '<font color="CC33CC">';
$color[] = '<font color="CC33FF">';
$color[] = '<font color="FF3300">';
$color[] = '<font color="FF3333">';
$color[] = '<font color="FF3366">';
$color[] = '<font color="FF3399">';
$color[] = '<font color="FF33CC">';
$color[] = '<font color="FF33FF">';
$color[] = '<font color="006600">';
$color[] = '<font color="006633">';
$color[] = '<font color="006666">';
$color[] = '<font color="006699">';
$color[] = '<font color="0066CC">';
$color[] = '<font color="0066FF">';
$color[] = '<font color="336600">';
$color[] = '<font color="336633">';
$color[] = '<font color="336666">';
$color[] = '<font color="336699">';
$color[] = '<font color="3366CC">';
$color[] = '<font color="3366FF">';
$color[] = '<font color="666600">';
$color[] = '<font color="666633">';
$color[] = '<font color="666666">';
$color[] = '<font color="666699">';
$color[] = '<font color="6666CC">';
$color[] = '<font color="6666FF">';
$color[] = '<font color="996600">';
$color[] = '<font color="996633">';
$color[] = '<font color="996666">';
$color[] = '<font color="996699">';
$color[] = '<font color="9966CC">';
$color[] = '<font color="9966FF">';
$color[] = '<font color="CC6600">';
$color[] = '<font color="CC6633">';
$color[] = '<font color="CC6666">';
$color[] = '<font color="CC6699">';
$color[] = '<font color="CC66CC">';
$color[] = '<font color="CC66FF">';
$color[] = '<font color="FF6600">';
$color[] = '<font color="FF6633">';
$color[] = '<font color="FF6666">';
$color[] = '<font color="FF6699">';
$color[] = '<font color="FF66CC">';
$color[] = '<font color="FF66FF">';
$color[] = '<font color="009900">';
$color[] = '<font color="009933">';
$color[] = '<font color="009966">';
$color[] = '<font color="009999">';
$color[] = '<font color="0099CC">';
$color[] = '<font color="0099FF">';
$color[] = '<font color="339900">';
$color[] = '<font color="339933">';
$color[] = '<font color="339966">';
$color[] = '<font color="339999">';
$color[] = '<font color="3399CC">';
$color[] = '<font color="3399FF">';
$color[] = '<font color="669900">';
$color[] = '<font color="669933">';
$color[] = '<font color="669966">';
$color[] = '<font color="669999">';
$color[] = '<font color="6699CC">';
$color[] = '<font color="6699FF">';
$color[] = '<font color="999900">';
$color[] = '<font color="999933">';
$color[] = '<font color="999966">';
$color[] = '<font color="999999">';
$color[] = '<font color="9999CC">';
$color[] = '<font color="9999FF">';
$color[] = '<font color="CC9900">';
$color[] = '<font color="CC9933">';
$color[] = '<font color="CC9966">';
$color[] = '<font color="CC9999">';
$color[] = '<font color="CC99CC">';
$color[] = '<font color="CC99FF">';
$color[] = '<font color="FF9900">';
$color[] = '<font color="FF9933">';
$color[] = '<font color="FF9966">';
$color[] = '<font color="FF9999">';
$color[] = '<font color="FF99CC">';
$color[] = '<font color="FF99FF">';
$color[] = '<font color="00CC00">';
$color[] = '<font color="00CC33">';
$color[] = '<font color="00CC66">';
$color[] = '<font color="00CC99">';
$color[] = '<font color="33CC33">';
$color[] = '<font color="33CC66">';
$color[] = '<font color="00CCCC">';
$color[] = '<font color="00CCFF">';
$color[] = '<font color="33CC00">';
$color[] = '<font color="33CC33">';
$color[] = '<font color="33CC66">';
$color[] = '<font color="33CC99">';
$color[] = '<font color="33CCCC">';
$color[] = '<font color="33CCFF">';
$color[] = '<font color="66CC00">';
$color[] = '<font color="66CC33">';
$color[] = '<font color="66CC66">';
$color[] = '<font color="66CC99">';
$color[] = '<font color="66CCCC">';
$color[] = '<font color="66CCFF">';
$color[] = '<font color="99CC00">';
$color[] = '<font color="99CC33">';
$color[] = '<font color="99CC66">';
$color[] = '<font color="99CC99">';
$color[] = '<font color="99CCCC">';
$color[] = '<font color="99CCFF">';
$color[] = '<font color="CCCC00">';
$color[] = '<font color="CCCC33">';
$color[] = '<font color="CCCC66">';
$color[] = '<font color="CCCC99">';
$color[] = '<font color="CCCCCC">';
$color[] = '<font color="CCCCFF">';
$color[] = '<font color="FFCC00">';
$color[] = '<font color="FFCC33">';
$color[] = '<font color="FFCC66">';
$color[] = '<font color="FFCC99">';
$color[] = '<font color="FFCCCC">';
$color[] = '<font color="FFCCFF">';
$color[] = '<font color="00FF00">';
$color[] = '<font color="00FF33">';
$color[] = '<font color="00FF66">';
$color[] = '<font color="00FF99">';
$color[] = '<font color="00FFCC">';
$color[] = '<font color="00FFFF">';
$color[] = '<font color="33FF00">';
$color[] = '<font color="33FF33">';
$color[] = '<font color="33FF66">';
$color[] = '<font color="33FF99">';
$color[] = '<font color="33FFCC">';
$color[] = '<font color="33FFFF">';
$color[] = '<font color="66FF00">';
$color[] = '<font color="66FF33">';
$color[] = '<font color="66FF66">';
$color[] = '<font color="66FF99">';
$color[] = '<font color="66FFCC">';
$color[] = '<font color="66FFFF">';
$color[] = '<font color="99FF00">';
$color[] = '<font color="99FF33">';
$color[] = '<font color="99FF66">';
$color[] = '<font color="99FF99">';
$color[] = '<font color="99FFCC">';
$color[] = '<font color="99FFFF">';
$color[] = '<font color="CCFF00">';
$color[] = '<font color="CCFF33">';
$color[] = '<font color="CCFF66">';
$color[] = '<font color="CCFF99">';
$color[] = '<font color="CCFFCC">';
$color[] = '<font color="CCFFFF">';
$color[] = '<font color="FFFF00">';
$color[] = '<font color="FFFF33">';
$color[] = '<font color="FFFF66">';
$color[] = '<font color="FFFF99">';
$color[] = '<font color="FFFFCC">';
$color[] = '<font color="FFFFFF">';
$color[] = '<font color="110000">';
$color[] = '<font color="220000">';
$color[] = '<font color="330000">';
$color[] = '<font color="440000">';
$color[] = '<font color="550000">';
$color[] = '<font color="660000">';
$color[] = '<font color="770000">';
$color[] = '<font color="880000">';
$color[] = '<font color="990000">';
$color[] = '<font color="AA0000">';
$color[] = '<font color="BB0000">';
$color[] = '<font color="CC0000">';
$color[] = '<font color="DD0000">';
$color[] = '<font color="EE0000">';
$color[] = '<font color="FF0000">';
$color[] = '<font color="111111">';
$color[] = '<font color="222222">';
$color[] = '<font color="333333">';
$color[] = '<font color="444444">';
$color[] = '<font color="555555">';
$color[] = '<font color="666666">';
$color[] = '<font color="777777">';
$color[] = '<font color="888888">';
$color[] = '<font color="999999">';
$color[] = '<font color="AAAAAA">';
$color[] = '<font color="BBBBBB">';
$color[] = '<font color="CCCCCC">';
$color[] = '<font color="DDDDDD">';
$color[] = '<font color="EEEEEE">';
$color[] = '<font color="FFFFFF">';
$out .= '' . $color[rand(0, count($color)-1)] . '' . $text . '</font>';
return $out;
}

function rand_size($text) {
$size = array();
$size[] = '<font size="+2">';
$size[] = '<font size="+1">';
$size[] = '<font>';
$size[] = '<font size="-1">';
$out .= '' . $size[rand(0, count($size)-1)] . '' . $text . '</font>';
return $out;
}

function rand_face($text) {
$face = array();
$face[] = '<font face="arial">';
$face[] = '<font>';
$face[] = '<font face="tahoma">';
$out .= '' . $face[rand(0, count($face)-1)] . '' . $text . '</font>';
return $out;
}