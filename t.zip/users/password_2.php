<?php

define('_IN_JOHNCMS', 1);
$headmod = 'shop';
require_once ('../incfiles/core.php');
$textl = 'Password cấp 2';
require_once ('../incfiles/head.php');
echo '<div class="mainblok">';
echo '<div class="phdr">Password cấp 2</div>';
	if (!$user_id) {
		echo '<div class="list1">Xin lỗi phần này chỉ thành viên mới được xem !</div>';
		echo '</div>';
		require_once ('../incfiles/end.php');
		exit;
	}

	if ($datauser['password_2'] != NULL) {
		echo '<div class="list1">Bạn đã thiết lập mật khẩu cấp 2 rồi nhé !</div>';
		echo '</div>';
		require_once ('../incfiles/end.php');
		exit;
	}
echo '<div class="list1">Bạn cần thiết lập mật khẩu cấp 2 để sử dụng các chức năng mới sắp ra mắt !</div>'; 
if (isset($_POST['submit'])) {
	$password = md5(md5($_POST['pass']));
	$re_password = md5(md5($_POST['re_pass']));
	$old_password = md5(md5($_POST['old_pass']));
	$password_user = mysql_fetch_assoc(mysql_query("SELECT password FROM users WHERE id = $user_id"));

	// pass xac nhan
	$pass_hien_tai = functions::checkout($_POST['old_pass']);
	$pass_moi = functions::checkout($_POST['pass']);
	$nhap_lai_pass = functions::checkout($_POST['re_pass']);

	// dieu kien xac nhan
	if ($pass_hien_tai == NULL || $pass_moi == NULL || $nhap_lai_pass == NULL) {
		echo '<div class="list1" style="color:red">Bạn chưa nhập đầy đủ thông tin !</div>';
	} else if ($old_password != $password_user['password']) {
		echo '<div class="list1" style="color:red">Mật khẩu hiện tại bạn nhập không đúng !</div>';
	} else if ($password != $re_password) {
		echo '<div class="list1" style="color:red">Mật khẩu cấp 2 bạn nhập không khớp nhau !</div>';
	} else {
		// khi da vuot qua cac dieu kien
		mysql_query("UPDATE users SET password_2 = '{$password}' WHERE id = $user_id");
		echo '<div class="list1" style="color:green">Bạn đã tạo password cấp 2 của bạn thành công, pass của bạn là "<b>'.$pass_moi.'</b>" bạn hãy nhớ lấy password cấp 2 này nhé !</div>';
		echo '</div>';
		require_once ('../incfiles/end.php');
		exit;
	}
}

echo '<div class="list1">';
echo '<form method="POST">';
echo '<p>Mật khẩu hiện tại:</p><p><input name="old_pass" type="password"></p>';
echo '<p>Tạo password cấp 2:</p><p><input name="pass" type="password"></p>';
echo '<p>Nhập lại password cấp 2:</p><p><input name="re_pass" type="password"></p>';
echo '<p><input name="submit" type="submit" value="Thực hiện"></p>';
echo '</form>';
echo '</div>';
echo '</div>';
require_once ('../incfiles/end.php');
?>