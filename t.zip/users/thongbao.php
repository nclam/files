<?php

/*
 * @package     VinaJohnCMS
 * @link        http://vina4u.pro
 * @copyright   Copyright (C) 2008-2011 VinaJohnCMS Community
 * @author      http://facebook.com/vina4uteam
 */



define('_IN_JOHNCMS',1);
require('../incfiles/core.php');
$textl='Thông báo mới';
require('../incfiles/head.php');
if (!$user_id) {
    echo '<div class="phdr">Thông báo</div><div class="list1">Chức năng chỉ dành cho thành viên tham gia diễn đàn!</div>';
    require('../incfiles/end.php');
    exit;
}
$hanhdong=array("trả lời bạn","thích bài viết của bạn");
$demnew=mysql_result(mysql_query("select count(*) from `thongbao` where `type`='f' and `id_to`='{$user_id}'"),0);
$demold=mysql_result(mysql_query("select count(*) from `thongbao` where `type`='t' and `id_to`='{$user_id}'"),0);
$total=mysql_result(mysql_query("select count(*) from `thongbao` where `id_to`='{$user_id}'"),0);
if(isset($_GET['del'])){
if (isset($_GET['yes'])) {
$dc = $_SESSION['dc'];
$prd = $_SESSION['prd'];
foreach ($dc as $delid) {
mysql_query("DELETE FROM `thongbao` WHERE `id_to` = '{$user_id}' AND `id`='" . intval($delid) . "'");
}
header("Location: thongbao.php");
} else {
if (empty($_POST['del'])) {
      echo '<div class="list2" style="background:#FFB7B7">Bạn chưa chọn mục nào!</div>';
}
foreach ($_POST['del'] as $v) {
$dc[] = intval($v);
}
$_SESSION['dc'] = $dc;
$_SESSION['prd'] = htmlspecialchars(getenv("HTTP_REFERER"));
echo '<div class="list2" style="background:#FFB7B7">bạn thực sự muốn xóa?<br/><a href="thongbao.php?del&amp;yes">Xóa</a> | <a href="thongbao.php">Hủy</a></div>';
}
	} else if(isset($_GET['delall'])){
mysql_query("delete from `thongbao` where `id_to`='{$user_id}'");
header("Location: thongbao.php");
		}
    echo '<div class="phdr">thông báo mới</div>';
if($total==0){
    echo '<div class="list1">';
    echo '<b>Bạn không có thông báo nào...!</b>';
    echo '</div>';
    echo '<div class="phdr"><a href="../index.php">trở lại</a></div>';
    require('../incfiles/end.php');
    exit;
}
echo '<form action="thongbao.php?del" method="POST">';
if($demnew==0){
	echo '<div class="list1">';
    echo 'Chưa có thông báo nào gần đây!';
    echo '</div>';
} else {
$req = mysql_query("SELECT * FROM `thongbao` WHERE `id_to` = '".$user_id."' AND `type`='f' ORDER BY `time` DESC");
$i = 0;
while (($res = mysql_fetch_assoc($req)) !== false) {
$topic = mysql_fetch_array(mysql_query("SELECT * FROM `forum` WHERE `id` = '{$res['id_forum']}' AND `type`='t'"));
    echo '<div class="list1" style="background:#FFFFD5">';
    echo '<input type="checkbox" name="del[]" value="'.$res['id'].'">';

    echo '<a href="../users/profile.php?user='.$res['id_from'].'">'.nick($res['id_from']).'</a> đã '.$hanhdong[$res['hanhdong']].' trong chủ đề : <a href="../forum/?id='.$topic['id'].'&page='.$inu[0].'#'.$inu[1].'">'.$topic['text'].'</a><br/><span class="gray">'.functions::display_date($res['time']).'</span>';
    echo '</div>';
    ++$i;
}
mysql_query("UPDATE `thongbao` SET `type`='t' WHERE `type`='f' AND `id_to` = '{$user_id}'");}
if($demold > 0){
	echo '<div class="phdr">Thông báo cũ hơn</div>';
$reqc = mysql_query("SELECT * FROM `thongbao` WHERE `id_to` = '".$user_id."' AND `type`='t' ORDER BY `time` DESC LIMIT  $start, $kmess");
$i = 0;
while (($resc = mysql_fetch_assoc($reqc)) !== false) {
$topic = mysql_fetch_array(mysql_query("SELECT * FROM `forum` WHERE `id` = '{$resc['id_forum']}' AND `type`='t'"));
    echo '<div class="list1">';
    echo '<input type="checkbox" name="del[]" value="'.$resc['id'].'">';
$inu=explode("|",$resc['text']);
    echo '<a href="../users/profile.php?user='.$resc['id_from'].'">'.nick($resc['id_from']).'</a> đã '.$hanhdong[$resc['hanhdong']].' trong chủ đề : <a href="../forum/?id='.$topic['id'].'&page='.$inu[0].'#'.$inu[1].'">'.$topic['text'].'</a><br/><span class="gray">'.functions::display_date($resc['time']).'</span>';
    echo '</div>';
    ++$i;
}
if ($demold > $kmess)
    echo '<div class="topmenu">' . functions::display_pagination('thongbao.php?', $start, $demold, $kmess) . '</div>';
}
if($total > 0)
    echo '<input type="submit" value="xóa mục đã chọn"></form><a href="thongbao.php?delall">xóa tất cả</a>';
   echo '<div class="phdr"><a href="../index.php">trở lại</a></div>';
require_once('../incfiles/end.php');
?>