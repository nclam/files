<?php

/**
 * @package     VinaJohnCMSVN 
 * @link        http://vina4u.Pro
 * @copyright   Copyright (C) 2015-2016 VinaJohnCMSVN Community
 * @author      Vina4u Team
 */
mysql_query("UPDATE `users` SET $sql `total_on_site`= '$totalonsite', `lastdate` = " . time() . " WHERE `id` = '2'");
//--- Mod tháống kê online ---//
$gbot = 0;$msn = 0;$baidu = 0;$bing = 0;$mj = 0;$coccoc = 0;$facebook = 0;$yandex = 0;
$users = mysql_result(mysql_query("SELECT COUNT(*) FROM `users` WHERE `lastdate` > '" . (time() - 600) . "'"), 0);
$guests = mysql_result(mysql_query("SELECT COUNT(*) FROM `cms_sessions` WHERE `lastdate` > '" . (time() - 600) . "'"), 0);
$tong = $users + $guests;$onltime = time() - 600;
$spider = mysql_query("SELECT * FROM `cms_sessions` WHERE `lastdate` > '" . (time() - 600) . "' ORDER BY `lastdate` DESC LIMIT 900");
while ($res = mysql_fetch_assoc($spider)) {
if(stristr($res['browser'], 'Google')) {$gbot = $gbot + 1;}
if(stristr($res['browser'], 'msnbot')) {$msn = $msn + 1;}
if(stristr($res['browser'], 'Baidu')) {$baidu = $baidu + 1;}
if(stristr($res['browser'], 'bingbot')) {$bing = $bing + 1;}
if(stristr($res['browser'], 'MJ12')) {$mj = $mj + 1;}
if(stristr($res['browser'], 'coccoc')) {$coccoc = $coccoc + 1;}
if(stristr($res['browser'], 'facebook')) {$facebook = $facebook + 1;}
if(stristr($res['browser'], 'Yandex')) {$yandex = $yandex + 1;}
}
echo '<div class="phdr"><i class="fa fa-globe"></i> Trực tuyến VinaJohn</div>';
echo '<div class="list1"><font color="green">» </font>Có <b>'.$tong.' Members Trực tuyến</b>, gồm '.$users.' Thành Viên và '.($guests - ($gbot + $msn + $baidu + $bing + $mj + $coccoc + $facebook + $yandex)).' Khách, và  '.($gbot + $msn + $baidu + $bing + $mj + $coccoc + $facebook + $yandex).' BOT.<br/>';

$thanhvienmoi=mysql_fetch_assoc(mysql_query("SELECT * FROM `users` ORDER BY `datereg` DESC LIMIT 1"));
echo '<br /><font color="green">» </font>Chào mừng thàn viên mới: <a href="'.$home.'/users/profile.php?user='.$thanhvienmoi['id'].'">'.nick($thanhvienmoi['id']).'</a>.';
echo '</div>';
?>