<?php

 /*
 * @package     Kenh10s.Com
 * @link        https://kenh10s.com
 * @copyright   Copyright (C) 2015-2016 Kenh10s.
 * @Mod         Châu Huỳnh
 * @Coder       Gazenwagen 
 */

defined('_IN_JOHNCMS') or die('Error: restricted access');

$mp = new mainpage();



/*
-----------------------------------------------------------------
Блок общения
-----------------------------------------------------------------
*/






/// KET THUC ///

function prefix_forum($id,$name){
global $set;
$catso['name'] = strip_tags($name);

$text = $name;
$a = array();

$a[] = '<span color="red">'.$catso['name'].'</span>';
$a[] = '<span color="red">'.$catso['name'].'</span>';
$a[] = '<span color="red">'.$catso['name'].'</span>';
$a[] = '<span color="red">'.$catso['name'].'</span>';
$a[] = '<span color="red">'.$catso['name'].'</span>';
$a[] = '<span color="red">'.$catso['name'].'</span>';
$a[] = '<span color="red">'.$catso['name'].'</span>';
$a[] = '<span color="red">'.$catso['name'].'</span>';
if(!empty($text)){
return $a[rand(0, count($a)-1)];
}

}

////////// Kenh10s.Com////
echo '<div class="row"><div class="col-sm-8"><div class="menu"><i class="fa fa-book"></i>  Mới Cập Nhật </div>';
$tong = mysql_result(mysql_query("SELECT COUNT(*) FROM `forum` WHERE `type` = 't' and kedit='0' AND `close`!='1'"), 0);
$req = mysql_query("SELECT * FROM `forum` WHERE `type` = 't' and kedit='0' AND `close`!='1' ORDER BY `time` DESC LIMIT $start, $kmess");
while ($arr = mysql_fetch_array($req)) {
$q3 = mysql_query("select `id`, `refid`, `text` from `forum` where type='r' and id='" .$arr['refid'] . "'");
$razd = mysql_fetch_array($q3);
$q4 = mysql_query("select `id`, `refid`, `text` from `forum` where type='f' and id='" .$razd['refid'] . "'");
$frm = mysql_fetch_array($q4);
$nikuser = mysql_query("SELECT `from`,`id`, `time` FROM `forum` WHERE `type` = 'm' AND `close` != '1' AND `refid` = '" . $arr['id'] . "'ORDER BY time DESC");
$colmes1 = mysql_num_rows($nikuser);
$cpg = ceil($colmes1 / $kmess);
$nam = mysql_fetch_array($nikuser);
echo is_integer($i / 2) ? '' : '';

$chauit= mysql_fetch_array(mysql_query("SELECT `text` FROM `forum` WHERE `type`='m' AND `refid`='". $arr [ 'id' ]. "' ORDER BY `id` ASC LIMIT 1" )); 
if( preg_match ('#\[img\](https?://.+?)\[\/img\]#i' ,$chauit['text'],$Img)){
$img =$Img [1 ];
 } else { 
$img ='http://gotruyen.xyz/noimg.png' ;
 } 
$desc = mysql_fetch_array(mysql_query("SELECT `text` FROM `forum` WHERE `id` = '".($arr['id']+1)."'"));

echo'
<div class="item"><img src="'.$img.'" width="56" height="60" alt="'.$arr['text'].'"/><i class="fa fa-rocket" style="color:#004b5d"></i> <a href="'.$home.'/forum/' . functions::vinarw($arr['text']) . '_' . $arr['id'] . '.html"><b>' . functions::smileys($arr['text']) . '</b></a> <br/>'.functions::Description_Topic(htmlspecialchars($desc['text']),200,$arr['description']).'<br/><br/> <i class="fa fa-eye"></i> '.$arr['view'].' Lượt Đọc</b>';
if ($cpg > 1)
echo ' <a href="'.$home.'/forum/' . functions::vinarw($arr['text']) . '_' . $arr['id'] . (!$set_forum['upfp'] && $set_forum['postclip'] ? '_clip_' : '') . ($set_forum['upfp'] ? '' : '_p' . $cpg) . '.html"></a>';


echo '</div>';
$i++;
}
if ($tong > $kmess){echo '<div class="topmenu"><center>' . functions::display_pagination('index.php?', $start, $tong, $kmess) . '</center></div>';
}
////////////END//////////////
////-Kenh10s.Com -////
echo '</div><div class="col-sm-4"><div class="menu"><a href="/news"> Thông Báo </a></div>';
echo $mp->news;

//Mod gim bài viết 
/*
$goi = mysql_query("SELECT * FROM `forum` WHERE `type` = 't' and kedit='0' AND `close`!='1' AND `vip` = '1' ORDER BY `time` DESC LIMIT 3");
while ($hien = mysql_fetch_array($goi)) {
echo '<div class="list4"><i class="fa fa-rss" style="color:#b55aa5"></i>
<a href="'.$home.'/forum/index.php?id=' . $hien['id'] . '">'.$hien['text']. '</a>';
echo '</div>';
$i++;
}
*/
echo '<div class="menu"><b>Xem Nhiều</b></div> ';
$sql = mysql_query("SELECT * FROM `forum` WHERE `type` = 't' && `close` = '0' order by view desc limit 5 ");
while($row = mysql_fetch_assoc($sql)){

echo is_integer($i / 2) ? '<div class="list3">' : '<div class="list4">';

echo '<i class="fa fa-rss" style="color:#b55aa5"></i> ';

echo '<a href="/forum/index.php?id='.$row['id'].'" title="'.$row['text'].'">' . bbcode::tags($row['text']) . '</a>'; 
if (!$is_mobile){
//echo '<font style="float:right;color:red;"> <b>'.$row['view'].'</b> Lượt Xem</font>';
}
echo '</div>';
}


////////// Kenh10s.Com //////








/*Thủ Thuật cập nhật*/
echo '<div class="menu"><b>Thủ Thuật Cập Nhật</b></div> ';
$total = mysql_result(mysql_query("SELECT COUNT(*) FROM `forum` WHERE `type`='t' AND `refid`='$id'" . ($rights >= 7 ? '' : " AND `close`!='1'")), 0);
$tong = mysql_result (mysql_query ("SELECT COUNT(*) FROM `forum` WHERE `type` ='t' and kedit='0' AND `close`!='1'" ), 0 );
$req = mysql_query("SELECT * FROM `forum` WHERE `type`='t'" . ($rights >= 7 ? '' : " AND `close`!='1'") . " AND (`refid`='12') ORDER BY `time` DESC LIMIT $start , $kmess");

while($row = mysql_fetch_assoc($req)){
$noidung = mysql_query("SELECT `id`, `refid`, `text` FROM `forum` WHERE `type`='m' AND `refid`='" . $row['id'] . "'");
echo '<div class="menu"><i class="fa fa-flag" style="color:#b55aa5"></i> <a href="'.$home.'/forum/'.functions::vinarw($row["text"]).'_' . $row['id'] . ($cpg > 1 && $set_forum['upfp'] && $set_forum['postclip'] ? '_clip_' : '') . ($set_forum['upfp'] && $cpg > 1 ? '_p' . $cpg : '.html') . '" title="'.bbcode::notags($row['text']).'"><font color="#8a2e7a">' . bbcode::tags($row['text']) . '</font></a></div>';
}
if ( $tong> $kmess ){echo'<div class="topmenu"><center><a id="submit" href="/forum/thu-thuat-cap-nhat_12.html">Xem Thêm</a></center></div>' ;}



		




//--chauit --------//
 echo '<div class="menu"><b>Các Thể Loại</b></div> ';
$reqq = mysql_query("SELECT * FROM `forum` WHERE `type`='r' ORDER BY `time` DESC LIMIT $start , $kmess");

while($roww = mysql_fetch_assoc($reqq)){
echo '<div class="list"> <i class="fa fa-refresh fa-spin""></i> <b><a href="'.$home.'/forum/'.functions::vinarw($roww['text']).'_' . $roww['id'].'.html"> '.$roww['text'].' </a></b></div>';
}

/////////

if (!$user_id) {
echo '<div class="mainblok"><div class="menu"><b>Đám mây từ khoá</b></div><div class="list1">';
$sta = mysql_query("SELECT * FROM `forum` WHERE `type`='t' ORDER BY rand() DESC LIMIT 0, 5");
while( $dat = mysql_fetch_assoc($sta)){
$tags=explode(' ',$dat['text']);
$dem = count($tags);
echo'<a href="/tags/'.$dat['text'].'">';
echo '<b>' . rand_size(rand_face(rand_color($dat['text']))) . '</b></a>, ';
for ($dem2=0; $dem2<$dem; $dem2++) {
$rand = array();
$rand[] = '';
$rand[] = '' . bbcode::notags($tags[$dem2]) . '';
$tag = $rand[rand(0, count($rand)-1)];
$ss = mb_strlen($tag);
if($ss > 3){
echo'<a href="/tags/'.$tags[$dem2].'">';
echo '<b>'.rand_size(rand_face(rand_color($tag))).'</b></a>, ';
}
}
}
echo '</div>';
}




?>