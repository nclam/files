<?php
define('_IN_JOHNCMS', 1);
$rootpath = '';
require('incfiles/core.php');
if (isset($_POST['msg'])) {
   $msg = isset($_POST['msg']) ? mb_substr(trim($_POST['msg']), 0, 5000) : '';
   $flood = functions::antiflood();
   if ($ban['1'] || $ban['13'])
       $error[] = $lng['access_forbidden'];
   if ($flood)
       $error = $lng['error_flood'] . ' ' . $flood . '&#160;' . $lng['seconds'];
   if (!$error) {
       $req = mysql_query("SELECT * FROM `guest` WHERE `user_id` = '$user_id' ORDER BY `time` DESC");
       $res = mysql_fetch_array($req);
       if ($res['text'] == $msg) {
           exit;
       }
   }
   if (!$error) {
       mysql_query("INSERT INTO `guest` SET
            `adm` = '$admset',
            `time` = '" . time() . "',
            `user_id` = '$user_id',
            `name` = '$from',
            `text` = '" . mysql_real_escape_string($msg) . "',
            `ip` = '" . core::$ip . "',
            `browser` = '" . mysql_real_escape_string($agn) . "'
       ");
	   
	   ## API Bot Chat Simsimi By Api.Vina4u.PRO ###
## Author : Hoàng Minh Thuận - Phạm Thanh Phong ##
## Home : Api.Vina4u.Pro - Vina4u Team ##


/////Cấu hình BOT SimSimi API///////
   $tatmo = 1; //Tắt mở BOT, 1 là mở, 0 là tắt
   
   $loaitraloi = "cuphap";
   $tukhoa = "#sim_";
   //Tạo một user làm user BOT và nhập ID của user đó vào đây
   $idbot = 2;
   
   //Cấu hình API
   $loctuxau = "0"; //Lọc những từ nói bậy. 0 là không lọc và 1 là có lọc. Mặc định là 0.
   $tenbot = "Bác TOM"; //Cái này sẽ thay thế tất cả tên bot là simsimi thành tên của bạn truyền vào. Mặc định là SieuLeech
   //End cấu hình BOT///
   
//GET Câu trả lời từ API 
$check = 0;
if($tatmo)
{
if($loaitraloi == "cuphap")
{
$test = "aaa".$msg;
$temp = explode($tukhoa,$test);
if($temp[0] == "aaa")
{
$check = 1;
$msg = $temp[1];
}
}
if($loaitraloi == "toanbo")
{
if(stripos(strtolower($msg), $tukhoa) !== false)
{
$check = 1;
}
}
if($check)
{
$c = curl_init("http://api.vina4u.pro/api.php?text=$msg");
curl_setopt($c, CURLOPT_SSL_VERIFYPEER,false);
curl_setopt($c, CURLOPT_SSL_VERIFYHOST,false);
curl_setopt($c, CURLOPT_FOLLOWLOCATION, true);
curl_setopt($c, CURLOPT_RETURNTRANSFER, true);
$traloi = curl_exec($c);
curl_close($c);
$traloi = trim($traloi);
if($traloi == "error")
{
$traloi = "Câu này mình chưa được học. Bạn có thể dạy cho mình chứ ?!";
}
$time = time() + 2;
mysql_query("INSERT INTO `guest` SET
                `adm` = '$admset',
                `time` = '" . $time. "',
                `user_id` = '" .$idbot. "',
                `name` = '$tenbot',
                `text` = '" . mysql_real_escape_string($traloi) . "',
                `ip` = '" . core::$ip . "',
                `browser` = '" . mysql_real_escape_string($agn) . "',
                `otvet` = ''
");
}
}
//////End Bot//////
	   
	   
       if ($user_id) {
          $postguest = $datauser['postguest'] + 1;
          mysql_query("UPDATE `users` SET `postguest` = '$postguest', `lastpost` = '" . time() . "' WHERE `id` = '$user_id'");
       }
   }
}
$total = mysql_result(mysql_query("SELECT COUNT(*) FROM `guest` WHERE `adm`='0'"), 0);
  if ($total) {
        $req = mysql_query("SELECT `guest`.*, `guest`.`id` AS `gid`, `users`.`lastdate`, `users`.`id`, `users`.`rights`, `users`.`name`
                    FROM `guest` LEFT JOIN `users` ON `guest`.`user_id` = `users`.`id`
                    WHERE `guest`.`adm`='0' ORDER BY `time` DESC LIMIT ".(!$is_mobile ? 10 : 10)."");
echo '<div class="forumtxt">';
        while ($gres = mysql_fetch_assoc($req)) {
        $post = $gres['text'];
        $post = functions::checkout($gres['text'], 1, 1);
        if ($set_user['smileys'])
          $post = functions::smileys($post, $gres['rights'] ? 1 : 0);
          $outputhtml .= (time() > $gres['lastdate'] + 600 ? ' <div class="list1"><img src="/images/offline.png" title="Ngoại Tuyến" /> ' : ' <div class="list1"><img src="/images/online.png" title="Trực Tuyến" /> ').'<a href="/users/profile.php?user='.$gres['id'].'">'. nick($gres['id']).'</a>: '.$post.'<br /> <font style="font-size:10px;color:green"><b>('.functions::thoigian($gres['time']).') <img src="/images/reply2.png" title="trả lời" /></b></font></div>';
          ++$i;
        }
      echo $outputhtml;
echo '</div>';
  }
?>