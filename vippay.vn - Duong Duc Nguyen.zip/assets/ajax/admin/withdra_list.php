<?php
/*
#########################################################
#               Code Edit By LuaUyTin                   #
#              Email: megashopnick@gmail.com            #
#            Phone: 0984.459.954 - 0965.783.736         #
#            Vui Lòng Tôn Trọng Quyền Tác Giả           #
#########################################################
*/

// Kết nối database và thông tin chung
require_once(realpath($_SERVER["DOCUMENT_ROOT"]) .'/core/init.php');
$get_info = new Info;
if ($data_user['admin'] < 1) {
?>
<div class="alert alert-warning">Bạn không phải là Admin nên không thể xem được nội dung này
<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button>
</div>
<?php
exit;
}elseif(!$_POST){
exit;
}

$input = new Input;
$page = (int)$input->input_post("page");
$username = $input->input_post("username");
$where = "`status` = '0' ";

if (!empty($username)) {
$where .= "AND username LIKE '%$username%'";
}


$total_record = $db->fetch_row("SELECT COUNT(id) FROM history_atm WHERE $where LIMIT 1");
    // config phân trang
    $config = array(
      "current_page" => $page,
      "total_record" => $total_record,
      "limit" => "20",
      "range" => "5",
      "link_first" => "",
      "link_full" => "?page={page}"
    );
    
    $paging = new Pagination;
    $paging->init($config);
    $sql_get_list_mem = "SELECT * FROM `history_atm` WHERE $where ORDER BY `time` ASC LIMIT {$paging->getConfig()["start"]}, {$paging->getConfig()["limit"]}";

// Nếu có 
if ($total_record){
?>
                        <table  class="table table-bordered">
                            <thead>
                                <tr style="background-color:black;">
                                    <th class="text-center" style="color:white;font-weight:bold;">ID</th>
                                    <th class="text-center" style="color:white;font-weight:bold;">Username</th>
                                    <th class="text-center" style="color:white;font-weight:bold;">Số tiền</th>
                                    <th class="text-center" style="color:white;font-weight:bold;">Thực nhận</th>
                                    <th class="text-center" style="color:white;font-weight:bold;">Ngân hàng</th>
                                    <th class="text-center" style="color:white;font-weight:bold;">Chủ tài khoản</th>
                                    <th class="text-center" style="color:white;font-weight:bold;">Số tài khoản</th>
                                    <th class="text-center" style="color:white;font-weight:bold;">Số thẻ</th>
                                    <th class="text-center" style="color:white;font-weight:bold;">Chi nhánh</th>
                                    <th class="text-center" style="color:white;font-weight:bold;">Thời gian</th>
                                    <th class="text-center" style="color:white;font-weight:bold;">Thao tác</th>
                                </tr>
                            </thead>
                        <tbody>
<?php                            
$i=1;
foreach ($db->fetch_assoc($sql_get_list_mem, 0) as $key => $data){ 
    $info_atm = $db->fetch_assoc("SELECT * FROM data_atm WHERE username = '".$data['username']."' AND ngan_hang = '".$data['ngan_hang']."' LIMIT 1", 1); 
?>
                            <tr>
                                    <td class="text-center"><?php echo $data['id']; ?></td>
                                    <td class="text-center"><?php echo $data['username']; ?></td>
                                    <td class="text-center"><?php echo $data['cash']; ?></td>
                                    <td class="text-center"><?php echo $data['cash_nhan']; ?></td>
                                    <td class="text-center"><?php echo $data['ngan_hang']; ?></td>
                                    <td class="text-center"><?php echo $info_atm['chu_tk']; ?></td>
                                    <td class="text-center"><?php echo $info_atm['so_tk']; ?></td>
                                    <td class="text-center"><?php echo $info_atm['so_the']; ?></td>
                                    <td class="text-center"><?php echo $info_atm['chi_nhanh']; ?></td>
                                    <td class="text-center"><?php echo $data['time']; ?></td>
                                    <td class="text-center">
                                     <button class="btn btn-sm btn-success col-md-4" onclick="status_atm('<?php echo $data['id']; ?>','1','<?php echo $get_info->status_withdra(1); ?>');">Thành công</button>
                                     <button class="btn btn-sm btn-warning col-md-4" onclick="status_atm('<?php echo $data['id']; ?>','2','<?php echo $get_info->status_withdra(2); ?>');">Sai T.T ATM</button>
                                     <button class="btn btn-sm btn-info col-md-4" onclick="status_atm('<?php echo $data['id']; ?>','3','<?php echo $get_info->status_withdra(3); ?>');">Bảo trì</button>
                                    </td>
                            </tr>



<?php 
$i++;
}
?>
                        </tbody>
                        
                        </table>
                    
<?php                     
echo $paging->html_list(); // page
}else {
?>
<div class="alert alert-info">Không có yêu cầu nào
<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button>
</div>
<?php
}
?>




