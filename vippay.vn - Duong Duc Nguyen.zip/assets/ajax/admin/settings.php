<?php
/*
#########################################################
#               Code Edit By LuaUyTin                   #
#              Email: megashopnick@gmail.com            #
#            Phone: 0984.459.954 - 0965.783.736         #
#            Vui Lòng Tôn Trọng Quyền Tác Giả           #
#########################################################
*/
 
// Kết nối database và thông tin chung
require_once(realpath($_SERVER["DOCUMENT_ROOT"]) .'/core/init.php');
// Nếu đăng nhập
if ($user && $data_user['admin'] > 0) 
{
    $title_web = trim(htmlspecialchars(addslashes($_POST['title'])));
    $descr_web = trim(htmlspecialchars(addslashes($_POST['descr'])));
    $thongbao = trim(htmlspecialchars(addslashes($_POST['thongbao'])));
    $keywords_web = trim(htmlspecialchars(addslashes($_POST['keywords'])));
    $status = trim(htmlspecialchars(addslashes($_POST['status'])));
    $name_admin = trim(htmlspecialchars(addslashes($_POST['name_admin'])));
    $fb_admin = trim(htmlspecialchars(addslashes($_POST['fb_admin'])));
    $fanpage = trim(htmlspecialchars(addslashes($_POST['fanpage'])));
    $phone_admin = trim(htmlspecialchars(addslashes($_POST['phone_admin'])));
    $price_atm = trim(htmlspecialchars(addslashes($_POST['price_atm'])));
    $email_admin = trim(htmlspecialchars(addslashes($_POST['email_admin'])));
    
    //Api gachthe.vn
    $merchant_key = trim(htmlspecialchars(addslashes($_POST['merchant_key'])));
    
    if (isset($_POST['api_gachthe'])){
        if(empty($merchant_key)){
            echo json_encode(array('status' => "error",'link'=> "#", 'title' => "Lỗi", 'msg' => "Vui lòng nhập đầy đủ thông tin !"));exit();}
        //Cập nhật vào db
        $db->query("UPDATE settings SET `merchant_key` = '$merchant_key'");
        echo json_encode(array('status' => "success",'link' => "/admin/settings/api", 'title' => "Thành công", 'msg' => "Lưu thông tin API thành công !"));exit();}
   
   
    $sql_info_web = "UPDATE settings SET 
        title = '$title_web',
        descr = '$descr_web',
        keywords = '$keywords_web',
        name_admin = '$name_admin',
        fb_admin = '$fb_admin',
        fanpage = '$fanpage',
        phone_admin = '$phone_admin',
        email_admin = '$email_admin',
        thongbao = '$thongbao',
        price_atm = '$price_atm'
    ";
    $db->query($sql_info_web);
    $db->close();
    echo json_encode(array('status' => "success",'link' => "/admin/settings/general", 'title' => "Thành công", 'msg' => "Lưu cài đặt thành công"));
}
else {
    echo json_encode(array('status' => "error",'link' => "#", 'title' => "Lỗi", 'msg' => "Bạn chưa đăng nhập hoặc không phải là Admin"));
}
?>