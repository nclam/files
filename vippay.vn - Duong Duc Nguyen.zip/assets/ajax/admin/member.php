<?php
/*
#########################################################
#               Code Edit By LuaUyTin                   #
#              Email: megashopnick@gmail.com            #
#            Phone: 0984.459.954 - 0965.783.736         #
#            Vui Lòng Tôn Trọng Quyền Tác Giả           #
#########################################################
*/

// Kết nối database và thông tin chung
require_once(realpath($_SERVER["DOCUMENT_ROOT"]) .'/core/init.php');
$get_info_card = new Info;
if (!$user and $data_user['admin'] < 1) {
?>
<div class="alert alert-warning">Vui lòng đăng nhập để xem thông tin
<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button>
</div>
<?php
exit;
}elseif(!$_POST){
exit;
}

$input = new Input;
$page = (int)$input->input_post("page");
$username = $input->input_post("username");
$name = $input->input_post("name");
$phone = $input->input_post("phone");
$email = $input->input_post("email");
$where = "`id` != '0' ";
if (!empty($username)) {
$where .= "AND username LIKE '%$username%'";
}
if (!empty($name)) {
$where .= "AND name LIKE '%$name%'";
}
if (!empty($phone)) {
$where .= "AND phone LIKE '%$phone%'";
}
if (!empty($email)) {
$where .= "AND email LIKE '%$email%'";
}

$total_record = $db->fetch_row("SELECT COUNT(id) FROM accounts WHERE $where LIMIT 1");
    // config phân trang
    $config = array(
      "current_page" => $page,
      "total_record" => $total_record,
      "limit" => "20",
      "range" => "5",
      "link_first" => "",
      "link_full" => "?page={page}"
    );
    
    $paging = new Pagination;
    $paging->init($config);
    $sql_get_list_mem = "SELECT * FROM `accounts` WHERE $where ORDER BY `admin` DESC, `time` DESC LIMIT {$paging->getConfig()["start"]}, {$paging->getConfig()["limit"]}";

// Nếu có 
if ($total_record){
?>
                        <table  class="table table-bordered">
                             <thead><tr style="background-color:black;">
                                    <th class="text-center" style="color:white;font-weight:bold;">ID</th>
                                    <th class="text-center" style="color:white;font-weight:bold;">Name</th>
                                    <th class="text-center" style="color:white;font-weight:bold;">Username</th>
                                    <th class="text-center" style="color:white;font-weight:bold;">Phone</th>
                                    <th class="text-center" style="color:white;font-weight:bold;">Email</th>
                                    <th class="text-center" style="color:white;font-weight:bold;">Cash</th>
                                    <th class="text-center" style="color:white;font-weight:bold;">Thời gian</th>
                                    <th class="text-center" style="color:white;font-weight:bold;">Thao tác</th>
                                </tr></thead>
                        <tbody>
<?php                            
$i=1;
foreach ($db->fetch_assoc($sql_get_list_mem, 0) as $key => $data){ 
?>


                             <tr>
                                    <td class="text-center"><a target="_blank" style="<?php echo($data['admin'] == 1) ? "color: green;font-weight: bold;":""; ?><?php echo($data['admin'] >= 10) ? "color: red;font-weight: bold;":""; ?><?php echo($data['block'] > 0) ? "color: black;font-weight: bold;":""; ?>"><?php echo $data['id']; ?></td>
                                    <td class="text-center"><a target="_blank" style="<?php echo($data['admin'] == 1) ? "color: green;font-weight: bold;":""; ?><?php echo($data['admin'] >= 10) ? "color: red;font-weight: bold;":""; ?><?php echo($data['block'] > 0) ? "color: black;font-weight: bold;":""; ?>"><?php echo $data['name']; ?></a></td>
                                    <td class="text-center"><a target="_blank" style="<?php echo($data['admin'] == 1) ? "color: green;font-weight: bold;":""; ?><?php echo($data['admin'] >= 10) ? "color: red;font-weight: bold;":""; ?><?php echo($data['block'] > 0) ? "color: black;font-weight: bold;":""; ?>"><?php echo $data['username']; ?></a></td>
                                    <td class="text-center"><?php echo $data['phone']; ?></td>
                                    <td class="text-center"><?php echo $data['email']; ?></td>
                                    <td class="text-center"><?php echo number_format($data['cash'], 0, '.', '.'); ?> <sup>đ</sup></td>
                                    <td class="text-center"><?php echo $data['time']; ?></td>
                                    <td class="text-center"><div class="btn-group"><a href="/admin/member/<?php echo $data['username']; ?>" target="_blank">
                                    <button class="btn btn-xs btn-default" type="button" data-toggle="tooltip">Xem</button>
                                    </a></div></td>
                            </tr>



<?php 
$i++;
}
?>
                        </tbody>
                        
                        </table>
                    
<?php                     
echo $paging->html_list(); // page
}else {
?>
<div class="alert alert-info">Không tìm thấy thành viên
<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button>
</div>
<?php
}
?>




