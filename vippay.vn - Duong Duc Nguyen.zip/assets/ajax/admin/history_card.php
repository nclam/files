<?php
/*
#########################################################
#               Code Edit By LuaUyTin                   #
#              Email: megashopnick@gmail.com            #
#            Phone: 0984.459.954 - 0965.783.736         #
#            Vui Lòng Tôn Trọng Quyền Tác Giả           #
#########################################################
*/

// Kết nối database và thông tin chung
require_once(realpath($_SERVER["DOCUMENT_ROOT"]) .'/core/init.php');
$get_info_card = new Info;
if (!$user) {
?>
<div class="alert alert-warning">Vui lòng đăng nhập để xem thông tin
<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button>
</div>
<?php
exit;
}elseif(!$_POST){
exit;
}

$iduser = $data_user['username'];
$input = new Input;
$page = (int)$input->input_post("page");
$seri = $input->input_post("seri");
$pin = $input->input_post("pin");
$username = $input->input_post("username");
$where = "`id` != '0' ";

if (!empty($seri)) {
$where .= "AND seri LIKE '%$seri%'";
}
if (!empty($pin)) {
$where .= "AND pin LIKE '%$pin%'";
}
if (!empty($username)) {
$where .= "AND username LIKE '%$username%'";
}

$total_record = $db->fetch_row("SELECT COUNT(id) FROM history_card WHERE $where LIMIT 1");
    // config phân trang
    $config = array(
      "current_page" => $page,
      "total_record" => $total_record,
      "limit" => "20",
      "range" => "5",
      "link_first" => "",
      "link_full" => "?page={page}"
    );
    
    $paging = new Pagination;
    $paging->init($config);
    $sql_get_list_mem = "SELECT * FROM `history_card` WHERE $where ORDER BY `time` DESC  LIMIT {$paging->getConfig()["start"]}, {$paging->getConfig()["limit"]}";

// Nếu có 
if ($total_record){
?>
                        <table  class="table table-bordered">
                             <thead><tr style="background-color:black;">
                                    <th class="text-center" style="color:white;font-weight:bold;">#</th>
                                    <th class="text-center" style="color:white;font-weight:bold;"><b>Username</b></th>
                                    <th class="text-center" style="color:white;font-weight:bold;"><b>Loại thẻ</b></th>
                                    <th class="text-center" style="color:white;font-weight:bold;">Serial</th>
                                    <th class="text-center" style="color:white;font-weight:bold;">Mã thẻ</th>
                                    <th class="text-center" style="color:white;font-weight:bold;">Mệnh giá</th>
                                    <th class="text-center" style="color:white;font-weight:bold;">Thực nhận</th>
                                    <th class="text-center" style="color:white;font-weight:bold;">Trạng thái</th>
                                    <th class="text-center" style="color:white;font-weight:bold;">Thời gian</th>
                                </tr></thead>
                        <tbody>
<?php                            
$i=1;
foreach ($db->fetch_assoc($sql_get_list_mem, 0) as $key => $data){ 
?>


                             <tr>
                                    <td class="text-center"><?php echo $data['id']; ?></td>
                                    <td class="text-center"><?php echo $data['username']; ?></td>
                                    <td class="text-center"><?php echo $get_info_card->get_string_card($data["type_card"]); ?></td>
                                    <td class="text-center"><b><?php echo $data['seri']; ?></b></td>
                                    <td class="text-center"><b><?php echo $data['pin']; ?></b></td>
                                    <td class="text-center"><?php echo number_format($data['count_card'], 0, '.', '.'); ?>đ</td>
                                    <td class="text-center"><?php echo number_format($data['cash_nhan'], 0, '.', '.'); ?>đ</td>
                                    <td class="text-center"><?php echo $get_info_card->get_string_status_card($data["status"]); ?></td>
                                    <td class="text-center"><?php echo $data['time']; ?></td>
                            </tr>



<?php 
$i++;
}
?>
                        </tbody>
                        
                        </table>
                    
<?php                     
echo $paging->html_list(); // page
}else {
?>
<div class="alert alert-info">Không tìm thấy thông tin
<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button>
</div>
<?php
}
?>




