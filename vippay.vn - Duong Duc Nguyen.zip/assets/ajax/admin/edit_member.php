<?php
/*
#########################################################
#               Code Edit By LuaUyTin                   #
#              Email: megashopnick@gmail.com            #
#            Phone: 0984.459.954 - 0965.783.736         #
#            Vui Lòng Tôn Trọng Quyền Tác Giả           #
#########################################################
*/
 
// Kết nối database và thông tin chung
require_once(realpath($_SERVER["DOCUMENT_ROOT"]) .'/core/init.php');

$input = new Input;
$id = (int)$input->input_post("id");

// Nếu đăng nhập
if ($user && $data_user['admin'] > 0) {   
    
    $name = trim(htmlspecialchars(addslashes($_POST['name'])));
    $admin = trim(htmlspecialchars(addslashes($_POST['admin'])));
    $email = trim(htmlspecialchars(addslashes($_POST['email'])));
    $cash = trim(htmlspecialchars(addslashes($_POST['cash'])));
    $phone = trim(htmlspecialchars(addslashes($_POST['phone'])));
    $point = trim(htmlspecialchars(addslashes($_POST['point'])));
    $username = trim(htmlspecialchars(addslashes($_POST['username'])));
    $note = trim(htmlspecialchars(addslashes($_POST['note'])));
    $block = trim(htmlspecialchars(addslashes($_POST['block'])));
    
    //Kiểm tra admin user
    $sql_get = "SELECT * FROM accounts WHERE username = '$username'";
    $data = $db->fetch_assoc($sql_get, 1);

    if($data_user['admin'] < $data['admin']){
        echo json_encode(array('status' => "error", 'title' => "Lỗi", 'msg' => "Bạn không có quyền thay đổi thông tin của ".$username.""));exit(); }
    if($data_user['admin'] == $data['admin'] and $username != $data_user['username']){
        echo json_encode(array('status' => "error", 'title' => "Lỗi", 'msg' => "Bạn không thể thay đổi thông tin của ".$username.""));exit(); }
    if ($block == "0"){$note = "";}
    
    $sql_info = "UPDATE accounts SET 
        name = '$name',
        admin = '$admin',
        email = '$email',
        point = '$point',
        cash = '$cash',
        phone = '$phone',
        block = '$block',
        note = '$note'
        WHERE `username` ='$username'";
    $db->query($sql_info);
    $db->close();
    
    echo json_encode(array('status' => "success", 'title' => "Thành công", 'msg' => "Cập nhật dữ liệu cho ".$username." thành công !"));
    
}
else {
    echo json_encode(array('status' => "error", 'title' => "Lỗi", 'msg' => "Bạn chưa đăng nhập hoặc không phải là Admin"));
}
?>