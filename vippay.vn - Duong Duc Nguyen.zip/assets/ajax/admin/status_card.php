<?php
/*
#########################################################
#               Code Edit By LuaUyTin                   #
#              Email: megashopnick@gmail.com            #
#            Phone: 0984.459.954 - 0965.783.736         #
#            Vui Lòng Tôn Trọng Quyền Tác Giả           #
#########################################################
*/
// Kết nối database và thông tin chung
require_once(realpath($_SERVER["DOCUMENT_ROOT"]) .'/core/init.php');
// Nếu đăng nhập
if ($user && $data_user['admin'] > 0) 
{ 
/*
    //trạng thái gạch tự động
     $db->query("UPDATE auto_card SET `1` = '".$_POST['p1']."',`2` = '".$_POST['p2']."',`3` = '".$_POST['p3']."',`4` = '".$_POST['p4']."',`5` = '".$_POST['p5']."',`7` = '".$_POST['p7']."' WHERE `id` = '1'");
    
    //trạng thái gạch chậm
    $db->query("UPDATE auto_card SET `1` = '".$_POST['c1']."',`2` = '".$_POST['c2']."',`3` = '".$_POST['c3']."',`4` = '".$_POST['c4']."',`5` = '".$_POST['c5']."',`7` = '".$_POST['c7']."' WHERE `id` = '2'");
    
    //chiết khấu gạch tự động
    $db->query("UPDATE ck_card SET `1` = '100' - '".$_POST['cka1']."',`2` = '100' - '".$_POST['cka2']."',`3` = '100' - '".$_POST['cka3']."',`4` = '100' - '".$_POST['cka4']."',`5` = '100' - '".$_POST['cka5']."',`7` = '100' - '".$_POST['cka7']."' WHERE `id` = '1'");
    
    //chiết khấu gạch châm
    $db->query("UPDATE ck_card SET `1` = '100' - '".$_POST['ckc1']."',`2` = '100' - '".$_POST['ckc2']."',`3` = '100' - '".$_POST['ckc3']."',`4` = '100' - '".$_POST['ckc4']."',`5` = '100' - '".$_POST['ckc5']."',`7` = '100' - '".$_POST['ckc7']."' WHERE `id` = '2'");
*/  

    //trạng thái gạch tự động
     $db->query("UPDATE auto_card SET `1` = '".$_POST['p1']."',`2` = '".$_POST['p2']."',`3` = '".$_POST['p3']."' WHERE `id` = '1'");
    
    //trạng thái gạch chậm
    $db->query("UPDATE auto_card SET `1` = '".$_POST['c1']."',`2` = '".$_POST['c2']."',`3` = '".$_POST['c3']."' WHERE `id` = '2'");
    
    //chiết khấu gạch tự động
    $db->query("UPDATE ck_card SET `1` = '100' - '".$_POST['cka1']."',`2` = '100' - '".$_POST['cka2']."',`3` = '100' - '".$_POST['cka3']."' WHERE `id` = '1'");
    
    //chiết khấu gạch châm
    $db->query("UPDATE ck_card SET `1` = '100' - '".$_POST['ckc1']."',`2` = '100' - '".$_POST['ckc2']."',`3` = '100' - '".$_POST['ckc3']."' WHERE `id` = '2'");

    $db->close();
    echo json_encode(array('status' => "success", 'title' => "Thành công", 'msg' => "Lưu thay đổi thành công"));
}
else {
    echo json_encode(array('status' => "error", 'title' => "Lỗi", 'msg' => "Bạn chưa đăng nhập hoặc không phải là Admin"));
}
?>