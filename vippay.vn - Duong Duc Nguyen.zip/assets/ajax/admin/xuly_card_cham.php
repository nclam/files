<?php
/*
#########################################################
#               Code Edit By LuaUyTin                   #
#              Email: megashopnick@gmail.com            #
#            Phone: 0984.459.954 - 0965.783.736         #
#            Vui Lòng Tôn Trọng Quyền Tác Giả           #
#########################################################
*/
 
// Kết nối database và thông tin chung
require_once(realpath($_SERVER["DOCUMENT_ROOT"]) .'/core/init.php');

$input = new Input;
// Nếu đăng nhập
if ($user && $data_user['admin'] > 0) 
{
    
    $status = $_POST['status'];
    $id = $_POST['id'];
    //lấy dữ liệu id
    $data = $db->fetch_assoc("SELECT * FROM history_card where `id` = {$id} LIMIT 1", 1);
    $username = $data['username'];
    $cash_nhan = $data['cash_nhan'];
    
    if($data['status'] != 0){
        echo json_encode(array('status' => "error", 'title' => "Lỗi", 'msg' => "Giao dịch đã được xử lý rồi")); exit;}
    if($status != "1"){ $cash_nhan = 0;}
    $db->query("UPDATE history_card SET `status` = '{$status}' , `cash_nhan` = '{$cash_nhan}' WHERE `id` = '{$id}'");// trang thai
    
    $db->query("UPDATE accounts SET `cash` = `cash` + '{$cash_nhan}' WHERE `username` = '{$username}'");
    
    echo json_encode(array('status' => "success", 'title' => "Thành công", 'msg' => "Đã xử lý giao dịch"));exit;
}
else {
    echo json_encode(array('status' => "error", 'title' => "Lỗi", 'msg' => "Bạn chưa đăng nhập hoặc không phải là Admin"));
    exit;
}
?>