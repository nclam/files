<?php
/*
#########################################################
#               Code Edit By LuaUyTin                   #
#              Email: megashopnick@gmail.com            #
#            Phone: 0984.459.954 - 0965.783.736         #
#            Vui Lòng Tôn Trọng Quyền Tác Giả           #
#########################################################
*/

// Kết nối database và thông tin chung
require_once(realpath($_SERVER["DOCUMENT_ROOT"]) .'/core/init.php');
if(!$_POST){die();}
if (!$user) {
echo
'<div class="alert alert-warning">Vui lòng đăng nhập để xem thông tin
<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button>
</div>';exit;
}

$iduser = $data_user['username'];
$input = new Input;
$page = (int)$input->input_post("page");

$total_record = $db->fetch_row("SELECT COUNT(id) FROM `history_atm` WHERE `username` = '".$iduser."' LIMIT 1");
    // config phân trang
    $config = array(
      "current_page" => $page,
      "total_record" => $total_record,
      "limit" => "20",
      "range" => "5",
      "link_first" => "",
      "link_full" => "?page={page}"
    );
    
    $paging = new Pagination;
    $paging->init($config);
    $sql_get_list_mem = "SELECT * FROM `history_atm` WHERE `username` = '".$iduser."'ORDER BY `time` DESC  LIMIT {$paging->getConfig()["start"]}, {$paging->getConfig()["limit"]}";

// Nếu có 
if ($total_record){
?>
                        <table  class="table table-bordered">
                             <thead><tr style="background-color:black;">
                                    <th class="text-center" style="color:white;font-weight:bold;">ID</th>
                                    <th class="text-center" style="color:white;font-weight:bold;">Số tiền</th>
                                    <th class="text-center" style="color:white;font-weight:bold;">Thực nhận</th>
                                    <th class="text-center" style="color:white;font-weight:bold;">Ngân hàng</th>
                                    <th class="text-center" style="color:white;font-weight:bold;">Nội dung</th>
                                    <th class="text-center" style="color:white;font-weight:bold;">Trạng thái</th>
                                    <th class="text-center" style="color:white;font-weight:bold;">Thời gian</th>
                                </tr></thead>
                        <tbody>
<?php                            
$i=1;
foreach ($db->fetch_assoc($sql_get_list_mem, 0) as $key => $data){ 
?>


                             <tr>
                                    <td class="text-center"><?php echo $data['id']; ?></td>
                                    <td class="text-center"><b style="color:red;"><?php echo number_format($data['cash'], 0, '.', '.'); ?>đ</b></td>
                                    <td class="text-center"><b style="color:green;"><?php echo number_format($data['cash_nhan'], 0, '.', '.'); ?>đ</b></td>
                                    <td class="text-center"><?php echo $data['ngan_hang']; ?></td>
                                    <td class="text-center"><?php echo $data['note']; ?></td>
                                    <td class="text-center"><?php echo $get_info->status_withdra($data["status"]); ?></td>
                                    <td class="text-center"><?php echo $data['time']; ?></td>
                            </tr>



<?php 
$i++;
}
?>
                        </tbody>
                        
                        </table>
                    
<?php                     
echo $paging->html_list(); // page
}else {
?>
<div class="alert alert-info">Không tìm thấy thông tin
<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button>
</div>
<?php
}
?>




