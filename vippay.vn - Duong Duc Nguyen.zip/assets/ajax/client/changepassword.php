<?php
/*
#########################################################
#               Code Edit By LuaUyTin                   #
#              Email: megashopnick@gmail.com            #
#            Phone: 0984.459.954 - 0965.783.736         #
#            Vui Lòng Tôn Trọng Quyền Tác Giả           #
#########################################################
*/
require_once(realpath($_SERVER["DOCUMENT_ROOT"]) .'/core/init.php');
if (!$user) {
    echo json_encode(array('status' => "error",'link' => "/", 'title' => "Lỗi", 'msg' => "Bạn chưa đăng nhập"));
}else {
    $oldpassword = md5(md5($_POST['password']));
    $newpassword = $_POST['newpass'];
    $newpassword2 = $_POST['newpass2'];
    $iduser = $data_user['username'];
    $password = md5(md5($newpassword));
    if(empty($oldpassword) || empty($newpassword) || empty($newpassword2)){
        echo json_encode(array('link' => "#luauytin_0984459954",'status' => "error", 'title' => "Lỗi", 'msg' =>"Vui lòng điển đầy đủ thông tin"));exit();}
        
    if ($db->fetch_row("SELECT COUNT(*) FROM accounts WHERE username = '{$iduser}' AND password = '{$oldpassword}'") < 1) {
        echo json_encode(array('link' => "#luauytin_0984459954",'status' => "error", 'title' => "Lỗi", 'msg' =>"Mật khẩu cũ không chính xác"));exit();}
    
    if($newpassword !=$newpassword2){
        echo json_encode(array('link' => "#luauytin_0984459954",'status' => "error", 'title' => "Lỗi", 'msg' =>"Xác thực mật khẩu không trùng nhau"));exit();}
        
    if($oldpassword == $password){
        echo json_encode(array('link' => "#luauytin_0984459954",'status' => "error", 'title' => "Lỗi", 'msg' =>"Mật khẩu mới trùng mật khẩu cũ"));exit();}
        
    if(strlen($newpassword) < 6 ){
        echo json_encode(array('link' => "#luauytin_0984459954",'status' => "error", 'title' => "Thất bại", 'msg' => "Mật khẩu phải ít nhất 6 kí tự"));exit();}
    
    //cập nhật pass
    $db->query("UPDATE `accounts` SET `password` ='{$password}' WHERE `username` = '{$iduser}'");// cập nhật mật khẩu vào db
    echo json_encode(array('link' => "/logout.html", 'status' => "success",'title' => "Thành công", 'msg' => "Cập nhật mật khẩu thành công. Vui lòng đăng nhập lại !"));exit();

}
