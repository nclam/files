<?php
/*
#########################################################
#               Code Edit By LuaUyTin                   #
#              Email: megashopnick@gmail.com            #
#            Phone: 0984.459.954 - 0965.783.736         #
#            Vui Lòng Tôn Trọng Quyền Tác Giả           #
#########################################################
*/
require_once(realpath($_SERVER["DOCUMENT_ROOT"]) .'/core/init.php');
if (!$user) {
    echo json_encode(array('status' => "error",'link' => "/", 'title' => "Lỗi", 'msg' => "Bạn chưa đăng nhập"));
}else {
    $iduser = $data_user['username'];
    
    if(isset($_POST['id_del_atm']) and isset($_POST['bank_del']) and $_POST['id_del_atm'] != ""){
        $id_del = (int)$_POST['id_del_atm'];
        $bank_del = anti_xss($db->real_escape_string($_POST['bank_del']));
        $db->query("DELETE FROM data_atm WHERE id ='{$id_del}'");
        echo json_encode(array('link' => "/danh-sach-ngan-hang.html", 'status' => "success",'title' => "Thành công", 'msg' => "Xóa $bank_del thành công !"));exit();
    }elseif(isset($_POST['ngan_hang'])){
        $pass_lv2 = md5(md5($_POST['pass_add_atm']));
        $ngan_hang = anti_xss($db->real_escape_string($_POST['ngan_hang']));
        $chu_tk = strip_tags($db->real_escape_string($_POST['chu_tk']));
        $so_tk = anti_xss($db->real_escape_string($_POST['so_tk']));
        $so_the = anti_xss($db->real_escape_string($_POST['so_the']));
        $chi_nhanh = strip_tags($db->real_escape_string($_POST['chi_nhanh']));
        
        if(empty($ngan_hang) || empty($chu_tk) || empty($so_tk) || empty($so_the) || empty($chi_nhanh) || empty($_POST['pass_add_atm'])){
            echo json_encode(array('status' => "error", 'title' => "Lỗi", 'msg' =>"Thông tin (*) không được để trống !"));exit();}
            
        if ($db->fetch_row("SELECT COUNT(*) FROM accounts WHERE username = '{$iduser}' AND password_lv2 = '{$pass_lv2}'") < 1) {
            echo json_encode(array('status' => "error", 'title' => "Lỗi", 'msg' =>"Mật khẩu cấp 2 không chính xác !"));exit();}
            
        if ($db->fetch_row("SELECT COUNT(*) FROM data_atm WHERE username = '{$iduser}' AND ngan_hang = '{$ngan_hang}'") > 0) {
            echo json_encode(array('status' => "error", 'title' => "Lỗi", 'msg' =>"Ngân hàng $ngan_hang đã có trong danh sách !"));exit();}
    
        //cập nhật bank
        $db->query("INSERT INTO `data_atm` (username,ngan_hang,so_tk,chu_tk,so_the,chi_nhanh) VALUES ('$iduser','$ngan_hang','$so_tk','$chu_tk','$so_the','$chi_nhanh')");
        echo json_encode(array('link' => "/danh-sach-ngan-hang.html", 'status' => "success",'title' => "Thành công", 'msg' => "Thêm ngân hàng $ngan_hang thành công !"));exit();
}else{
     echo json_encode(array('status' => "error",'link' => "/", 'title' => "Lỗi", 'msg' => "Lỗi không xác đinh !"));exit();
}
}
