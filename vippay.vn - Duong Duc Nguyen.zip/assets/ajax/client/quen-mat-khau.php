<?php
/*
#########################################################
#               Code Edit By LuaUyTin                   #
#              Email: megashopnick@gmail.com            #
#            Phone: 0984.459.954 - 0965.783.736         #
#            Vui Lòng Tôn Trọng Quyền Tác Giả           #
#########################################################
*/

session_start();
error_reporting(E_ALL^E_NOTICE);
error_reporting(E_ERROR);
require_once(realpath($_SERVER["DOCUMENT_ROOT"]) .'/core/init.php');
//Copyright buy LuaUyTin
$luauytin_dz = "atm.lienquanmobile.pro";
if( $_SERVER["SERVER_NAME"] != "www.$luauytin_dz" &&  $_SERVER["SERVER_NAME"] != $luauytin_dz ){
    echo json_encode(array('status' => "warning",'link' => "#luauytin_0984459954", 'title' => "@luauytin-0984.459.954", 'msg' => "Code chưa được kích hoạt. Để mua bản quyền CODE. Liên hệ: 0984.459.954 (Mr.Điệp)"));exit;}
    
$email_admin = $data_site['email_admin'];
if ($user && isset($_POST['pass_lv1'])) {
    echo json_encode(array('status' => "error",'link' => "/logout.html", 'title' => "Lỗi", 'msg' => "Bạn đã đăng nhập rồi !"));
}else {
    $email = $_POST['email'];
    $username = $_POST['username'];
    $phone = $_POST['phone'];
    if(isset($_POST['pass_lv1'])){$type = "password";$type_pass="đăng nhập";
    }elseif(isset($_POST['pass_lv2'])){$type = "password_lv2";$type_pass = "cấp 2";
    }else{
        echo json_encode(array('status' => "error",'link' =>"/", 'title' => "Thất bại", 'msg' => "Lỗi không xác định !"));exit();}
    
    if (!$email || !$username || !$phone){
        echo json_encode(array('status' => "error",'link' =>"#luauytin_0984459954", 'title' => "Thất bại", 'msg' => "Vui lòng nhập đầy đủ thông tin"));exit();}
    if(!filter_var($email, FILTER_VALIDATE_EMAIL)){
        echo json_encode(array('status' => "error",'link' =>"#luauytin_0984459954", 'title' => "Thất bại", 'msg' => "Email không đúng định dạng"));exit();}
    if(!preg_match("/^\+?(84|0)(1\d{9}|9\d{8}|8\d{8}|3\d{8}|7\d{8}|5\d{8})$/", $phone)){
    echo json_encode(array('code' => "1",'status' => "error",'link' =>"#luauytin_0984459954", 'title' => "Lỗi", 'msg' =>"Số điện thoại không đúng định dạng"));exit();}
    
    if($db->fetch_row("SELECT COUNT(*) FROM accounts WHERE username = '{$username}' AND email = '{$email}' AND phone = '{$phone}'") < 1){
        echo json_encode(array('status' => "error",'link' =>"#luauytin_0984459954", 'title' => "Thất bại", 'msg' => "Thông tin yêu cầu không chính xác"));exit();}

            $newpass = rand(100000,999999);
            $password = md5(md5($newpass));
            $db->query("UPDATE `accounts` SET `{$type}` ='{$password}' WHERE `username` = '{$username}'");// cập nhật mật khẩu vào db
            //send mail
            $subject = "Cấp lại mật khẩu $type_pass";
            $message = "Xin chào, $username\nMật khẩu $type_pass mới của bạn tại $_DOMAIN là: $newpass";
              $from = "From: $email_admin"."\r\n";
              mail($email, $subject, $message, $from);
            //thông báo
            echo json_encode(array('link' => "/", 'status' => "success",'title' => "Thành công", 'msg' => "Mật khẩu $type_pass đã được gửi về Email của bạn. Vui lòng kiểm tra hòm thư (có thể trong mục Spam)."));
        
}

