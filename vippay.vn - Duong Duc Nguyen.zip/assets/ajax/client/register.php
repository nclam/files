<?php
/*
╔═════════════════════════════════════════════╗
║             Design by LuaUyTin              ║
║      Facebook: facebook.com/luauytin        ║
║   Hotline: 0984.459.954 - 0899.91.31.91     ║
╚═════════════════════════════════════════════╝
*/
session_start();
require_once(realpath($_SERVER["DOCUMENT_ROOT"]) .'/core/init.php');
//check post
if(!$_POST){load_url('/');die();}
if ($user) {
    echo json_encode(array('status' => "error", 'link' => "/",'title' => 'Lỗi', 'msg' => "Bạn đã đăng nhập rồi"));
}else {

    if (empty(POST('email')) || empty(POST('phone')) || empty(POST('password')) || empty(POST('password2'))) {
        echo json_encode(array('status' => "error",  'title' => "Lỗi", 'msg' =>"Thông tin đăng ký không được để trống !"));exit;}
    if(!preg_match("/^\+?(84|0)(1\d{9}|9\d{8}|8\d{8}|3\d{8}|7\d{8}|5\d{8})$/", POST('phone'))){
        echo json_encode(array('status' => "error", 'title' => "Lỗi", 'msg' => "Số điện thoại không đúng định dạng !"));exit();}
    if(!filter_var(POST('email'), FILTER_VALIDATE_EMAIL)){
        echo json_encode(array('status' => "error", 'title' => "Lỗi", 'msg' => "Email không đúng định dạng !"));exit();}
    if( md5(POST('password')) != md5(POST('password2')) ){
        echo json_encode(array('status' => "error", 'title' => "Lỗi", 'msg' =>"Xác thực mật khẩu không trùng nhau !"));exit;}
	if(strlen(POST('password')) < 6 || strlen(POST('password')) > 40){
	    echo json_encode(array('status' => "error", 'title' => "Lỗi", 'msg' => "Mật khẩu phải từ 6 - 40 kí tự kí tự !"));exit;}
    if($db->fetch_row("SELECT COUNT(*) FROM `accounts` WHERE `username` = '".POST('phone')."'") > 0) {
		 echo json_encode(array('status' => "error", 'title' => "Lỗi", 'msg' => "Số điện thoại đã tồn tại !"));exit;}
	if($db->fetch_row("SELECT COUNT(*) FROM `accounts` WHERE `email` = '".POST('email')."'") > 0) {
		 echo json_encode(array('status' => "error", 'title' => "Lỗi", 'msg' => "Email đã tồn tại !"));exit;}
		 
    //Đủ điều kiện để đăng kí
	   $password = md5(md5(POST('password'))); 
	   $db->query("INSERT INTO `accounts` (`username`,`name`,`phone`,`email`,`cash`,`password`,`time`) 
	   VALUES ('".POST('phone')."','".POST('phone')."','".POST('phone')."','".POST('email')."','0','".md5(md5(POST('password')))."','".$date_current."')");
	   $_SESSION['user'] = POST('phone');
	   $_SESSION['password'] = $password;
		echo json_encode(array('status' => "success", 'link' => '/','title' => "Thành công", 'msg' => "Đăng ký thành công. Đang đăng nhập!"));
}