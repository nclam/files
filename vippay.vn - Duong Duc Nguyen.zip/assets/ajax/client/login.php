<?php
/*
╔═════════════════════════════════════════════╗
║             Design by LuaUyTin              ║
║      Facebook: facebook.com/luauytin        ║
║   Hotline: 0984.459.954 - 0899.91.31.91     ║
╚═════════════════════════════════════════════╝
*/
session_start();
require_once(realpath($_SERVER["DOCUMENT_ROOT"]) .'/core/init.php');
//check post
if(!$_POST){load_url('/');die();}
if ($user) {
    echo json_encode(array('status' => "error",'link' => "/", 'title' => "Lỗi", 'msg' => "Bạn đã đăng nhập rồi"));
}else{
    if (!$_POST['username'] || !$_POST['password']) {
        echo json_encode(array('status' => "error",'title' => "Lỗi", 'msg' => "Thông tin đăng nhập không được để trống!"));exit();}
        
    $username = addslashes(strtolower(POST('username')));
    $password = addslashes(md5(md5(POST('password'))));
    
    if(!preg_match("/^\+?(84|0)(1\d{9}|9\d{8}|8\d{8}|3\d{8}|7\d{8}|5\d{8})$/", $username)){
        echo json_encode(array('status' => "error", 'title' => "Lỗi", 'msg' => "Số điện thoại không đúng định dạng !"));exit();}
    
    $check_user = $db->fetch_row("SELECT COUNT(*) FROM `accounts` WHERE `username` = '".$username."' AND `password` = '".$password."'"); // kiểm tra tài khoản
    if($check_user != 1){
        echo json_encode(array('status' => "error",'title' => "Lỗi", 'msg' =>"Thông tin đăng nhập không chính xác !"));exit;}
    //Get dữ liệu tài khoản
    $_SESSION['user'] = $username;
    $_SESSION['password'] = $password;
        echo json_encode(array('status' => "success", 'link' => '/' ,'title' => "Thành công", 'msg' => "Thành công. Đang đăng nhập !"));
    exit();
}