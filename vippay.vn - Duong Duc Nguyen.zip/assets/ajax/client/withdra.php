<?php
session_start();
error_reporting(E_ALL^E_NOTICE);
error_reporting(E_ERROR);
require_once(realpath($_SERVER["DOCUMENT_ROOT"]) .'/core/init.php');
$iduser = $data_user['username'];
if (!$user) {
    echo json_encode(array('status' => "error", 'link' => "", 'title' => "Lỗi", 'msg' => "Bạn chưa đăng nhập"));
} else {
    $bank = anti_xss($db->real_escape_string($_POST['bank_withdra']));
    $cash = (int)$_POST['cash_withdra'];
    $cash_nhan = $cash - $data_site['price_atm'];
    $note = anti_xss($db->real_escape_string($_POST['note_withdra']));
    $password = md5(md5($_POST['pass_withdra']));
    
    if(empty($bank) || empty($cash) || empty($_POST['pass_withdra'])){
        echo json_encode(array('status' => "error", 'title' => "Lỗi", 'msg' => "Thông tin (*) không được để trống !"));exit;}
    if($cash < 100000){
        echo json_encode(array('status' => "error", 'title' => "Lỗi", 'msg' => "Số tiền rút ít nhất là 100.000đ"));exit;}
    if($cash > $data_user['cash']){
        echo json_encode(array('status' => "error", 'title' => "Lỗi", 'msg' => "Số dư của bạn không đủ để thực hiện giao dịch"));exit;}
    if($password != $data_user['password_lv2']){
        echo json_encode(array('status' => "error", 'title' => "Lỗi", 'msg' => "Mật khẩu cấp 2 không chính xác"));exit;}
        
    $db->query("UPDATE accounts SET `cash` = `cash` - '{$cash}' WHERE `username` = '{$iduser}'");// trừ tiền 
    $db->query("INSERT INTO `history_atm` (username,cash,cash_nhan,ngan_hang,note,status,time) VALUES ('$iduser','$cash','$cash_nhan','$bank','$note','0','$date_current')");// lịch sử    
    echo json_encode(array('link' => "/lich-su-rut.html", 'status' => "success",'title' => "Thành công",'msg' => "Gửi yêu cầu thành công. Vui lòng đợi Admin xử lý!"));
}