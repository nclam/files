<?php
require_once(realpath($_SERVER["DOCUMENT_ROOT"]) .'/core/init.php');
$iduser = $data_user['username'];
if (!$user) {
    echo json_encode(array('status' => "error",'link' => "/", 'title' => "Lỗi", 'msg' => "Bạn chưa đăng nhập"));
} else {
    $username = anti_xss($db->real_escape_string($_POST['username_transfer']));  
    $cash = (int)$_POST['cash_transfer'];
    $note = anti_xss($db->real_escape_string($_POST['note_transfer']));
    $password = md5(md5($_POST['pass_transfer']));
    
    if(empty($username) || empty($cash) || empty($password)){
        echo json_encode(array('status' => "error", 'title' => "Lỗi", 'msg' => "Thông tin (*) không được để trống !"));exit;}
    if(!preg_match("/^\+?(84|0)(1\d{9}|9\d{8}|8\d{8}|3\d{8}|7\d{8}|5\d{8})$/", $username)){
        echo json_encode(array('status' => "error", 'title' => "Lỗi", 'msg' => "Số điện thoại không đúng định dạng !"));exit();}
    if($db->num_rows("SELECT username FROM accounts WHERE username = '$username'") < 1){
        echo json_encode(array('status' => "error", 'title' => "Lỗi", 'msg' => "Số điện thoại không tồn tại"));exit;}
    if($username == $iduser){
        echo json_encode(array('status' => "error", 'title' => "Lỗi", 'msg' => "Bạn không thể chuyển tiền cho chính mình"));exit;}
    if($cash < 10000){
        echo json_encode(array('status' => "error", 'title' => "Lỗi", 'msg' => "Số tiền chuyển ít nhất là 10.000đ"));exit;}
    if($cash > $data_user['cash']){
        echo json_encode(array('status' => "error", 'title' => "Lỗi", 'msg' => "Số dư của bạn không đủ để thực hiện giao dịch"));exit;}
    if($password != $data_user['password_lv2']){
        echo json_encode(array('status' => "error", 'title' => "Lỗi", 'msg' => "Mật khẩu cấp 2 không chính xác"));exit;}
        
    $db->query("UPDATE accounts SET `cash` = `cash` + '{$cash}' WHERE `username` = '{$username}'");// cộng tiền 
    $db->query("UPDATE accounts SET `cash` = `cash` - '{$cash}' WHERE `username` = '{$iduser}'");// trừ tiền 
    $db->query("INSERT INTO `history_transfer` (user_nhan,user_gui,cash,note,time) VALUES ('$username','$iduser','$cash','$note','$date_current')");// lịch sử    
    echo json_encode(array('code' => 0, 'status' => "success",'title' => "Thành công",'msg' => "Chuyển $cash đ cho $username thành công!"));
}