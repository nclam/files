<?php
/*
#########################################################
#               Code Edit By LuaUyTin                   #
#              Email: megashopnick@gmail.com            #
#            Phone: 0984.459.954 - 0965.783.736         #
#            Vui Lòng Tôn Trọng Quyền Tác Giả           #
#########################################################
*/

// Kết nối database và thông tin chung
require_once(realpath($_SERVER["DOCUMENT_ROOT"]) .'/core/init.php');
if(!$_POST){die();}
if (!$user) {
echo
'<div class="alert alert-warning">Vui lòng đăng nhập để xem thông tin
<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button>
</div>';exit;
}

$iduser = $data_user['username'];
$input = new Input;
$page = (int)$input->input_post("page");

$total_record = $db->fetch_row("SELECT COUNT(id) FROM data_atm WHERE username = '{$iduser}' LIMIT 1");
    // config phân trang
    $config = array(
      "current_page" => $page,
      "total_record" => $total_record,
      "limit" => "20",
      "range" => "5",
      "link_first" => "",
      "link_full" => "?page={page}"
    );
    
    $paging = new Pagination;
    $paging->init($config);
    $sql_get_list_mem = "SELECT * FROM `data_atm` WHERE username = '{$iduser}' ORDER BY `id` ASC  LIMIT {$paging->getConfig()["start"]}, {$paging->getConfig()["limit"]}";

// Nếu có 
if ($total_record){
?>
                        <table  class="table table-bordered">
                             <thead><tr style="background-color:black;">
                                    <th class="text-center" style="color:white;font-weight:bold;">ID</th>
                                    <th class="text-center" style="color:white;font-weight:bold;">Ngân hàng</th>
                                    <th class="text-center" style="color:white;font-weight:bold;">Chủ tài khoản</th>
                                    <th class="text-center" style="color:white;font-weight:bold;">Số tài khoản</th>
                                    <th class="text-center" style="color:white;font-weight:bold;">Số thẻ</th>
                                    <th class="text-center" style="color:white;font-weight:bold;">Chi nhánh</th>
                                    <th class="text-center" style="color:white;font-weight:bold;">Thao tác</th>
                                </tr></thead>
                        <tbody>
<?php                            
$i=1;
foreach ($db->fetch_assoc($sql_get_list_mem, 0) as $key => $data){ 
?>


                             <tr>
                                    <td class="text-center"><?php echo $i; ?></td>
                                    <td class="text-center"><?php echo $data['ngan_hang']; ?></td>
                                    <td class="text-center"><?php echo $data['chu_tk']; ?></td>
                                    <td class="text-center"><?php echo $data['so_tk']; ?></td>
                                    <td class="text-center"><?php echo $data['so_the']; ?></td>
                                    <td class="text-center"><?php echo $data['chi_nhanh']; ?></td>
                                    <td class="text-center">
                                     <button class="btn btn-sm btn-danger" onclick="del_atm('<?php echo $data['id']; ?>','<?php echo $data['ngan_hang']; ?>');">Delete</button>
                                    </td>
                            </tr>



<?php 
$i++;
}
?>
                        </tbody>
                        </table>
                    
<?php                     
echo $paging->html_list(); // page
}else {
?>
<div class="alert alert-info">Không có ngân hàng nào
<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button>
</div>

<?php
}
?>