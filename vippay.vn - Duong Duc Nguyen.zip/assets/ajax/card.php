<?php
/*
#########################################################
#               Code Edit By LuaUyTin                   #
#              Email: megashopnick@gmail.com            #
#            Phone: 0984.459.954 - 0965.783.736         #
#            Vui Lòng Tôn Trọng Quyền Tác Giả           #
#########################################################
*/
require_once(realpath($_SERVER["DOCUMENT_ROOT"]) .'/core/init.php');
if(!$_POST){die();}
if (!$user) {
    echo json_encode(array('status' => "error", 'title' => "Lỗi", 'msg' => "Bạn chưa đăng nhập"));
} else {
    
    if (!$_POST['card_type_id']) {
    echo json_encode(array('status' => "error", 'title' => "Lỗi", 'msg' => "Chưa chọn loại nhà mạng"));
    }elseif (!$_POST['price_guest']) {
    echo json_encode(array('status' => "error", 'title' => "Lỗi", 'msg' => "Chưa chọn mệnh giá thẻ"));
    }elseif (!$_POST['pin']) {
    echo json_encode(array('status' => "error", 'title' => "Lỗi", 'msg' => "Độ dài mã thẻ hoặc số seri không hợp lệ"));
    }elseif (!$_POST['seri']) {
    echo json_encode(array('status' => "error", 'title' => "Lỗi", 'msg' => "Độ dài mã thẻ hoặc số seri không hợp lệ"));
    }else{

$info_card = new Info;
$iduser = $data_user['username'];
$name = addslashes($data_user['name']);
$email_admin = $data_site['email_admin'];

//Truyền dữ liệu thẻ
$pin = anti_xss($db->real_escape_string($_POST['pin'])); // string
$seri = anti_xss($db->real_escape_string($_POST['seri'])); // string
$card_type = (int)$_POST['card_type_id']; // interger
$type = $card_type >= 10 ? 2:1;
$card_type_check = $card_type >= 10 ? $card_type-10:$card_type;

switch ($_POST['price_guest']) {
    case 10000:
        $price_guest = 10000;
        break;
    case 20000:
        $price_guest = 20000;
        break;
    case 30000:
        $price_guest = 30000;
        break;
    case 50000:
        $price_guest = 50000;
        break;
    case 100000:
        $price_guest = 100000;
        break;
    case 200000:
        $price_guest = 200000;
        break;
    case 300000:
        $price_guest = 300000;
        break;
    case 500000:
        $price_guest = 500000;
        break;
    case 1000000:
        $price_guest = 1000000;
        break;
    default:
        echo json_encode(array('status' => "error", 'title' => "Lỗi", 'msg' => 'Vui lòng chọn mệnh giá thẻ !'));exit();
        break;
}

//Check thẻ nạp có hoạt động không
if ($db->fetch_row("SELECT COUNT(*) FROM auto_card WHERE `{$card_type_check}` = 'on' AND `id` = '{$type}'") == 0) {
    echo json_encode(array('status' => "error", 'title' => "Lỗi", 'msg' => "Hiện tại ".$info_card->get_string_card($card_type)." bảo trì"));exit();}
//định dạng
if(!luauytin($card_type,$seri,$pin)){
    echo json_encode(array('status' => "error", 'msg' => "Mã thẻ hoặc seri không đúng định dạng !"));exit();}
//Xử lý chiết khấu card
$cash_nhan = $db->fetch_assoc("SELECT * FROM `ck_card` WHERE `id` = '{$type}'", 1)[$card_type_check]*$price_guest*0.01;
//check thẻ đã nạp
$check = $db->fetch_row("SELECT COUNT(id) FROM history_card WHERE pin = '{$pin}' AND seri = '{$seri}'"); //thẻ sai
if($check > 0){
        echo json_encode(array('code' => '1', 'status' => "error",'title' => "Thất bại",'msg' => "Thẻ đã được nạp trên hệ thống. Vui lòng sử dụng thẻ khác"));exit;}
        
if($type == "1"){
############################################################################################################
//api gachthe.vn
$APIKey = $data_site['merchant_key'];
$Network = array(1 => 'VTT', 2 => 'VMS', 3 => 'VNP')[$card_type];
$TrxID = time().rand(142236,989964);
$URLCallback = 'https://'.$_SERVER["SERVER_NAME"].'/callback.php';
if(!$Network){
    echo json_encode(array('status' => "error", 'title' => 'Lỗi', 'msg' => "Thẻ này không được hỗ trợ trên hệ thống !"));exit;}

$luauytin_card = luauytin_gachthe($APIKey,$Network,$pin,$seri,$price_guest,$URLCallback,$TrxID);

if($luauytin_card->Code == 1){
    $db->query("INSERT INTO `history_card` (`request_id`,`username`,`name`,`type_card`,`count_card`,`cash_nhan`,`time`,`seri`,`pin`,`status`) 
    VALUES ('$TrxID','$iduser','$name','$card_type','$price_guest','$cash_nhan','$date_current','$seri','$pin','0')");// lịch sử
    echo json_encode(array('status' => "success", 'title' => 'Chờ xử lý', 'msg' => 'Gửi thẻ thành công. Vui lòng chờ hệ thống kiểm tra thẻ trong giây lát !'));exit;
}else{
    echo json_encode(array('status' => "error", 'title' => 'Lỗi', 'msg' => $luauytin_card->Message));exit;
}
############################################################################################################
}elseif($type == "2"){
    
    $db->query("INSERT INTO `history_card` (username,name,type_card,count_card,cash_nhan,time,seri,pin,status) VALUES ('$iduser','$name','$card_type','$price_guest','$cash_nhan','$date_current','$seri','$pin','0')");// lịch sử
    
    
    //Thông báo tới mail admin
    $yc = $db->fetch_row("SELECT COUNT(*) FROM history_card WHERE status = '0'");
    $loaithe =  $info_card->get_string_card($card_type);
    $subject = "Yêu cầu xử lý thẻ nạp tại $_DOMAIN";
    $message = "Có $yc đang đợi Admin xử lý \n\n
    Yêu cầu mới nhất: \n
    User: $iduser\n
    Loại thẻ: $loaithe \n
    Mệnh giá: $price_guest \n
    Seri: $seri \n
    Pin: $pin";
    $from = 'From: GachThe@megashopnick.com'."\r\n";
    mail($email_admin, $subject, $message, $from);
    
    echo json_encode(array('status' => "success",'title' => "Thành công",'msg' => "Gửi yêu cầu thành công. Vui lòng đợi Admin duyệt trong ít phút"));
    
    
}else{
     echo json_encode(array('status' => "error", 'title' => "Lỗi", 'msg' => "Lỗi không xác định"));
}
}
}

function luauytin_gachthe($APIKey,$Network,$CardCode,$CardSeri,$CardValue,$URLCallback,$TrxID){
        $fields = array(
            'APIKey'    => $APIKey,
            'Network'   => $Network,
            'CardCode'  => $CardCode,
            'CardSeri'  => $CardSeri,
            'CardValue' => $CardValue,
            'URLCallback' => $URLCallback,
            'TrxID'       => $TrxID
        );
        $ch = curl_init("http://gachthe.vn/API/NapThe");
        curl_setopt($ch, CURLOPT_HTTPGET, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $fields);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_DIGEST);
        curl_setopt($ch, CURLOPT_TIMEOUT, 120);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
        $result = curl_exec($ch);
        $result = json_decode($result);
    return $result;
}
