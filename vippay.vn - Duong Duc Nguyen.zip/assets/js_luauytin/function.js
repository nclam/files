       $(document).ready(function () {

            $("#card-charing").validate({
                rules: {
                    type: {
                        required: true
                    },
                    card_type_id: {
                        required: true
                    },
                    price_guest: {
                        required: true
                    },
                    seri: {
                        required: true,
                        minlength: 6
                    },
                    pin: {
                        required: true,
                        minlength: 6
                    }
                },
                messages: {
                    type: '<font color="red">Vui lòng chọn phương thức nạp</font>',
                    card_type_id: '<font color="red">Vui lòng chọn loại thẻ</font>',
                    price_guest: '<font color="red">Vui lòng chọn mệnh giá thẻ</font>',
                    seri: '<font color="red">Vui lòng nhập serial của thẻ</font>',
                    pin: '<font color="red">Vui lòng nhập mã thẻ</font>'
                },
                submitHandler: function (e) {

                    if (!$('#card-charing').hasClass('isPosting')) {

                        $('#card-charing').addClass('isPosting');
                        $('#card-charing button[type="submit"]').text('ĐANG NẠP THẺ...');

                        $.post('/assets/ajax/card.php', $('#card-charing').serialize(), function (res) {
                        var json = $.parseJSON(res);
                            if (json.status == "success") {
                                swal("Thành công!", json.msg, "success");
                            }
                            else {swal("Thất bại!",json.msg , "error");}
                        }).complete(function () {
                            $('#card-charing').removeClass('isPosting');
                            $('#card-charing button[type="submit"]').text('NẠP THẺ');
                        }).fail(function() {
                            $('#card-charing').removeClass('isPosting');
                            $('#card-charing button[type="submit"]').text('NẠP THẺ');
                        });
                    }
                    return false;
                }
            });
        });

    $(document).ready(function() {
        $.toast({
            heading: 'Chào mừng bạn tới website',
            text: 'Hệ thống gạch thẻ uy tín nhất.',
            position: 'bottom-right',
            loaderBg: '#ff6849',
            icon: 'info',
            hideAfter: 3500,
            stack: 6
        })
    });
    
    $(document).ready(function () {
      $("#lostpass_luauytin").validate({
          submitHandler: function (e) {
          $('button[id="submit_lostpass"]').html("ĐANG XỬ LÝ...");
          $.post("/assets/ajax/client/quen-mat-khau.php", $('#lostpass_luauytin').serialize(), function(data) {
              $('button[id="submit_lostpass"]').html("GỬI YÊU CẦU");
              swal(data.title, data.msg, data.status);
              setTimeout(function () {
                    window.location.href = data.link;
                    }, 2500);	      
          }, "json");
              return false;
          }
      });
      });
      
         $(document).ready(function () {

            $("#ruttien").click(function(){

                $(".atm").modal('show');
            });
            $("#login").click(function(){

                $(".login").modal('show');
            });
            $("#register").click(function(){

                $(".register").modal('show');
            });
            $("#login_1 , #login_2 , #login_3 , #login_4 , #login_5 , #login_6 , #login_7 , #login_8 , #login_9").click(function(){

                $(".login2").modal('show');
            });
            $("#changepassword").click(function(){

                $(".changepassword").modal('show');
            });
            $("#changepassword_lv2").click(function(){

                $(".changepassword_lv2").modal('show');
            });
            $("#transfer").click(function(){

                $(".transfer").modal('show');
            });
            $("#withdra").click(function(){

                $(".withdra").modal('show');
            });
            $("#add_atm").click(function(){

                $(".add_atm").modal('show');
            });
            $("#profile").click(function(){

                $(".profile").modal('show');
            });

            $(".thongbao").modal('show');
        });
		
$(document).ready(function () {
      $("#changepassword_luauytin").validate({
          submitHandler: function (e) {
          $('button[id="changepass"]').html("ĐANG CẬP NHẬT...");
          $.post("/assets/ajax/client/changepassword.php", $('#changepassword_luauytin').serialize(), function(data) {
              $('button[id="changepass"]').html("CẬP NHẬT");
              swal(data.title, data.msg, data.status);
              if (data.link) window.location.href = data.link; 
          }, "json");
              return false;
          }
      });
      });
    $(document).ready(function () {
      $("#password2_luauytin").validate({
          submitHandler: function (e) {
          $('button[id="changepass2"]').html("ĐANG CẬP NHẬT...");
          $.post("/assets/ajax/client/changepassword_lv2.php", $('#password2_luauytin').serialize(), function(data) {
              $('button[id="changepass2"]').html("CẬP NHẬT");
              swal(data.title, data.msg, data.status);
              if (data.link) window.location.href = data.link; 	      
          }, "json");
              return false;
          }
      });
      });
    $(document).ready(function () {
      $("#transfer_luauytin").validate({
          submitHandler: function (e) {
          $('button[id="submit_transfer"]').html("ĐANG XỬ LÝ...");
          $.post("/assets/ajax/client/transfer.php", $('#transfer_luauytin').serialize(), function(data) {
              $('button[id="submit_transfer"]').html("CHUYỂN TIỀN");
              swal(data.title, data.msg, data.status);
              if (data.link) window.location.href = data.link; 	      
          }, "json");
              return false;
          }
      });
      });
      $(document).ready(function () {
      $("#add_atm_luauytin").validate({
          submitHandler: function (e) {
          $('button[id="submit_add_atm"]').html("ĐANG XỬ LÝ...");
          $.post("/assets/ajax/client/add_del_bank.php", $('#add_atm_luauytin').serialize(), function(data) {
              $('button[id="submit_add_atm"]').html("THÊM NGÂN HÀNG");
              swal(data.title, data.msg, data.status);
              if (data.link) window.location.href = data.link;     
          }, "json");
              return false;
          }
      });
      });
      $(document).ready(function () {
      $("#withdra_luauytin").validate({
          submitHandler: function (e) {
          $('button[id="submit_withdra"]').html("ĐANG XỬ LÝ...");
          $.post("/assets/ajax/client/withdra.php", $('#withdra_luauytin').serialize(), function(data) {
              $('button[id="submit_withdra"]').html("GỬI YÊU CẦU");
              swal(data.title, data.msg, data.status);
              if (data.link) window.location.href = data.link; 	      
          }, "json");
              return false;
          }
      });
      });
      $(document).ready(function () {
      $("#lostpass_luauytin").validate({
          submitHandler: function (e) {
          $('button[id="submit_lostpass"]').html("ĐANG XỬ LÝ...");
          $.post("/assets/ajax/client/quen-mat-khau.php", $('#lostpass_luauytin').serialize(), function(data) {
              $('button[id="submit_lostpass"]').html("GỬI YÊU CẦU");
              swal(data.title, data.msg, data.status);
              if (data.link) window.location.href = data.link; 	      
          }, "json");
              return false;
          }
      });
      });
	  
    $(document).ready(function () {
      $("#login_luauytin").validate({
          submitHandler: function (e) {
          $('button[id="login"]').html("ĐANG ĐĂNG NHẬP...");
          $.post("/assets/ajax/client/login.php", $('#login_luauytin').serialize(), function(data) {
              $('button[id="login"]').html("ĐĂNG NHẬP");
              swal(data.title, data.msg, data.status);
              if (data.link) window.location.href = data.link;    
          }, "json");
              return false;
          }
      });
      });
    $(document).ready(function () {
      $("#login_luauytin2").validate({
          submitHandler: function (e) {
          $('button[id="login"]').html("ĐANG ĐĂNG NHẬP...");
          $.post("/assets/ajax/client/login.php", $('#login_luauytin2').serialize(), function(data) {
              $('button[id="login"]').html("ĐĂNG NHẬP");
              swal(data.title, data.msg, data.status);
              if (data.link) window.location.href = data.link;    
          }, "json");
              return false;
          }
      });
      });
      
    $(document).ready(function () {
      $("#register_luauytin").validate({
          submitHandler: function (e) {
          $('button[id="register"]').html("ĐANG ĐĂNG KÝ...");
          $.post("/assets/ajax/client/register.php", $('#register_luauytin').serialize(), function(data) {
              $('button[id="register"]').html("ĐĂNG KÝ");
              swal(data.title, data.msg, data.status);
              if (data.link) window.location.href = data.link; 
          }, "json");
              return false;
          }
      });
      });
  $(document).ready(function () {
      $("#edit_member").validate({
          submitHandler: function (e) {
          $('button[type="submit"]').html("ĐANG LƯU...");
          $.post("/assets/ajax/admin/edit_member.php", $('#edit_member').serialize(), function(data) {
              $('button[type="submit"]').html("LƯU LẠI");
              swal(data.title, data.msg, data.status);
              if (data.link) window.location.href = data.link; 
          }, "json");
              return false;
          }
      });
  });

  $(document).ready(function () {
      $("#settings").validate({
          submitHandler: function (e) {
          $('button[type="submit"]').html("ĐANG LƯU...");
          $.post("/assets/ajax/admin/settings.php", $('#settings').serialize(), function(data) {
              $('button[type="submit"]').html("LƯU LẠI");
              swal(data.title, data.msg, data.status);
              if (data.link) window.location.href = data.link; 
          }, "json");
              return false;
          }
      });
  });

  $(document).ready(function () {
      $("#status_card").validate({
          submitHandler: function (e) {
          $('button[type="submit"]').html("ĐANG LƯU...");
          $.post("/assets/ajax/admin/status_card.php", $('#status_card').serialize(), function(data) {
              $('button[type="submit"]').html("LƯU LẠI");
              swal(data.title, data.msg, data.status);
              if (data.status == 'success') load_list(); 
          }, "json");
              return false;
          }
      });
  });