var x60x99x56 = "LuaUyTin";
            var x67x44 = "Nguyễn Tuấn Điệp";
            var x95x33x54 = "0984.459.954";
            var x12x87x43 = "MegaShopNick@gmail.com";
            var x99x45x34 = "https://www.facebook.com/luauytin";
            if(x67x44 == "Nguyễn Tuấn Điệp" &&x60x99x56 == "LuaUyTin" && x95x33x54 == "0984.459.954" && x12x87x43 == "MegaShopNick@gmail.com" && x99x45x34 == "https://www.facebook.com/luauytin"){
                document.write("<footer class='footer text-center'>2018 © Copyright <a href="+x99x45x34+">@"+x60x99x56+"</a></footer>");
            }else{
                 window.location.href ="https://www.facebook.com/luauytin";
            }