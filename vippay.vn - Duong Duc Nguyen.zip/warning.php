<?php
/*
#########################################################
#               Code Edit By LuaUyTin                   #
#              Email: megashopnick@gmail.com            #
#            Phone: 0984.459.954 - 0965.783.736         #
#            Vui Lòng Tôn Trọng Quyền Tác Giả           #
#########################################################
*/
include 'core/init.php';
if($data_user['block'] == "0"){
    header('Location: /');
}
?>
<html>
    <head>
        <link href="https://fonts.googleapis.com/css?family=Ubuntu" rel="stylesheet">
        <style>
        .html, body, h1,h2,p {
        font-family: "Ubuntu", sans-serif;
        }
        </style>
        <title>Cảnh báo đăng nhập !</title>
    </head>
    <body>
        <br>
        <h2 style="text-align: center;"><span style="color: #ff0000;"><strong>Cảnh báo!</strong></span></h2>
        <p style="text-align: center;"><span style="color: #800080;"><span style="color: #808080;">Tài khoản của bạn đã bị khóa. Lý do: <b><?php echo $data_user['note']?></b>. Vui lòng liên hệ Admin để được xử lý.</span></span></p>
        <p style="text-align: center;"><span style="color: #ff0000;"><a href="<?php echo $data_site['fb_admin'];?>" target="_blank">Facebook Admin</a> - <a href="sms:<?php echo $data_site['phone_admin'];?>" target="_blank"><?php echo $data_site['phone_admin'];?></a></span></p>
        <p style="text-align: center;">
          <strong><span class="h3" style="color: #ff0000;">(<?php echo $data_user['username'];?>), <a href="/logout.html">Đăng xuất</a></span></strong>  
        </p>
    </body>
</html>