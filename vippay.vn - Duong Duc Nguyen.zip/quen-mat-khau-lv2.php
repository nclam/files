<?php
/*
#########################################################
#               Code Edit By LuaUyTin                   #
#              Email: megashopnick@gmail.com            #
#            Phone: 0984.459.954 - 0965.783.736         #
#            Vui Lòng Tôn Trọng Quyền Tác Giả           #
#########################################################
*/
// Require database 
require_once 'core/init.php';
if(!$user){header('Location: /');}
$tieude = "Quên mật khẩu cấp 2";
// Require header
require_once 'includes/header.php';
// Danh sach
require_once 'products/quen-mat-khau-lv2.php'; 
// Require footer
require_once 'includes/footer.php';
 
?>