<?php  
/*
╔═════════════════════════════════════════════╗
║             Design by LuaUyTin              ║
║      Facebook: facebook.com/luauytin        ║
║   Hotline: 0984.459.954 - 0899.91.31.91     ║
╚═════════════════════════════════════════════╝
*/
require_once(realpath($_SERVER["DOCUMENT_ROOT"]) .'/core/init.php');
if(!$_GET){die();}
if(isset($_GET['Code']) && isset($_GET['TrxID']) && isset($_GET['CardValue']) && $_GET['TrxID'] != '') {

$file = fopen("luauytin.txt",'a+') or die("lỗi");
$info= "request_id : ".GET('TrxID')." | Code: ".GET('Code')." | MSG: ".GET('Mess')." | time: ".date('d-m-Y H:i:s')."\n________________________________________________";
fwrite($file,"".$info." \r\n\n");
fclose($file);

###############################################################################################################################################################
$sql = "SELECT * FROM `history_card` WHERE `status` = '0' AND `request_id` = '".GET('TrxID')."' LIMIT 1";
if($db->fetch_row($sql)){
$luauytin = $db->fetch_assoc($sql,1);
        if(GET('Code') == 1){
            //cập nhật data
            $db->query("UPDATE `history_card` SET `status` = '1' WHERE `id` = '".$luauytin['id']."' LIMIT 1");
            $db->query("UPDATE `accounts` SET `cash` = `cash` + '".$luauytin['cash_nhan']."' WHERE `username` = '".$luauytin['username']."'");
        }else{
            $status = GET('Code') == 2 || GET('Code') == 3 ? 3:(GET('Code') == 5 ? 2:4);
            $db->query("UPDATE `history_card` SET `status` = '".$status."', `notice` = '".$_GET['Mess']."', `cash_nhan` = '0' WHERE `id` = '".$luauytin['id']."' LIMIT 1");
        }
}
################################################################################################################################################################
}