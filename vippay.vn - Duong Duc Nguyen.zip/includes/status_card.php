<?php
/*
#########################################################
#               Code Edit By LuaUyTin                   #
#              Email: megashopnick@gmail.com            #
#            Phone: 0984.459.954 - 0965.783.736         #
#            Vui Lòng Tôn Trọng Quyền Tác Giả           #
#########################################################
*/

// Require database
require_once(realpath($_SERVER["DOCUMENT_ROOT"]) .'/core/init.php');
$auto_card_1 = $db->fetch_assoc("SELECT * FROM auto_card WHERE id = '1'", 1);
$auto_card_2 = $db->fetch_assoc("SELECT * FROM auto_card WHERE id = '2'", 1);
$ck_card_1 = $db->fetch_assoc("SELECT * FROM ck_card WHERE id = '1'", 1);
$ck_card_2 = $db->fetch_assoc("SELECT * FROM ck_card WHERE id = '2'", 1);
?>
<div class="col-md-3 col-sm-12">
<div class="white-box">   
  <div class="table-responsive">          
  <table class="table">
    <thead class="text-center">
     <center style="font-weight:bold;">TRẠNG THÁI GẠCH THẺ</center>
    </thead>
    <thead>
      <tr>
        <th class="text-center font-weight-bold">Loại thẻ</th>
        <th class="text-center font-weight-bold">Auto</th>
        <th class="text-center font-weight-bold">Chậm</th>
      </tr>
    </thead>
    <tbody>
    <tr class="text-center">
    <td>Viettel</td>
    <td><?php if($auto_card_1['1'] != 'on'){echo "Bảo trì";}else{echo 100-$ck_card_1['1'];echo "%";}?></td>
    <td><?php if($auto_card_2['1'] != 'on'){echo "Bảo trì";}else{echo 100-$ck_card_2['1'];echo "%";}?></td>
    </tr>

    
        <tr class="text-center">
    <td>Mobifone</td>
    <td><?php if($auto_card_1['2'] != 'on'){echo "Bảo trì";}else{echo 100-$ck_card_1['2'];echo "%";}?></td>
    <td><?php if($auto_card_2['2'] != 'on'){echo "Bảo trì";}else{echo 100-$ck_card_2['2'];echo "%";}?></td>
    </tr>

        <tr class="text-center">
    <td>Vinaphone</td>
    <td><?php if($auto_card_1['3'] != 'on'){echo "Bảo trì";}else{echo 100-$ck_card_1['3'];echo "%";}?></td>
    <td><?php if($auto_card_2['3'] != 'on'){echo "Bảo trì";}else{echo 100-$ck_card_2['3'];echo "%";}?></td>
    </tr>
    </tbody>
  </table>
  </div>
  </div>

</div>