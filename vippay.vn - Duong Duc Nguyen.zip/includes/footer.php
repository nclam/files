<!--
#########################################################
#                  Design By LuaUyTin                   #
#              Email: megashopnick@gmail.com            #
#            Phone: 0984.459.954 - 0965.783.736         #
#            Vui Lòng Tôn Trọng Quyền Tác Giả           #
#########################################################
-->
<footer class='footer text-center'>2018 © Copyright <a href="https://facebook.com/luauytin">@LuaUyTin</a>. Hotline: <b><?=$data_site['phone_admin'];?></b></footer>


<?php if(!$user){?>        
<!--Login-->
<div class="modal login" tabindex="-1">

  <div class="modal-dialog modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-header">
        
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                <b class="modal-title h4">ĐĂNG NHẬP</b>
            
      </div>
      <div class="modal-body">
        <div class="panel-body">
           <form id="login_luauytin" novalidate="novalidate">
            <div class="form-group param_text">
                <label for="username" class="col-sm-12 control-label">Số điện thoại:</label>
                <div class="col-sm-12">
                    <input type="text" class="form-control" id="username" name="username" autocomplete="off" placeholder="Số điện thoại">
                </div>
            </div>
            <div class="form-group">
                <label class="col-sm-12 control-label" for="password">Mật khẩu:</label>
                <div class="col-sm-12">
                    <input type="password" class="form-control" id="password" name="password" autocomplete="off" placeholder="Mật khẩu"> 
                </div>
            </div>
            <div class="form-group">
                <label class="col-sm-12 control-label" for="login"></label>
                <div class="col-sm-12">
                    <button type="submit" class="btn btn-success btn-block" id="login">ĐĂNG NHẬP</button> 
                </div>
            </div>
            <div class="form-group">
                <label class="col-sm-12 control-label"></label>
                <div class="col-sm-12">
                    <a href="/account/quen-mat-khau.html"><center>Quên mật khẩu ?</center></a>
                </div>
            </div>
        </form>
    </div>


      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>
<!--Login 2-->
<div class="modal login2" tabindex="-1">

  <div class="modal-dialog modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-header">
        
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                <b class="modal-title h4">ĐĂNG NHẬP</b>
            
      </div>
      <div class="modal-body">
        <div class="panel-body">
           <form id="login_luauytin2" novalidate="novalidate">
            <div class="form-group param_text">
                <div class="alert alert-warning">Trước tiên bạn cần đăng nhập để thực hiện nội dung
                <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button>
                </div>
                <label for="username" class="col-sm-12 control-label">Tài khoản:</label>
                <div class="col-sm-12">
                    <input type="text" class="form-control" id="username" name="username" autocomplete="off" placeholder="Tài khoản">
                </div>
            </div>
            <div class="form-group">
                <label class="col-sm-12 control-label" for="password">Mật khẩu:</label>
                <div class="col-sm-12">
                    <input type="password" class="form-control" id="password" name="password" autocomplete="off" placeholder="Mật khẩu"> 
                </div>
            </div>
            <div class="form-group">
                <label class="col-sm-12 control-label" for="login"></label>
                <div class="col-sm-12">
                    <button type="submit" class="btn btn-success btn-block" id="login">ĐĂNG NHẬP</button> 
                </div>
            </div>
            <div class="form-group">
                <label class="col-sm-12 control-label"></label>
                <div class="col-sm-12">
                    <a href="/account/quen-mat-khau.html"><center>Quên mật khẩu ?</center></a>
                </div>
            </div>
        </form>
    </div>


      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>

<!--register-->
<div class="modal register" tabindex="-1">

  <div class="modal-dialog modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-header">
        
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                <b class="modal-title h4">ĐĂNG KÝ TÀI KHOẢN</b>
            
      </div>
      <div class="modal-body">
        <div class="panel-body">
           <form id="register_luauytin" novalidate="novalidate">
            <div class="form-group param_text">
                <label for="phone" class="col-sm-12 control-label">Số điện thoại(<b style="color:red;">*</b>):</label>
                <div class="col-sm-12">
                    <input type="text" class="form-control" id="phone" name="phone" autocomplete="off" placeholder="Số điện thoại">
                </div>
            </div>
            <div class="form-group param_text">
                <label for="email" class="col-sm-12 control-label">Email(<b style="color:red;">*</b>):</label>
                <div class="col-sm-12">
                    <input type="email" class="form-control" id="email" name="email" autocomplete="off" placeholder="Email tài khoản">
                </div>
            </div>
            <div class="form-group">
                <label class="col-sm-12 control-label" for="password">Mật khẩu(<b style="color:red;">*</b>):</label>
                <div class="col-sm-12">
                    <input type="password" class="form-control" id="password" name="password" autocomplete="off" placeholder="Mật khẩu"> 
                </div>
            </div>
            <div class="form-group">
                <label class="col-sm-12 control-label" for="password2">Nhập lại mật khẩu(<b style="color:red;">*</b>):</label>
                <div class="col-sm-12">
                    <input type="password" class="form-control" id="password2" name="password2" autocomplete="off" placeholder="Nhập lại mật khẩu"> 
                </div>
            </div>
            <div class="form-group">
                <label class="col-sm-12 control-label" for="register"></label>
                <div class="col-sm-12">
                    <button type="submit" class="btn btn-success btn-block" id="register">ĐĂNG KÝ</button> 
                </div>
            </div>
            
        </form>
    </div>


      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>
<?php }?>

<?php if($user){?>
<!--profile-->
<div class="modal profile" tabindex="-1">

  <div class="modal-dialog modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-header">
       
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                <b class="modal-title h4">THÔNG TIN TÀI KHOẢN</b>
      </div>
      <div class="modal-body">
        <div class="panel-body">
            <div class="form-group param_text">
                <label for="phone" class="col-sm-12 control-label">SĐT đăng nhập:</label>
                <div class="col-sm-12">
                    <input class="form-control" value="<?php echo str_replace( substr($data_user['phone'], -4), '****', $data_user['phone'] );?>" disabled>
                </div>
            </div>
            <div class="form-group param_text">
                <label for="phone" class="col-sm-12 control-label">Email:</label>
                <div class="col-sm-12">
                    <input class="form-control" value="<?php echo str_replace( substr(substr($data_user['email'], 0, strpos($data_user['email'], '@')), -5), '*****', $data_user['email']);?>" disabled>
                </div>
            </div>
            <div class="form-group param_text">
                <label for="phone" class="col-sm-12 control-label">Số dư hiện có:</label>
                <div class="col-sm-12">
                    <input class="form-control" value="<?php echo number_format($data_user['cash'], 0, '.', '.'); ?>đ" disabled>
                </div>
            </div> 
            
            
    </div>


      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>

<!--add_atm-->
<div class="modal add_atm" tabindex="-1">
  <div class="modal-dialog modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                <b class="modal-title h4">THÊM NGÂN HÀNG</b>
      </div>
      <div class="modal-body">
        <div class="panel-body">
           <form id="add_atm_luauytin" novalidate="novalidate">
            <div class="form-group param_text">
                <label for="ngan_hang" class="col-sm-12 control-label">Ngân hàng(<b style="color:red;">*</b>):</label>
                <div class="col-sm-12">
                    <select class="form-control" id="ngan_hang" name="ngan_hang">
            <option value="">- Chọn ngân hàng -</option>
            <option value="VIETCOMBANK">VIETCOMBANK</option>
            <option value="AGRIBANK">AGRIBANK</option>
            <option value="TIENPHONGBANK">TIENPHONGBANK</option>
            <option value="VIBANK">VIBANK</option>
            <option value="TECHCOMBANK">TECHCOMBANK</option>
            <option value="VIETTINBANK">VIETTINBANK</option>
            <option value="MBBANK">MBBANK</option>
            <option value="PGBANK">PGBANK</option>
            <option value="SHBBANK">SHBBANK</option>
            <option value="EXIMBANK">EXIMBANK</option>
            <option value="MARITIMEBANK">MARITIMEBANK</option>
            <option value="SAIGONBANK">SAIGONBANK</option>
            <option value="NAMABANK">NAMABANK</option>
            <option value="VIETABANK">VIETABANK</option>
            <option value="SACOMBANK">SACOMBANK</option>
            <option value="SEABANK">SEABANK</option>
            <option value="OCEANBANK">OCEANBANK</option>
            <option value="BIDV">BIDV</option>
            <option value="BACABANK">BACABANK</option>
            <option value="VPBANK">VPBANK</option>
            <option value="ABBANK">ABBANK</option>
            <option value="GPBANK">GPBANK</option>
                    </select>
                </div>
            </div>
            <div class="form-group">
                <label class="col-sm-12 control-label" for="chu_tk">Chủ tài khoản(<b style="color:red;">*</b>):</label>
                <div class="col-sm-12">
                    <input type="text" class="form-control" id="chu_tk" name="chu_tk" autocomplete="off" placeholder="Chủ tài khoản">
                </div>
            </div>
            <div class="form-group">
                <label class="col-sm-12 control-label" for="so_tk">Số tài khoản(<b style="color:red;">*</b>):</label>
                <div class="col-sm-12">
                    <input type="text" class="form-control" id="so_tk" name="so_tk" autocomplete="off" placeholder="Số tài khoản">
                </div>
            </div>
            <div class="form-group">
                <label class="col-sm-12 control-label" for="so_the">Số thẻ(<b style="color:red;">*</b>):</label>
                <div class="col-sm-12">
                    <input type="text" class="form-control" id="so_the" name="so_the" autocomplete="off" placeholder="Số thẻ">
                </div>
            </div>
            <div class="form-group">
                <label class="col-sm-12 control-label" for="chi_nhanh">Chi nhánh(<b style="color:red;">*</b>):</label>
                <div class="col-sm-12">
                    <input type="text" class="form-control" id="chi_nhanh" name="chi_nhanh" autocomplete="off" placeholder="Quân(huyện)-Tỉnh">
                </div>
            </div>
            <div class="form-group">
                <label class="col-sm-12 control-label" for="pass_add_atm">Mật khẩu cấp 2(<b style="color:red;">*</b>):</label>
                <div class="col-sm-12">
                    <input type="password" class="form-control" id="pass_add_atm" name="pass_add_atm" placeholder="Nhập mật khẩu cấp 2">
                </div>
            </div>
            <div class="form-group">
                
                <label class="col-sm-12 control-label" for="submit_add_atm"></label>
                <div class="col-sm-12">
                    <button type="submit" class="btn btn-success btn-block" id="submit_add_atm">THÊM NGÂN HÀNG</button> 
                </div>
            </div>
        </form>
    </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>

<!--wihdra-->
<div class="modal withdra" tabindex="-1">
  <div class="modal-dialog modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                <b class="modal-title h4">RÚT TIỀN VỀ NGÂN HÀNG</b>
      </div>
      <div class="modal-body">
        <div class="panel-body">
           <form id="withdra_luauytin" novalidate="novalidate">
            <div class="form-group param_text">
                <div class="alert alert-info">Phí rút tiền về ngân hàng là: <b><?php echo number_format($data_site['price_atm'], 0, '.', '.'); ?>đ</b>
                <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button>
                </div>
            <?php if(!$data_user['password_lv2']){
                echo 
                '<div class="alert alert-danger">Hãy thêm mật khâu cấp 2 trước khi thực hiện giao dịch
                <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button>
                </div>';
            }?>
            <?php $sql_data_atm = "SELECT ngan_hang FROM data_atm WHERE username = '".$data_user['username']."' ORDER BY id ASC";
            if(!$db->num_rows($sql_data_atm)){
                echo 
                '<div class="alert alert-warning">Bạn chưa cập nhật danh sách ngân hàng.
                <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button>
                </div>';
            }?>
                <label for="bank_withdra" class="col-sm-12 control-label">Ngân hàng(<b style="color:red;">*</b>):</label>
                <div class="col-sm-12">
                    <select class="form-control" id="bank_withdra" name="bank_withdra">
                                    <option value="">Chọn ngân hàng</option>
                                    <?php
                                    $sql_data_atm = "SELECT ngan_hang FROM data_atm WHERE username = '".$data_user['username']."' ORDER BY id ASC";
                                    if($db->num_rows($sql_data_atm)){
                                    foreach ($db->fetch_assoc($sql_data_atm,0) as $item => $data) { ?>                                   
                                        <option value="<?php echo $data['ngan_hang']; ?>"><?php echo $data['ngan_hang']; ?></option>
                                    <?php }} ?>
                    </select>
                </div>
            </div>
            <div class="form-group">
                <label class="col-sm-12 control-label" for="cash_withdra">Số tiền(<b style="color:red;">*</b>):</label>
                <div class="col-sm-12">
                    <input type="number" class="form-control" id="cash_withdra" name="cash_withdra" autocomplete="off" placeholder="Tối thiểu 100.000đ"> 
                </div>
            </div>
            <div class="form-group">
                <label class="col-sm-12 control-label" for="note_withdra">Nội dung (nếu có):</label>
                <div class="col-sm-12">
                    <input type="text" class="form-control" id="note_withdra" name="note_withdra" autocomplete="off" placeholder="Nội dung (nếu có)">
                </div>
            </div>
            <div class="form-group">
                <label class="col-sm-12 control-label" for="pass_withdra">Mật khẩu cấp 2(<b style="color:red;">*</b>):</label>
                <div class="col-sm-12">
                    <input type="password" class="form-control" id="pass_withdra" name="pass_withdra" placeholder="Nhập mật khẩu cấp 2">
                </div>
            </div>
            <div class="form-group">
                
                <label class="col-sm-12 control-label" for="submit_withdra"></label>
                <div class="col-sm-12">
                    <button type="submit" class="btn btn-success btn-block" id="submit_withdra">GỬI YÊU CẦU</button> 
                </div>
            </div>
        </form>
    </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>

<!--transfer-->
<div class="modal transfer" tabindex="-1">
  <div class="modal-dialog modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                <b class="modal-title h4">CHUYỂN TIỀN HỆ THỐNG</b>
      </div>
      <div class="modal-body">
        <div class="panel-body">
           <form id="transfer_luauytin" novalidate="novalidate">
            <?php if(!$data_user['password_lv2']){
                echo 
                '<div class="alert alert-danger">Hãy thêm mật khâu cấp 2 trước khi thực hiện giao dịch
                <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button>
                </div>';
            }?>
            <div class="form-group param_text">
                <label for="username_transfer" class="col-sm-12 control-label">Số điện thoại(<b style="color:red;">*</b>):</label>
                <div class="col-sm-12">
                    <input type="text" class="form-control" id="username_transfer" name="username_transfer" autocomplete="off" placeholder="Tài khoản nhận tiền">
                </div>
            </div>
            <div class="form-group">
                <label class="col-sm-12 control-label" for="cash_transfer">Số tiền(<b style="color:red;">*</b>):</label>
                <div class="col-sm-12">
                    <input type="number" class="form-control" id="cash_transfer" name="cash_transfer" autocomplete="off" placeholder="Tối thiểu 10.000đ"> 
                </div>
            </div>
            <div class="form-group">
                <label class="col-sm-12 control-label" for="note_transfer">Nội dung chuyển tiền:</label>
                <div class="col-sm-12">
                    <input type="text" class="form-control" id="note_transfer" name="note_transfer" autocomplete="off" placeholder="Nội dung chuyển tiền">
                </div>
            </div>
            <div class="form-group">
                <label class="col-sm-12 control-label" for="pass_transfer">Mật khẩu cấp 2(<b style="color:red;">*</b>):</label>
                <div class="col-sm-12">
                    <input type="password" class="form-control" id="pass_transfer" name="pass_transfer" placeholder="Nhập mật khẩu cấp 2">
                </div>
            </div>
            <div class="form-group">
                
                <label class="col-sm-12 control-label" for="submit_transfer"></label>
                <div class="col-sm-12">
                    <button type="submit" class="btn btn-success btn-block" id="submit_transfer">CHUYỂN TIỀN</button> 
                </div>
            </div>
        </form>
    </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>

<!--changepass-->
<div class="modal changepassword" tabindex="-1">

  <div class="modal-dialog modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                <b class="modal-title h4">THAY ĐỔI MẬT KHẨU</b>
      </div>
      <div class="modal-body">
        <div class="panel-body">
           <form id="changepassword_luauytin" novalidate="novalidate">
            <div class="form-group param_text">
                <label for="password" class="col-sm-12 control-label">Mật khẩu cũ:</label>
                <div class="col-sm-12">
                    <input type="password" class="form-control" id="password" name="password" autocomplete="off" placeholder="Mật khẩu cũ">
                </div>
            </div>
            <div class="form-group">
                <label class="col-sm-12 control-label" for="newpass">Mật khẩu mới:</label>
                <div class="col-sm-12">
                    <input type="password" class="form-control" id="newpass" name="newpass" autocomplete="off" placeholder="Mật khẩu mới"> 
                </div>
            </div>
            <div class="form-group">
                <label class="col-sm-12 control-label" for="newpass2">Nhập lại mật khẩu mới:</label>
                <div class="col-sm-12">
                    <input type="password" class="form-control" id="newpass2" name="newpass2" autocomplete="off" placeholder="Nhập lại mật khẩu mới">
                </div>
            </div>
            <div class="form-group">
                
                <label class="col-sm-12 control-label" for="changepass"></label>
                <div class="col-sm-12">
                    <button type="submit" class="btn btn-success btn-block" id="changepass">CẬP NHẬT</button> 
                </div>
            </div>
        </form>
    </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>

<!--changepass lv2-->
<div class="modal changepassword_lv2" tabindex="-1">

  <div class="modal-dialog modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                <b class="modal-title h4">MẬT KHẨU CẤP 2</b>
      </div>
      <div class="modal-body">
        <div class="panel-body">
           <form id="password2_luauytin" novalidate="novalidate">
            <?php if($data_user['password_lv2'] != ""){?>
            <div class="form-group param_text">
                <label for="password_lv2" class="col-sm-12 control-label">Mật khẩu cấp 2 cũ:</label>
                <div class="col-sm-12">
                    <input type="password" class="form-control" id="password_lv2" name="password_lv2" autocomplete="off" placeholder="Mật khẩu cấp 2 cũ">
                </div>
            </div>
            <?php }else{?>
                <div class="alert alert-warning">Bạn chưa tạo mật khẩu cấp 2. Vui lòng cập nhật để thực hiện một số giao dịch của hệ thống.
                <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button>
                </div>
            <?php }?>
            <div class="form-group">
                <label class="col-sm-12 control-label" for="newpass_lv2">Mật khẩu cấp 2 mới:</label>
                <div class="col-sm-12">
                    <input type="password" class="form-control" id="newpass_lv2" name="newpass_lv2" autocomplete="off" placeholder="Mật khẩu cấp 2 mới"> 
                </div>
            </div>
            <div class="form-group">
                <label class="col-sm-12 control-label" for="newpass2_lv2">Nhập lại mật khẩu cấp 2 mới:</label>
                <div class="col-sm-12">
                    <input type="password" class="form-control" id="newpass2_lv2" name="newpass2_lv2" autocomplete="off" placeholder="Nhập lại mật khẩu cấp 2 mới"> 
                </div>
            </div>
            <div class="form-group">
                <label class="col-sm-12 control-label" for="changepass2"></label>
                <div class="col-sm-12">
                    <button type="submit" class="btn btn-success btn-block" id="changepass2">CẬP NHẬT</button> 
                </div>
            </div>
            <div class="form-group">
                <label class="col-sm-12 control-label"></label>
                <div class="col-sm-12">
                    <a href="/account/quen-mat-khau-lv2.html"><center>Quên mật khẩu cấp 2 ?</center></a>
                </div>
            </div>
        </form>
    </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>
<?php }?>

<script src="/assets/js_luauytin/function.js"></script>
</body>

</html>