<?php
/*
#########################################################
#               Code Edit By LuaUyTin                   #
#              Email: megashopnick@gmail.com            #
#            Phone: 0984.459.954 - 0965.783.736         #
#            Vui Lòng Tôn Trọng Quyền Tác Giả           #
#########################################################
*/
 
// Require database & th00ng tin chung
require_once 'core/init.php';
$tieude = '';
require_once 'includes/header.php';
require_once 'includes/home.php';
// Require footer
require_once 'includes/footer.php';
 
?>