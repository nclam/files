<?php
/*
#########################################################
#               Code Edit By LuaUyTin                   #
#              Email: megashopnick@gmail.com            #
#            Phone: 0984.459.954 - 0965.783.736         #
#            Vui Lòng Tôn Trọng Quyền Tác Giả           #
#########################################################
*/

// Require database
require_once '../core/init.php';

// Require header
require_once 'header.php';

// Nếu đăng nhập
if ($user) {
      // Nếu tài khoản không phải là admin
      if ($data_user['admin'] == 0) {
            new Redirect($_DOMAIN); // Trở về trang index
            exit;
      }
      $xss = new Anti_xss;

      $act = $xss->clean_up($_GET['act']);
      switch ($act) {
      case 'status_card':
            require_once 'luauytin/status_card.php'; 
            break;
      case 'member':
            require_once 'luauytin/member.php'; 
            break;
      case 'history_card':
            require_once 'luauytin/history_card.php'; 
            break;
      case 'history_atm':
            require_once 'luauytin/history_atm.php'; 
            break;
      case 'history_transfer':
            require_once 'luauytin/history_transfer.php'; 
            break;
      case 'rut_tien':
            require_once 'luauytin/rut_tien.php'; 
            break;
      case 'card_cham':
            require_once 'luauytin/card_cham.php'; 
            break;
      case 'api':
            require_once 'luauytin/api.php'; 
            break;
      case 'edit_member':
            require_once 'luauytin/edit_member.php'; 
            break;
      case 'settings':
            require_once 'luauytin/settings.php'; 
            break;
      default:
            require_once 'luauytin/main.php'; 
            break;
      }
} else {
      new Redirect($_DOMAIN); // Trở về trang index
}

// Require footer
require_once 'footer.php';

?>