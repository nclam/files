<?php
/*
#########################################################
#               Code Edit By LuaUyTin                   #
#              Email: megashopnick@gmail.com            #
#            Phone: 0984.459.954 - 0965.783.736         #
#            Vui Lòng Tôn Trọng Quyền Tác Giả           #
#########################################################
*/
$gach_the = $db->fetch_row("SELECT COUNT(*) FROM history_card WHERE status = '0'");
$rut_tien = $db->fetch_row("SELECT COUNT(*) FROM history_atm WHERE status = '0'");
$total_yc = $gach_the + $rut_tien;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Admin Panel</title>
    <meta name="keywords" content="<?php echo $data_site["keywords"]; ?>" />
    <meta name="description" content="<?php echo $data_site["keywords"]; ?>" />
    <meta property="og:site_name" content="<?php echo $_DOMAIN; ?>">
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="icon" type="image/png" sizes="16x16" href="/assets/theme/plugins/images/favicon.png">
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta property="og:type" content="website">
    <meta property="og:title" content="<?php echo $data_site['title']; ?>">
    <meta property="og:image" content="/warper.jpg">
    <!--css-->
    <link href="/assets/theme/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="/assets/theme/plugins/bower_components/bootstrap-extension/css/bootstrap-extension.css" rel="stylesheet">
    <link href="/assets/theme/plugins/bower_components/datatables/jquery.dataTables.min.css" rel="stylesheet">
    <link href="/assets/theme/plugins/bower_components/sidebar-nav/dist/sidebar-nav.min.css" rel="stylesheet">
    <link href="/assets/theme/plugins/bower_components/toast-master/css/jquery.toast.css" rel="stylesheet">
    <link href="/assets/theme/plugins/bower_components/morrisjs/morris.css" rel="stylesheet">
    <link href="/assets/theme/css/animate.css" rel="stylesheet">
    <link href="/assets/theme/css/style.css" rel="stylesheet">
    <link href="https://cdn.datatables.net/buttons/1.5.1/css/buttons.dataTables.min.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="/assets/theme/sweetalert.css">
    <link href="/assets/theme/css/colors/megna.css" id="theme" rel="stylesheet">
    <link rel="stylesheet" id="css-main" href="/assets/theme/css/page_list.css">
    <!-js-->
    <script src="/assets/theme/sweetalert.min.js"></script>
    <script src="/assets/theme/js/jquery.form.js"></script>
    <script src="/assets/theme/js/jquery.min.js"></script>
    <script src="/assets/theme/js/jquery.validate.js"></script>
    <script src="/assets/theme/plugins/bower_components/styleswitcher/jQuery.style.switcher.js"></script>
    <script src="/assets/theme/plugins/bower_components/datatables/jquery.dataTables.min.js" type="text/javascript"></script>
    <script src="/assets/theme/bootstrap/dist/js/tether.min.js"></script>
    <script src="/assets/theme/bootstrap/dist/js/bootstrap.min.js"></script>
    <script src="/assets/theme/plugins/bower_components/bootstrap-extension/js/bootstrap-extension.min.js"></script>
    <script src="/assets/theme/plugins/bower_components/sidebar-nav/dist/sidebar-nav.min.js"></script>
    <script src="/assets/theme/js/jquery.slimscroll.js"></script>
    <script src="/assets/theme/js/waves.js"></script>
    <script src="/assets/theme/plugins/bower_components/waypoints/lib/jquery.waypoints.js"></script>
    <script src="/assets/theme/plugins/bower_components/counterup/jquery.counterup.min.js"></script>
    <script src="/assets/theme/plugins/bower_components/raphael/raphael-min.js"></script>
    <script src="/assets/theme/plugins/bower_components/morrisjs/morris.js"></script>
    <script src="/assets/theme/js/custom.min.js"></script>
    <script src="/assets/theme/js/dashboard1.js"></script>
    <script src="/assets/theme/plugins/bower_components/jquery-sparkline/jquery.sparkline.min.js"></script>
    <script src="/assets/theme/plugins/bower_components/jquery-sparkline/jquery.charts-sparkline.js"></script>
    <script src="/assets/theme/plugins/bower_components/toast-master/js/jquery.toast.js"></script>
</head>

<body onload="fitler()">

    <div class="preloader">
        <div class="cssload-speeding-wheel"></div>
    </div>
    <div id="wrapper">
        <!-- Navigation -->
        <nav class="navbar navbar-default navbar-static-top m-b-0">
            <div class="navbar-header"><a class="navbar-toggle hidden-sm hidden-md hidden-lg" href="javascript:void(0)" data-toggle="collapse" data-target=".navbar-collapse"><strong style="color:white;">MENU</strong></a>
                <div class="top-left-part"><span class="hidden-xs"><a class="logo" href="/"><img src="/assets/images/logo.png" height="60px" alt="home" /></a></span></div>
                <ul class="nav navbar-top-links navbar-left hidden-xs">
                    <li><a href="javascript:void(0)" class="open-close hidden-xs waves-effect waves-light"><i class="icon-arrow-left-circle ti-menu"></i></a></li>

                </ul>
                
                <?php if(!empty($user)){?>
               <ul class="nav navbar-top-links navbar-right pull-right">
                    <li class="dropdown">
                        <a class="dropdown-toggle profile-pic" data-toggle="dropdown" href="#"><img src="/assets/images/male-user-shadow_318-34042.jpg" alt="user-img" width="36" class="img-circle"> <b class="hidden-xs"><?php echo $data_user['name'];?></b> </a>
                        <ul class="dropdown-menu dropdown-user animated flipInY">
                            <li><a href="#"> <b><?php echo number_format($data_user['cash'], 0, '.', '.'); ?> <sup class="text-muted">vnđ</sup></b></a></li>
                            <li role="separator" class="divider"></li>
                            <li><a href="/profile.html"> Thông tin</a></li>
                            <li role="separator" class="divider"></li>
                            <li><a href="/logout.html" style="color:red;"> Đăng xuất</a></li>
                        </ul>
                    </li>
                </ul>
                <?php }else{ ?>
                <ul class="nav navbar-top-links navbar-right pull-right">
                    <li class="dropdown"><a id="login" style="color:white;">Đăng nhập</a></li>
                    <li class="dropdown"><a id="register" style="color:white;">Đăng kí</a></li>
                </ul>
                <?php } ?>
            </div>
            <!-- /.navbar-header -->
            <!-- /.navbar-top-links -->
            <!-- /.navbar-static-side -->
        </nav>
        <!-- Left navbar-header -->
        <div class="navbar-default sidebar" role="navigation">
            <div class="sidebar-nav navbar-collapse slimscrollsidebar">
                <ul class="nav" id="side-menu">

                    <li> <a href="/index.html?luauytin_dep_trai_nhat" class="waves-effect"><i class="linea-icon linea-basic fa-fw" data-icon="v"></i> <span class="hide-menu"> Trang chủ </span></a>
                    </li>
                    <li> <a href="/admin?luauytin_dep_trai_nhat" class="waves-effect"><i class="linea-icon linea-basic fa-fw" data-icon="v"></i> <span class="hide-menu"> Thống kê </span></a>
                    </li>
                    <li> <a href="settings" class="waves-effect"><i data-icon="O" class="linea-icon linea-software fa-fw"></i> <span class="hide-menu">Settings</span></a>
                        <ul class="nav nav-second-level">
                            <li><a href="/admin/settings/general">Cài đặt chung</a></li>
                            <li><a href="/admin/settings/status_card">Trạng thái thẻ</a></li>
                            <li><a href="/admin/settings/api">Thông tin tích hợp</a></li>
                        </ul>
                    </li>
                    <li> <a href="settings" class="waves-effect"><i data-icon="O" class="linea-icon linea-software fa-fw"></i> <span class="hide-menu">Lịch sử</span></a>
                        <ul class="nav nav-second-level">
                            <li><a href="/admin/history/card">Lịch sử nạp thẻ</a></li>
                            <li><a href="/admin/history/atm">Lịch sử rút tiền</a></li>
                            <li><a href="/admin/history/transfer">Lịch sử chuyển tiền</a></li>
                        </ul>
                    </li>
                    <li> <a href="/admin/member" class="waves-effect"><i class="linea-icon linea-basic fa-fw" data-icon="v"></i> <span class="hide-menu"> Thành viên </span></a>
                    </li>
                    
                    <li><a href="require" class="waves-effect"><i data-icon="O" class="linea-icon linea-software fa-fw"></i> <span class="hide-menu">Yêu cầu <?php if($total_yc > 0){echo "($total_yc)";}?></span></a>
                        <ul class="nav nav-second-level">
                            <li><a href="/admin/require/card-cham">Gạch thẻ chậm <?php if($gach_the > 0){echo "($gach_the)";}?></a></li>
                            <li><a href="/admin/require/rut-tien">Rút tiền <?php if($rut_tien > 0){echo "($rut_tien)";}?></a></li>
                        </ul>
                    </li>
                </ul>
            </div>
        </div>