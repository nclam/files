<footer class="footer text-center"> 2018 &copy; Copyright @LuaUyTin </footer>
<script src="/assets/js_luauytin/function.js"></script>
</body>
</html>