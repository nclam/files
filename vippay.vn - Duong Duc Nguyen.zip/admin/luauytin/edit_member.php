<?php
/*
#########################################################
#               Code Edit By LuaUyTin                   #
#              Email: megashopnick@gmail.com            #
#            Phone: 0984.459.954 - 0965.783.736         #
#            Vui Lòng Tôn Trọng Quyền Tác Giả           #
#########################################################
*/

$username = $_GET['username'];
$sql_get = "SELECT * FROM accounts WHERE username = '$username'";
if ($db->num_rows($sql_get)) {
$data = $db->fetch_assoc($sql_get, 1); 
}else{
new Redirect("/admin/member"); 
}
?>


<div id="page-wrapper" style="min-height: 797px;">
            <div class="container-fluid">
                <div class="row bg-title">
                    <div class="col-lg-3 col-md-3 col-xs-12">
                            <h4 class="page-title">CHỈNH SỬA USER: <font color="red"><?php echo $data['username']; ?></font></h4>
                    </div>
                </div>

<div class="row">
<div class="col-md-12 col-xs-12">
<div class="white-box">   
<form id="edit_member" novalidate="novalidate">

    <input class="form-control" type="hidden" name="username" value="<?php echo $data['username']; ?>">
    <div class="row">
    <div class="form-group col-md-4">
    <label class="control-label" for="idu">ID User</label>
        <input class="form-control" type="text" id="idu" value="<?php echo $data['id']; ?>" disabled>
    </div>
    <div class="form-group col-md-4">
    <label class="control-label" for="userna">Username</label>
        <input class="form-control" type="text" id="userna" value="<?php echo $data['username']; ?>" disabled>
    </div>
    <div class="form-group col-md-4">
    <label class="control-label" for="name">Name</label>
        <input class="form-control" type="text" id="name" name="name" placeholder="%" value="<?php echo $data['name']; ?>">
    </div>
    </div>
    <div class="row">
    <div class="form-group col-md-4">
    <label class="control-label" for="phone">Phone</label>
        <input class="form-control" type="text" id="phone" name="phone" value="<?php echo $data['phone']; ?>">
    </div>
    <div class="form-group col-md-4">
    <label class="control-label" for="email">Email</label>
        <input class="form-control" type="email" id="email" name="email" value="<?php echo $data['email']; ?>">
    </div>
    <div class="form-group col-md-4">
    <label class="control-label" for="cash">Cash</label>
        <input class="form-control" type="number" id="cash" name="cash" placeholder="<?php echo $data['cash']; ?>" value="<?php echo $data['cash']; ?>">
    </div>
    </div>
    <div class="row">
    <div class="form-group col-md-4">
    <label class="control-label" for="admin">Quyền</label>
        <select class="form-control" id="admin" name="admin">
        <option value="0" <?php echo ($data['admin']=='0') ? 'selected':''; ?>>Member</option>
        <option value="<?php echo ($data['admin'] > '0') ? ''.$data['admin'].'':'1'; ?>" <?php echo ($data['admin'] > '0') ? 'selected':''; ?>>Admin</option>
    </select>
    </div>
    <div class="form-group col-md-4">
    <label class="control-label" for="block">Trạng thái</label>
        <select class="form-control border-input" id="block" name="block">
        <option value="0" <?php echo ($data['block']=='0') ? 'selected':''; ?>>Hoạt động</option>
        <option value="1" <?php echo ($data['block'] > '0') ? 'selected':''; ?>>Bị khóa</option>
    </select>
    </div>
    <div class="form-group col-md-4">
    <label class="control-label" for="note">Lỗi vi phạm</label>
        <input class="form-control" type="text" id="note" name="note" placeholder="Lỗi vi phạm(nếu có)" value="<?php echo $data['note']; ?>">
    </div>
    </div>
    <hr/>
    <div class="form-group">
    <label class="control-label sr-only"></label>
    <button type="submit" class="btn btn-success" id="status_save">LƯU LẠI</button>
    </div>

</div>
</div>
</div></div>

