<script>
page = 1;
username="";
name = "";
phone = "";
email = "";
</script>
<div id="page-wrapper">
            <div class="container-fluid">
                <div class="row bg-title">
                    <div class="col-lg-3 col-md-4 col-sm-4 col-xs-12">
                        <h4 class="page-title">QUẢN LÍ THÀNH VIÊN</h4>
                    </div>

                </div>

<div class="row">
<div class="col-md-12">
    <div class="white-box">
<?php if($user){?>  
<div class="row" onchange="fitler();">
  <div class="col-lg-3">
    <div class="input-group">
      <input class="form-control" placeholder="Name" id="name" name="name" value="">
    </div>
  </div>
  <div class="col-lg-3">
    <div class="input-group">
      <input class="form-control" placeholder="Username" id="username" name="username" value="">
    </div>
  </div>
  <div class="col-lg-3">
    <div class="input-group">
      <input class="form-control" placeholder="Phone" id="phone" name="phone" value="">
    </div>
  </div>
  <div class="col-lg-3">
    <div class="input-group">
      <input type="email" class="form-control" placeholder="Email" id="email" name="email" value="">
      <span class="input-group-btn">
        <button class="btn btn-default" type="button" onclick="fitler();">Tìm</button>
      </span>
    </div>
  </div>
</div>
<br/>    
<?php }?>   <div class="table-responsive">
                <div style="display: block;" class="list"></div>
            </div>    
    </div>
</div>
</div>
</div></div>
<script>
           function load_list(){
                $(".list").hide();
                $("#loading").show();
                $.post("/assets/ajax/admin/member.php", { page : page , username : username , name : name , phone : phone , email : email})
                .done(function(data) {
                    $(".list").html('');
                    $('.list').empty().append(data);
                    $("#loading").hide();
                    $(".list").show();   
                }); 
            }

            function fitler(){
                username = $("#username").val();
                name = $("#name").val();
                phone = $("#phone").val();
                email = $("#email").val();
                load_list();                                              
            }

load_list();
</script>