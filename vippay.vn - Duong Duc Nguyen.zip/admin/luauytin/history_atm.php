<script>
page = 1;
username = "";
</script>
<div id="page-wrapper">
            <div class="container-fluid">
                <div class="row bg-title">
                    <div class="col-lg-3 col-md-4 col-sm-4 col-xs-12">
                        <h4 class="page-title">LỊCH SỬ RÚT TIỀN</h4>
                    </div>

                </div>

<div class="row">
<div class="col-md-12">
    <div class="white-box">
<div class="row">    
  <div class="col-lg-4">
    <div class="input-group">
      <input class="form-control" placeholder="Username" id="username" name="username" value="">
      <span class="input-group-btn">
        <button class="btn btn-default" type="button" onclick="fitler();">Tìm</button>
      </span>
    </div>
  </div>
</div>
<br/>    
            <div class="table-responsive">
                <div style="display: block;" class="list"></div>
            </div>    
    </div>
</div>
</div>
</div></div>
<script>
           function load_list(){
                $(".list").hide();
                $("#loading").show();
                $.post("/assets/ajax/admin/history_withdra.php", { page : page , username : username })
                .done(function(data) {
                    $(".list").html('');
                    $('.list').empty().append(data);
                    $("#loading").hide();
                    $(".list").show();   
                }); 
            }

            function fitler(){
                username = $("#username").val();
                load_list();                                                 
            }
load_list();
</script>