<script>
page = 1;
user_nhan = "";
user_gui = "";
</script>
<div id="page-wrapper">
            <div class="container-fluid">
                <div class="row bg-title">
                    <div class="col-lg-3 col-md-4 col-sm-4 col-xs-12">
                        <h4 class="page-title">LỊCH SỬ CHUYỂN TIỀN</h4>
                    </div>

                </div>

<div class="row">
<div class="col-md-12">
    <div class="white-box">   
<div class="row">    
  <div class="col-lg-4">
    <div class="input-group">
      <input class="form-control" placeholder="Người nhận" id="user_nhan" name="user_nhan" value="">
    </div>
  </div>
  <div class="col-lg-4">
    <div class="input-group">
      <input class="form-control" placeholder="Người gửi" id="user_gui" name="user_gui" value="">
      <span class="input-group-btn">
        <button class="btn btn-default" type="button" onclick="fitler();">Tìm</button>
      </span>
    </div>
  </div>
</div>
<br/>    
            <div class="table-responsive">
                <div style="display: block;" class="list"></div>
            </div>    
    </div>
</div>
</div>
</div></div>
<script>
           function load_list(){
                $(".list").hide();
                $("#loading").show();
                $.post("/assets/ajax/admin/history_transfer.php", { page : page , user_nhan : user_nhan , user_gui : user_gui })
                .done(function(data) {
                    $(".list").html('');
                    $('.list').empty().append(data);
                    $("#loading").hide();
                    $(".list").show();   
                }); 
            }

            function fitler(){
                user_nhan = $("#user_nhan").val();
                user_gui = $("#user_gui").val();
                load_list();                                                 
            }
load_list();
</script>