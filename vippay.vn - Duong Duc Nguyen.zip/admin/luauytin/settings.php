<?php
/*
#########################################################
#               Code By LuaUyTin                        #
#              Email: megashopnick@gmail.com            #
#            Phone: 0984.459.954 - 0965.783.736         #
#            Vui Lòng Tôn Trọng Quyền Tác Giả           #
#########################################################
*/
$data_web = $db->fetch_assoc("SELECT * FROM settings", 1);
?>



<div id="page-wrapper" style="min-height: 797px;">
            <div class="container-fluid">
                <div class="row bg-title">
                    <div class="col-lg-3 col-md-4 col-sm-4 col-xs-12">
                            <h4 class="page-title">CÀI ĐẶT CHUNG    </h4>
                    </div>
                </div>

<div class="row">
<div class="col-md-12 col-xs-12">
<div class="white-box">   
<form action="" id="settings">
<div class="form-group">
<label class="col-xs-12" for="title">Tiêu đề trang web</label>
<div class="col-xs-12">
<input class="form-control" type="text" id="title" name="title" placeholder="Tiêu đề trang web" value="<?php echo $data_web['title']; ?>">
</div>
</div>
<div class="form-group">
<label class="col-xs-12" for="keywords">Từ khóa tìm kiếm</label>
<div class="col-xs-12">
<input class="form-control" type="text" id="keywords" name="keywords" placeholder="Từ khóa tìm kiếm" value="<?php echo $data_web['keywords']; ?>">
</div>
</div>
<div class="form-group">
<label class="col-xs-12" for="name_admin">Tên Admin</label>
<div class="col-xs-12">
<input class="form-control" type="text" id="name_admin" name="name_admin" placeholder="Nguyễn Tuấn Điệp" value="<?php echo $data_web['name_admin']; ?>">
</div>
</div>
<div class="form-group">
<label class="col-xs-12" for="fb_admin">Facebook Admin</label>
<div class="col-xs-12">
<input class="form-control" type="text" id="fb_admin" name="fb_admin" placeholder="https://www.facebook.com/luauytin" value="<?php echo $data_web['fb_admin']; ?>">
</div>
</div>
<div class="form-group">
<label class="col-xs-12" for="fanpage">Fanpage Facebook</label>
<div class="col-xs-12">
<input class="form-control" type="text" id="fanpage" name="fanpage" placeholder="https://www.facebook.com/luauytin" value="<?php echo $data_web['fanpage']; ?>">
</div>
</div>
<div class="form-group">
<label class="col-xs-12" for="email_admin">Email Admin</label>
<div class="col-xs-12">
<input class="form-control" type="text" id="email_admin" name="email_admin" placeholder="megashopnick@gmail.com" value="<?php echo $data_web['email_admin']; ?>">
</div>
</div>
<div class="form-group">
<label class="col-xs-12" for="phone_admin">Số điện thoại Admin</label>
<div class="col-xs-12">
<input class="form-control" type="text" id="phone_admin" name="phone_admin" placeholder="0984459954" value="<?php echo $data_web['phone_admin']; ?>">
</div>
</div>
<div class="form-group">
<label class="col-xs-12" for="price_atm">Phí rút tiền</label>
<div class="col-xs-12">
<input class="form-control" type="text" id="price_atm" name="price_atm" placeholder="<?php echo $data_web['price_atm']; ?>" value="<?php echo $data_web['price_atm']; ?>">
</div>
</div>
<div class="form-group">
<label class="col-xs-12" for="descr">Mô tả website</label>
<div class="col-xs-12">
<textarea class="form-control" id="descr" name="descr" rows="3" placeholder="Mô tả"><?php echo $data_web['descr']; ?></textarea>
</div>
</div>
<div class="form-group">
<label class="col-xs-12" for="thongbao">Thông báo</label>
<div class="col-xs-12">
<textarea class="form-control" id="thongbao" name="thongbao" rows="3" placeholder="Thông báo"><?php echo $data_web['thongbao']; ?></textarea>
</div>
</div>


<div class="form-group">
<div class="col-xs-12">
        <button class="btn btn-sm btn-success" type="submit">LƯU LẠI</button>
</div>
</div>
</form>
</div>
</div>
</div></div>