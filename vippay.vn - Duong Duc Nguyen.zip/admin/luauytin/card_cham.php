<script>
page = 1;
username="";
seri = "";
pin = "";
</script>
<div id="page-wrapper">
            <div class="container-fluid">
                <div class="row bg-title">
                    <div class="col-lg-3 col-md-4 col-sm-4 col-xs-12">
                        <h4 class="page-title">XỬ LÝ GẠCH THẺ CHẬM</h4>
                    </div>

                </div>

<div class="row">
<div class="col-md-12">
    <div class="white-box">
  
<div class="row" onchange="fitler();">
  <div class="col-lg-3">
    <div class="input-group">
      <input class="form-control" placeholder="Username" id="username" name="username" value="">
    </div>
  </div>
  <div class="col-lg-3">
    <div class="input-group">
      <input class="form-control" placeholder="Số serial" id="seri" name="seri" value="">
    </div>
  </div>
  <div class="col-lg-3">
    <div class="input-group">
      <input type="text" class="form-control" placeholder="Mã thẻ" id="pin" name="pin" value="">
      <span class="input-group-btn">
        <button class="btn btn-default" type="button" onclick="fitler();">Tìm</button>
      </span>
    </div>
  </div>
</div>

<br/>    
   <div class="table-responsive">
                <div style="display: block;" class="list"></div>
            </div>    
    </div>
</div>
</div>
</div></div>
<script>
           function load_list(){
                $(".list").hide();
                $("#loading").show();
                $.post("/assets/ajax/admin/card_cham_list.php", { page : page , username : username , seri : seri , pin : pin})
                .done(function(data) {
                    $(".list").html('');
                    $('.list').empty().append(data);
                    $("#loading").hide();
                    $(".list").show();   
                }); 
            }

            function fitler(){
                username = $("#username").val();
                seri = $("#seri").val();
                pin = $("#pin").val();
                load_list();                                              
            }
load_list();
</script>
<script>
    function status_card(id,status,note) {
            	swal(
            	{
            	  title: "Trường hợp #"+id,
            	  text: "Nội dung xử lý: "+note,
            	  type: "info",
            	  showCancelButton: true,
            	  confirmButtonColor: "#DD6B55",
            	  confirmButtonText: "Continue",
            	  cancelButtonText: "Exit",
            	  closeOnConfirm: false,
            	  showLoaderOnConfirm: true
            	}, function () {
            	  $.post("/assets/ajax/admin/xuly_card_cham.php", {id: id , status : status}, function (data) {
            	    if (data.status == "success") {
                    swal({
            	        title : "Thành công",
            	        type: "success",
            	        text: data.msg
            	      }, function() {
            	        load_list(); 
            	      });	      
            	    } else {
            	      swal({
            	        title : "Có lỗi xảy ra",
            	        type: "error",
            	        text: data.msg
            	      }, function() {
            	        if(data.link) window.location = data.link;
            	      });
            	    }
            	  }, "json");
            	}
            	);
            }
</script>