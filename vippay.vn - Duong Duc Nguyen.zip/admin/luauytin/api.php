<?php
/*
#########################################################
#               Code Edit By LuaUyTin                   #
#              Email: megashopnick@gmail.com            #
#            Phone: 0984.459.954 - 0965.783.736         #
#            Vui Lòng Tôn Trọng Quyền Tác Giả           #
#########################################################
*/
$data = $db->fetch_assoc("SELECT * FROM settings", 1); 
?>


<div id="page-wrapper" style="min-height: 797px;">
            <div class="container-fluid">
                <div class="row bg-title">
                    <div class="col-lg-3 col-md-3 col-xs-12">
                            <h4 class="page-title">THÔNG TIN TÍCH HỢP GACHTHE.VN</h4>
                    </div>
                </div>

<div class="row">
<div class="col-md-12 col-xs-12">
<div class="white-box">   
<form id="settings" novalidate="novalidate">
    <input class="form-control" type="hidden" name="api_gachthe">
    <div class="alert alert-info">Lấy thông tin tich hợp <a href="http://gachthe.vn/Home/Account" style="color:yellow;">tại đây</a>
    <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button></div>
    <div class="form-group">
    <label class="control-label" for="merchant_key"><b>API KEY</b></label>
        <input class="form-control" type="text" id="merchant_key" name="merchant_key" placeholder="API KEY" value="<?php echo $data['merchant_key']; ?>">
    </div>
    <hr/>
    <div class="form-group">
    <label class="control-label sr-only"></label>
    <button type="submit" class="btn btn-success" id="status_save">LƯU LẠI</button>
    </div>

</div>
</div>
</div></div>
