<?php
/*
#########################################################
#               Code Edit By LuaUyTin                   #
#              Email: megashopnick@gmail.com            #
#            Phone: 0984.459.954 - 0965.783.736         #
#            Vui Lòng Tôn Trọng Quyền Tác Giả           #
#########################################################
*/


// bộ đếm người dùng
$user_last_6day = $db->fetch_row("SELECT COUNT(*) FROM accounts WHERE time >= DATE_ADD(CURDATE(), INTERVAL -6 DAY)"); // 6 ngay truoc
$user_today = $db->fetch_row("SELECT COUNT(*) FROM accounts WHERE time >= DATE_ADD(CURDATE(), INTERVAL 0 DAY)"); // hom nay
$user_month = $db->fetch_row("SELECT COUNT(*) FROM accounts WHERE time >= DATE_ADD(CURDATE(), INTERVAL -30 DAY)"); // thang trược
$user_count = $db->fetch_row("SELECT COUNT(*) FROM accounts"); // all


$card_today = $db->fetch_row("SELECT COUNT(*) FROM history_card WHERE status = '1' AND time >= DATE_ADD(CURDATE(), INTERVAL 0 DAY)"); // giao dịch hôm nay
$card_count_cash = $db->fetch_row("SELECT SUM(count_card) FROM history_card WHERE status = '1' AND time >= DATE_ADD(CURDATE(), INTERVAL 0 DAY)"); // hôm nay
$card_count_total = $db->fetch_row("SELECT SUM(count_card) FROM history_card WHERE status = '1'"); // all giao dịch
$card_last_6day = $db->fetch_row("SELECT SUM(count_card) FROM history_card WHERE status = '1' AND time >= DATE_ADD(CURDATE(), INTERVAL -6 DAY)"); // 6 ngay truoc
$card_month = $db->fetch_row("SELECT SUM(count_card) FROM history_card WHERE status = '1' AND time >= DATE_ADD(CURDATE(), INTERVAL -30 DAY)"); // giao dịch tháng trước
$card_total = $db->fetch_row("SELECT COUNT(*) FROM history_card WHERE status = '1'"); // all

?>
<div id="page-wrapper" style="min-height: 797px;">
            <div class="container-fluid">
                <div class="row bg-title">
                    <div class="col-lg-3 col-md-4 col-sm-4 col-xs-12">
                        <h4 class="page-title">THỐNG KÊ WEBSITE</h4>
                    </div>
                </div>
<div class="row">
    
                    <div class="col-lg-4 col-md-6">
                        <div class="white-box text-center">
                            <h3 class="box-title">THÀNH VIÊN</h3>
                                <h1><?php echo $user_today;?></h1>
                                <p class="text-black">Tổng <?php echo $user_count;?> user</p>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6">
                        <div class="white-box text-center bg-purple">
                             <h3 class="box-title" style="color:white;">GẠCH THẺ</h3>
                            <h1 class="text-white counter"><?php echo $card_today;?></h1>
                            <p class="text-white">Tổng thẻ: <?php echo $card_total;?></p>
                        </div>
                    </div>  
                        <div class="col-lg-4 col-md-6">
                         <div class="white-box text-center">
                            <h3 class="box-title">TIỀN NẠP</h3>
                                <h1><?php echo number_format($card_count_cash, 0, '.', '.'); ?> đ</h1>
                            <p class="text-black">Tổng tiền: <?php echo number_format($card_count_total, 0, '.', '.'); ?> đ</p>
                         </div>
                        </div>
</div>

<div class="row">

<div class="col-sm-12 col-md-9">

                        <div class="white-box">   
<h3 class="box-title">NẠP TIỀN</h3>

    <!-- Begin -->
<form id="card-charing" novalidate="novalidate">
    <div class="row">
    <div class="form-group col-md-6">
    <label class="control-label" for="card_type_id">Loại thẻ</label>
        <select name="card_type_id" id="card_type_id" class="form-control">
            <option value="1">Viettel Auto</option>
            <option value="2">Mobiphone Auto</option>
            <option value="3">Vinaphone Auto</option>
            <option value="11">Viettel Chậm</option>
            <option value="12">Mobiphone Chậm</option>
            <option value="13">Vinaphone Chậm</option>
        </select>
    </div>
    <div class="form-group col-md-6">
    <label class="control-label" for="price_guest">Mệnh giá thẻ</label>
        <select name="price_guest" id="price_guest" class="form-control">
            <option value="">- Chọn mệnh giá -</option>
            <option value="10000">10.000</option>
            <option value="20000">20.000</option>
            <option value="30000">30.000</option>
            <option value="50000">50.000</option>
            <option value="100000">100.000</option>
            <option value="200000">200.000</option>
            <option value="300000">300.000</option>
            <option value="500000">500.000</option>
            <option value="1000000">1.000.000</option>
        </select>
    </div>
    </div>

    <div class="form-group">

    <label class="control-label" for="pin">Mã thẻ</label>
    <input type="text" id="pin" value="" name="pin" placeholder="Nhập mã thẻ" autocomplete="off" class="form-control" style="background-image: url(&quot;data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAABHklEQVQ4EaVTO26DQBD1ohQWaS2lg9JybZ+AK7hNwx2oIoVf4UPQ0Lj1FdKktevIpel8AKNUkDcWMxpgSaIEaTVv3sx7uztiTdu2s/98DywOw3Dued4Who/M2aIx5lZV1aEsy0+qiwHELyi+Ytl0PQ69SxAxkWIA4RMRTdNsKE59juMcuZd6xIAFeZ6fGCdJ8kY4y7KAuTRNGd7jyEBXsdOPE3a0QGPsniOnnYMO67LgSQN9T41F2QGrQRRFCwyzoIF2qyBuKKbcOgPXdVeY9rMWgNsjf9ccYesJhk3f5dYT1HX9gR0LLQR30TnjkUEcx2uIuS4RnI+aj6sJR0AM8AaumPaM/rRehyWhXqbFAA9kh3/8/NvHxAYGAsZ/il8IalkCLBfNVAAAAABJRU5ErkJggg==&quot;); background-repeat: no-repeat; background-attachment: scroll; background-size: 16px 18px; background-position: 98% 50%;">

    </div>

    <div class="form-group">

    <label class="control-label" for="serial">Số seri</label>
    <input type="text" id="seri" value="" name="seri" placeholder="Nhập serial thẻ" autocomplete="off" class="form-control">

    </div>


        
    <div class="form-group" id="btn-nap">
    <label class="control-label sr-only"></label>
    <button type="submit" class="btn btn-success btn-block">NẠP TIỀN</button>
    </div>
    </form>

</div>

</div>
<?
require_once '../includes/status_card.php';
?>

</div>
</div></div>