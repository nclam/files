<?php
/*
#########################################################
#               Code By LuaUyTin                        #
#              Email: megashopnick@gmail.com            #
#            Phone: 0984.459.954 - 0965.783.736         #
#            Vui Lòng Tôn Trọng Quyền Tác Giả           #
#########################################################
*/
$data_auto_card_1 = $db->fetch_assoc("SELECT * FROM auto_card WHERE id = '1'", 1);
$data_auto_card_2 = $db->fetch_assoc("SELECT * FROM auto_card WHERE id = '2'", 1);
$data_ck_1= $db->fetch_assoc("SELECT * FROM ck_card WHERE id = '1'", 1);
$data_ck_2= $db->fetch_assoc("SELECT * FROM ck_card WHERE id = '2'", 1);
?>



<div id="page-wrapper" style="min-height: 797px;">
            <div class="container-fluid">
                <div class="row bg-title">
                    <div class="col-lg-3 col-md-4 col-sm-4 col-xs-12">
                        <h4 class="page-title">TRẠNG THÁI THẺ CÀO</h4>
                    </div>
                </div>

<div class="row">
<div class="col-md-12 col-xs-12">
<div class="white-box">   

<h3 class="box-title">TRẠNG THÁI GẠCH AUTO</h3>
<form action="" id="status_card">
    <div class="row">
    <div class="form-group col-md-4 col-xs-12">
    <label class="control-label" for="p1">Viettel</label>
        <select name="p1" id="p1" class="form-control">
            <option value="on" <?php echo ($data_auto_card_1['1'] == 'on') ? 'selected':''; ?>>Hoạt động</option>
            <option value="off" <?php echo ($data_auto_card_1['1'] != 'on') ? 'selected':''; ?>>Bảo trì</option>
        </select>
    </div>
    <div class="form-group col-md-4 col-xs-12">
    <label class="control-label" for="p2">Mobifone</label>
        <select class="form-control" name="p2" id="p2">
            <option value="on" <?php echo ($data_auto_card_1['2'] == 'on') ? 'selected':''; ?>>Hoạt động</option>
            <option value="" <?php echo ($data_auto_card_1['2'] != 'on') ? 'selected':''; ?>>Bảo trì</option>
        </select>
    </div>
    <div class="form-group col-md-4 col-xs-12">
    <label class="control-label" for="p3">Vinaphone</label>
        <select class="form-control" name="p3" id="p3">
            <option value="on" <?php echo ($data_auto_card_1['3'] == 'on') ? 'selected':''; ?>>Hoạt động</option>
            <option value="" <?php echo ($data_auto_card_1['3'] != 'on') ? 'selected':''; ?>>Bảo trì</option>
        </select>
    </div>
<?php /*
    <div class="form-group col-md-4 col-xs-12">
    <label class="control-label" for="p1">Gate</label>
        <select class="form-control" name="p4" id="p4">
            <option value="on" <?php echo ($data_auto_card_1['4'] == 'on') ? 'selected':''; ?>>Hoạt động</option>
            <option value="" <?php echo ($data_auto_card_1['4'] != 'on') ? 'selected':''; ?>>Bảo trì</option>
        </select>
    </div>
    <div class="form-group col-md-4 col-xs-12">
    <label class="control-label" for="p5">Vcoin</label>
        <select class="form-control" name="p5" id="p5">
            <option value="on" <?php echo ($data_auto_card_1['5'] == 'on') ? 'selected':''; ?>>Hoạt động</option>
            <option value="" <?php echo ($data_auto_card_1['5'] != 'on') ? 'selected':''; ?>>Bảo trì</option>
        </select>
    </div>
    <div class="form-group col-md-4 col-xs-12">
    <label class="control-label" for="p7">Zing</label>
        <select class="form-control" name="p7" id="p7">
            <option value="on" <?php echo ($data_auto_card_1['7'] == 'on') ? 'selected':''; ?>>Hoạt động</option>
            <option value="" <?php echo ($data_auto_card_1['7'] != 'on') ? 'selected':''; ?>>Bảo trì</option>
        </select>
    </div>
*/?>
    </div>
<hr/>
<h3 class="box-title">TRẠNG THÁI GẠCH CHẬM</h3>
    <div class="row">
    <div class="form-group col-md-4 col-xs-12">
    <label class="control-label" for="c1">Viettel</label>
        <select class="form-control" name="c1" id="c1">
            <option value="on" <?php echo ($data_auto_card_2['1'] == 'on') ? 'selected':''; ?>>Hoạt động</option>
            <option value="" <?php echo ($data_auto_card_2['1'] != 'on') ? 'selected':''; ?>>Bảo trì</option>
        </select>
    </div>
    <div class="form-group col-md-4 col-xs-12">
    <label class="control-label" for="c2">Mobifone</label>
        <select class="form-control" name="c2" id="c2">
            <option value="on" <?php echo ($data_auto_card_2['2'] == 'on') ? 'selected':''; ?>>Hoạt động</option>
            <option value="" <?php echo ($data_auto_card_2['2'] != 'on') ? 'selected':''; ?>>Bảo trì</option>
        </select>
    </div>
    <div class="form-group col-md-4 col-xs-12">
    <label class="control-label" for="c3">Vinaphone</label>
        <select class="form-control" name="c3" id="c3">
            <option value="on" <?php echo ($data_auto_card_2['3'] == 'on') ? 'selected':''; ?>>Hoạt động</option>
            <option value="" <?php echo ($data_auto_card_2['3'] != 'on') ? 'selected':''; ?>>Bảo trì</option>
        </select>
    </div>
<?php /*
    <div class="form-group col-md-4 col-xs-12">
    <label class="control-label" for="c4">Gate</label>
        <select class="form-control" name="c4" id="c4">
            <option value="on" <?php echo ($data_auto_card_2['4'] == 'on') ? 'selected':''; ?>>Hoạt động</option>
            <option value="" <?php echo ($data_auto_card_2['4'] != 'on') ? 'selected':''; ?>>Bảo trì</option>
        </select>
    </div>
    <div class="form-group col-md-4 col-xs-12">
    <label class="control-label" for="c5">Vcoin</label>
        <select class="form-control" name="c5" id="c5">
            <option value="on" <?php echo ($data_auto_card_2['5'] == 'on') ? 'selected':''; ?>>Hoạt động</option>
            <option value="" <?php echo ($data_auto_card_2['5'] != 'on') ? 'selected':''; ?>>Bảo trì</option>
        </select>
    </div>
    <div class="form-group col-md-4 col-xs-12">
    <label class="control-label" for="c7">Zing</label>
        <select class="form-control" name="c7" id="c7">
            <option value="on" <?php echo ($data_auto_card_2['7'] == 'on') ? 'selected':''; ?>>Hoạt động</option>
            <option value="" <?php echo ($data_auto_card_2['7'] != 'on') ? 'selected':''; ?>>Bảo trì</option>
        </select>
    </div>
*/?>
    </div>
<hr/>
<h3 class="box-title">CHIẾU KHẤU GẠCH AUTO</h3>
    <div class="row">
    <div class="form-group col-md-4 col-xs-12">
    <label class="control-label" for="cka1">Viettel</label>
        <input class="form-control" type="number" id="cka1" name="cka1" placeholder="%" value="<?php echo (100-$data_ck_1['1']); ?>">
    </div>
    <div class="form-group col-md-4 col-xs-12">
    <label class="control-label" for="ck12">Mobifone</label>
        <input class="form-control" type="number" id="cka2" name="cka2" placeholder="%" value="<?php echo (100-$data_ck_1['2']); ?>">
    </div>
    <div class="form-group col-md-4 col-xs-12">
    <label class="control-label" for="cka3">Vinaphone</label>
        <input class="form-control" type="number" id="cka3" name="cka3" placeholder="%" value="<?php echo (100-$data_ck_1['3']); ?>">
    </div>
<?php /*
    <div class="form-group col-md-4 col-xs-12">
    <label class="control-label" for="cka4">Gate</label>
        <input class="form-control" type="number" id="cka4" name="cka4" placeholder="%" value="<?php echo (100-$data_ck_1['4']); ?>">
    </div>
    <div class="form-group col-md-4 col-xs-12">
    <label class="control-label" for="cka5">Vcoin</label>
        <input class="form-control" type="number" id="cka5" name="cka5" placeholder="%" value="<?php echo (100-$data_ck_1['5']); ?>">
    </div>
    <div class="form-group col-md-4 col-xs-12">
    <label class="control-label" for="cka7">Zing</label>
        <input class="form-control" type="number" id="cka7" name="cka7" placeholder="%" value="<?php echo (100-$data_ck_1['7']); ?>">
    </div>
*/?>
    </div>

<hr/>
<h3 class="box-title">CHIẾU KHẤU GẠCH CHẬM</h3>
    <div class="row">
    <div class="form-group col-md-4 col-xs-12">
    <label class="control-label" for="ckc1">Viettel</label>
        <input class="form-control" type="number" id="ckc1" name="ckc1" placeholder="%" value="<?php echo (100-$data_ck_2['1']); ?>">
    </div>
    <div class="form-group col-md-4 col-xs-12">
    <label class="control-label" for="ck12">Mobifone</label>
        <input class="form-control" type="number" id="ckc2" name="ckc2" placeholder="%" value="<?php echo (100-$data_ck_2['2']); ?>">
    </div>
    <div class="form-group col-md-4 col-xs-12">
    <label class="control-label" for="ckc3">Vinaphone</label>
        <input class="form-control" type="number" id="ckc3" name="ckc3" placeholder="%" value="<?php echo (100-$data_ck_2['3']); ?>">
    </div>
<?php /*
    <div class="form-group col-md-4 col-xs-12">
    <label class="control-label" for="ckc4">Gate</label>
        <input class="form-control" type="number" id="ckc4" name="ckc4" placeholder="%" value="<?php echo (100-$data_ck_2['4']); ?>">
    </div>
    <div class="form-group col-md-4 col-xs-12">
    <label class="control-label" for="ckc5">Vcoin</label>
        <input class="form-control" type="number" id="ckc5" name="ckc5" placeholder="%" value="<?php echo (100-$data_ck_2['5']); ?>">
    </div>
    <div class="form-group col-md-4 col-xs-12">
    <label class="control-label" for="ckc7">Zing</label>
        <input class="form-control" type="number" id="ckc7" name="ckc7" placeholder="%" value="<?php echo (100-$data_ck_2['7']); ?>">
    </div>
*/?>
    </div>
    
    <hr/>
    <div class="form-group">
    <label class="control-label sr-only"></label>
    <button type="submit" class="btn btn-success" id="status_save">LƯU LẠI</button>
    </div>
</form>
</div>
</div>
</div>
</div></div>