<?php
/*
#########################################################
#               Code Edit By LuaUyTin                   #
#              Email: megashopnick@gmail.com            #
#            Phone: 0984.459.954 - 0965.783.736         #
#            Vui Lòng Tôn Trọng Quyền Tác Giả           #
#########################################################
*/
//anti_xss
function anti_xss($text) {
      return htmlspecialchars(htmlentities(strip_tags($text), ENT_QUOTES, 'UTF-8'));
}
// $_GET 
function GET($key) {
    return isset($_GET[$key]) ? anti_xss($_GET[$key]) : false; 
}
// $_POST
function POST($key) {
    return isset($_POST[$key]) ? anti_xss($_POST[$key]) : false; 
}
//check card
function luauytin($type,$seri,$pin) {
    $type = $type >= 10 ? $type-10:$type;
    if($type == 1 && strlen($seri) == 11 && strlen($pin) == 13){return true;}
    if($type == 1 && strlen($seri) == 14 && strlen($pin) == 15){return true;}
    if($type == 2 && strlen($seri) == 15 && strlen($pin) == 12){return true;}
    if($type == 3 && strlen($seri) == 14 && strlen($pin) == 12){return true;}
    if($type == 3 && strlen($seri) == 14 && strlen($pin) == 14){return true;}
    return false;
}
// Hàm điều hướng trang
class Redirect {
    public function __construct($url = null) {
        if ($url)
        {
            echo '<script>location.href="'.$url.'";</script>';
        }
    }
}
function time_ago($datetime, $full = false) {
    $now = new DateTime;
    $ago = new DateTime($datetime);
    $diff = $now->diff($ago);

    $diff->w = floor($diff->d / 7);
    $diff->d -= $diff->w * 7;

    $string = array(
        'y' => 'năm',
        'm' => 'tháng',
        'w' => 'tuần',
        'd' => 'ngày',
        'h' => 'giờ',
        'i' => 'phút',
        's' => 'giây',
    );
    foreach ($string as $k => &$v) {
        if ($diff->$k) {
            $v = $diff->$k . ' ' . $v . ($diff->$k > 1 ? '' : '');
        } else {
            unset($string[$k]);
        }
    }

    if (!$full) $string = array_slice($string, 0, 1);
    return $string ? implode(', ', $string) . '' : 'Bây giờ';
}


function time_stamp($time){
    $periods = array("giây", "phút", "giờ", "ngày", "tuần", "tháng", "năm", "thập kỉ");
    $lengths = array("60","60","24","7","4.35","12","10");
    $now = time();
    $difference = $now - $time;
    $tense = "trước";
    for($j = 0; $difference >= $lengths[$j] && $j < count($lengths)-1; $j++) {
       $difference /= $lengths[$j];
    }
   $difference = round($difference);
   return "Cách đây $difference $periods[$j]";
}


// func time ago
function time_elapsed_string($datetime, $full = false) {
    $now = new DateTime;
    $ago = new DateTime($datetime);
    $diff = $now->diff($ago);

    $diff->w = floor($diff->d / 7);
    $diff->d -= $diff->w * 7;

    $string = array(
        'y' => 'năm',
        'm' => 'tháng',
        'w' => 'tuần',
        'd' => 'ngày',
        'h' => 'giờ',
        'i' => 'phút',
        's' => 'giây',
    );
    
    
    foreach ($string as $k => &$v) {
        if ($diff->$k) {
            $v = $diff->$k . ' ' . $v . ($diff->$k > 1 ? '' : '');
        } else {
            unset($string[$k]);
        }
    }

    if (!$full) $string = array_slice($string, 0, 1);
    return $string ? implode(', ', $string) . ' trước' : 'vừa xong';
}
// time left

function time_left($from, $to = '') {
if (empty($to))
$to = time();
$diff = (int) abs($to - $from);
if ($diff <= 60) {
$since = sprintf('Còn vài giây');
} elseif ($diff <= 3600) {
$mins = round($diff / 60);
if ($mins <= 1) {
$mins = 1;
}
/* translators: min=minute */
$since = sprintf('Còn %s phút', $mins);
} else if (($diff <= 86400) && ($diff > 3600)) {
$hours = round($diff / 3600);
if ($hours <= 1) {
$hours = 1;
}
$since = sprintf('Còn %s giờ', $hours);
} elseif ($diff >= 86400) {
$days = round($diff / 86400);
if ($days <= 1) {
$days = 1;
}
$since = sprintf('Còn %s ngày', $days);
}
return $since;
}

function auto_get($url){
    $data = curl_init();
    curl_setopt($data, CURLOPT_HEADER, false);
    curl_setopt($data, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($data, CURLOPT_SSL_VERIFYPEER, 0);
    curl_setopt($data, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
    curl_setopt($data, CURLOPT_CONNECTTIMEOUT, 3);
    curl_setopt($data, CURLOPT_TIMEOUT, 3);
    curl_setopt($data, CURLOPT_HTTPHEADER, array('Accept: application/json'));
    curl_setopt($data, CURLOPT_URL, $url);
    $res = curl_exec($data);
    curl_close($data);
    return $res;
}

function in_array_r($needle, $haystack, $strict = false) {
    foreach ($haystack as $item) {
        if (($strict ? $item === $needle : $item == $needle) || (is_array($item) && in_array_r($needle, $item, $strict))) {
            return true;
        }
    }

    return false;
}
function text($string, $separator = ', '){
    $vals = explode($separator, $string);
    foreach($vals as $key => $val) {
        $vals[$key] = strtolower(trim($val));
    }
    return array_diff($vals, array(""));
}

// Chống xss
class Anti_xss {
      public function clean_up($text) {
      return htmlentities(strip_tags($text), ENT_QUOTES, 'UTF-8');
      }
} 

// Truyền vào
class Input {
    public function input_get($key) {
	return isset($_GET[$key]) ? $_GET[$key] : false; 
    }
    public function input_post($key) {
	return isset($_POST[$key]) ? $_POST[$key] : false; 
    }

}


// lấy thông tin rank và khung 
class Info {

        public function nice_number($n) {
            // first strip any formatting;
            $n = (0+str_replace(",", "", $n));
    
            // is this a number?
            if (!is_numeric($n)) return false;
    
            // now filter it;
            if ($n > 1000000000000) return round(($n/1000000000000), 2).' nghìn tỉ';
            elseif ($n > 1000000000) return round(($n/1000000000), 2).' tỉ';
            elseif ($n > 1000000) return round(($n/1000000), 2).' triệu';
            elseif ($n > 1000) return round(($n/1000), 2).' nghìn';
    
            return number_format($n);
        }
    
        public function get_post($id) {
            $post = glob($_SERVER["DOCUMENT_ROOT"]."/assets/files/post/".$id.".*");
            if ($avatar) {
                $arr = explode("/", $post[0]);
                $last = array_pop($arr);
                return "assets/files/post/".$last;
            } else {
                return get_thumb($id);
            }
        }
    
        public function get_thumb($id) {
        $index = glob($_SERVER["DOCUMENT_ROOT"]."/assets/files/thumb/".$id.".*");
        if ($index) {
            $arr = explode("/", $index[0]);
            $last = array_pop($arr);
            return "assets/files/thumb/".$last;
        } else {
                return "assets/images/banner.jpg";
        }
        }


public function get_string_card($card) {
      switch ($card) {
        case 1:
            $str = "Viettel Auto";
            break;
        case 2:
            $str = "Mobifone Auto";
            break;
        case 3:
            $str = "Vinaphone Auto";
            break;
        case 11:
            $str = "Viettel Chậm";
            break;
        case 12:
            $str = "Mobifone Chậm";
            break;
        case 13:
            $str = "Vinaphone Chậm";
            break;
        default:
            $str = "Chưa Xác Định";
            break;
    }
    return $str;
}
public function get_string_status_card($frame) {
      switch ($frame) {
        case 0:
            $str = "Chờ duyệt...";
            break;
        case 1:
            $str = "Thành công";
            break;
        case 2:
            $str = "Thẻ sai hoặc đã sử dụng";
            break;
        case 3:
            $str = "Không được cộng tiền do khai báo sai mệnh giá";
            break;
        case 4:
            $str = "Bảo trì. Vui lòng nạp lại sau";
            break;
        default:
            $str = "Chưa Xác Định";
            break;
    }
    return $str;
}

public function status_withdra($status_withdra) {
      switch ($status_withdra) {
        case 0:
            $str = "Chờ duyệt...";
            break;
        case 1:
            $str = "Thành công";
            break;
        case 2:
            $str = "Thông tin ngân hàng sai. Hoàn tiền";
            break;
        case 3:
            $str = "Bảo trì. Hoàn tiền";
            break;
        default:
            $str = "Chưa Xác Định";
            break;
    }
    return $str;
}

}

?>