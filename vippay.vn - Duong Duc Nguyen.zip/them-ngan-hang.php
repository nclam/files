<?php
/*
#########################################################
#               Code Edit By LuaUyTin                   #
#              Email: megashopnick@gmail.com            #
#            Phone: 0984.459.954 - 0965.783.736         #
#            Vui Lòng Tôn Trọng Quyền Tác Giả           #
#########################################################
*/
// Require database 
require_once 'core/init.php';

$tieude = "Danh sách ngân hàng";
// Require header
require_once 'includes/header.php';
// Danh sach
require_once 'products/them-ngan-hang.php'; 
// Require footer
require_once 'includes/footer.php';
 
?>