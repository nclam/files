-- phpMyAdmin SQL Dump
-- version 4.7.7
-- https://www.phpmyadmin.net/
--
-- Máy chủ: localhost:3306
-- Thời gian đã tạo: Th7 19, 2019 lúc 11:40 PM
-- Phiên bản máy phục vụ: 10.2.18-MariaDB-log-cll-lve
-- Phiên bản PHP: 5.6.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Cơ sở dữ liệu: `ccxlduzvhosting_vippay`
--

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `accounts`
--

CREATE TABLE `accounts` (
  `id` int(11) NOT NULL,
  `name` text COLLATE utf8_unicode_ci NOT NULL,
  `username` text COLLATE utf8_unicode_ci NOT NULL,
  `password` text COLLATE utf8_unicode_ci NOT NULL,
  `password_lv2` text COLLATE utf8_unicode_ci NOT NULL,
  `cash` int(11) DEFAULT 0,
  `email` text COLLATE utf8_unicode_ci NOT NULL,
  `phone` text COLLATE utf8_unicode_ci NOT NULL,
  `point` int(11) DEFAULT 0,
  `admin` int(11) NOT NULL DEFAULT 0,
  `block` int(11) NOT NULL DEFAULT 0,
  `note` longtext COLLATE utf8_unicode_ci NOT NULL,
  `time` text COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `accounts`
--

INSERT INTO `accounts` (`id`, `name`, `username`, `password`, `password_lv2`, `cash`, `email`, `phone`, `point`, `admin`, `block`, `note`, `time`) VALUES
(1, '0984459954', '0984459954', '550e1bafe077ff0b0b67f4e32f29d751', '', 77000, 'vippay.vn@gmail.com', '0984459954', 0, 100, 0, '', '2019-07-19 20:30:06pm');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `auto_card`
--

CREATE TABLE `auto_card` (
  `id` int(11) NOT NULL,
  `1` text NOT NULL,
  `2` text NOT NULL,
  `3` text NOT NULL,
  `4` text NOT NULL,
  `5` text NOT NULL,
  `7` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Đang đổ dữ liệu cho bảng `auto_card`
--

INSERT INTO `auto_card` (`id`, `1`, `2`, `3`, `4`, `5`, `7`) VALUES
(2, 'on', 'on', 'on', '', '', ''),
(1, 'on', 'on', 'on', '', '', '');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `ck_card`
--

CREATE TABLE `ck_card` (
  `id` int(11) NOT NULL,
  `1` text NOT NULL,
  `2` text NOT NULL,
  `3` text NOT NULL,
  `4` text NOT NULL,
  `5` text NOT NULL,
  `7` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Đang đổ dữ liệu cho bảng `ck_card`
--

INSERT INTO `ck_card` (`id`, `1`, `2`, `3`, `4`, `5`, `7`) VALUES
(1, '70', '65', '62', '0', '0', '0'),
(2, '75', '74', '73', '0', '0', '0');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `data_atm`
--

CREATE TABLE `data_atm` (
  `id` int(11) NOT NULL,
  `username` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `ngan_hang` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `so_tk` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `chu_tk` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `so_the` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `chi_nhanh` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `history_atm`
--

CREATE TABLE `history_atm` (
  `id` int(11) NOT NULL,
  `username` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `cash` int(11) NOT NULL,
  `cash_nhan` int(11) NOT NULL,
  `ngan_hang` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `note` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `status` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `time` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `history_card`
--

CREATE TABLE `history_card` (
  `id` int(11) NOT NULL,
  `request_id` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `username` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `type_card` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `seri` text COLLATE utf8_unicode_ci NOT NULL,
  `pin` text COLLATE utf8_unicode_ci NOT NULL,
  `count_card` int(11) NOT NULL,
  `cash_nhan` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  `notice` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `time` datetime NOT NULL,
  `point` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `history_card`
--

INSERT INTO `history_card` (`id`, `request_id`, `username`, `name`, `type_card`, `seri`, `pin`, `count_card`, `cash_nhan`, `status`, `notice`, `time`, `point`) VALUES
(13, '1563548906980953', '0984459954', '0984459954', '1', '12587690965', '4356432353465', 100000, 70000, 1, NULL, '2019-07-19 22:08:26', 0),
(14, '1563548968733557', '0984459954', '0984459954', '1', '12587690965', '4356432353445', 10000, 7000, 1, NULL, '2019-07-19 22:09:28', 0),
(15, '1563549086605045', '0984459954', '0984459954', '1', '12587690965', '4356432353444', 10000, 7000, 2, NULL, '2019-07-19 22:11:26', 0),
(16, '1563549465598395', '0984459954', '0984459954', '1', '10003917427277', '017447151021498', 20000, 0, 2, 'Duyệt bằng tay', '2019-07-19 22:17:45', 0),
(17, NULL, '0984459954', '0984459954', '11', '43654654654', '1231231231234', 30000, 0, 0, NULL, '2019-07-19 23:13:19', 0),
(18, NULL, '0984459954', '0984459954', '13', '45435436436436', '12312312312312', 100000, 73000, 0, NULL, '2019-07-19 23:14:39', 0);

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `history_transfer`
--

CREATE TABLE `history_transfer` (
  `id` int(11) NOT NULL,
  `user_nhan` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `user_gui` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `cash` int(11) NOT NULL,
  `note` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `time` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `settings`
--

CREATE TABLE `settings` (
  `title` text COLLATE utf8_unicode_ci NOT NULL,
  `descr` text COLLATE utf8_unicode_ci NOT NULL,
  `keywords` text COLLATE utf8_unicode_ci NOT NULL,
  `fanpage` text COLLATE utf8_unicode_ci NOT NULL,
  `fb_admin` text COLLATE utf8_unicode_ci NOT NULL,
  `name_admin` text COLLATE utf8_unicode_ci NOT NULL,
  `phone_admin` text COLLATE utf8_unicode_ci NOT NULL,
  `thongbao` longtext COLLATE utf8_unicode_ci NOT NULL,
  `email_admin` text COLLATE utf8_unicode_ci NOT NULL,
  `merchant_id` text COLLATE utf8_unicode_ci NOT NULL,
  `merchant_key` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `price_atm` int(11) NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `settings`
--

INSERT INTO `settings` (`title`, `descr`, `keywords`, `fanpage`, `fb_admin`, `name_admin`, `phone_admin`, `thongbao`, `email_admin`, `merchant_id`, `merchant_key`, `price_atm`, `status`) VALUES
('VIPPAY.VN - Thu Mua Thẻ Cào Uy Tín', 'LuaUyTin', '', 'LuaUyTin', 'https://facebook.com/luauytin', 'Nguyễn Tuấn Điệp', '0984.459.954', 'Nạp thẻ Viettel sẽ được xử lý nhanh nhất.', 'LuaUyTin', 'LuaUyTin', NULL, 0, 0);

--
-- Chỉ mục cho các bảng đã đổ
--

--
-- Chỉ mục cho bảng `accounts`
--
ALTER TABLE `accounts`
  ADD PRIMARY KEY (`id`);

--
-- Chỉ mục cho bảng `auto_card`
--
ALTER TABLE `auto_card`
  ADD PRIMARY KEY (`id`);

--
-- Chỉ mục cho bảng `ck_card`
--
ALTER TABLE `ck_card`
  ADD PRIMARY KEY (`id`);

--
-- Chỉ mục cho bảng `data_atm`
--
ALTER TABLE `data_atm`
  ADD PRIMARY KEY (`id`);

--
-- Chỉ mục cho bảng `history_atm`
--
ALTER TABLE `history_atm`
  ADD PRIMARY KEY (`id`);

--
-- Chỉ mục cho bảng `history_card`
--
ALTER TABLE `history_card`
  ADD PRIMARY KEY (`id`);

--
-- Chỉ mục cho bảng `history_transfer`
--
ALTER TABLE `history_transfer`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT cho các bảng đã đổ
--

--
-- AUTO_INCREMENT cho bảng `accounts`
--
ALTER TABLE `accounts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT cho bảng `auto_card`
--
ALTER TABLE `auto_card`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT cho bảng `ck_card`
--
ALTER TABLE `ck_card`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT cho bảng `data_atm`
--
ALTER TABLE `data_atm`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT cho bảng `history_atm`
--
ALTER TABLE `history_atm`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT cho bảng `history_card`
--
ALTER TABLE `history_card`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT cho bảng `history_transfer`
--
ALTER TABLE `history_transfer`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
