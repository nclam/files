<?php
/*
#########################################################
#               Code Edit By LuaUyTin                   #
#              Email: megashopnick@gmail.com            #
#            Phone: 0984.459.954 - 0965.783.736         #
#            Vui Lòng Tôn Trọng Quyền Tác Giả           #
#########################################################
*/
 
// Require database & thông tin chung
require_once 'core/init.php';
 
// Xoá session
$session->destroy();
new Redirect($_DOMAIN); // Trở về trang index
 
?>