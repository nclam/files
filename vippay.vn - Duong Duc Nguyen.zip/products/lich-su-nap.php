<script>
page = 1;
seri = "";
</script>
<div id="page-wrapper">
            <div class="container-fluid">
                <div class="row bg-title">
                    <div class="col-lg-3 col-md-4 col-sm-4 col-xs-12">
                        <h4 class="page-title">LỊCH SỦ NẠP THẺ</h4>
                    </div>

                </div>

<div class="row">
<div class="col-md-12">
    <div class="white-box">   
    <h3 class="box-title">LỊCH SỬ NẠP</h3>
<?php if($user){?>    
  <div class="col-lg-4">
    <div class="input-group">
      <input class="form-control" placeholder="Số Serial" id="seri" name="seri" value="">
      <span class="input-group-btn">
        <button class="btn btn-default" type="button" onclick="fitler();">Tìm</button>
      </span>
    </div>
  </div>

<br/>    
<?php }?>   <div class="table-responsive">
                <div style="display: block;" class="list"></div>
            </div>    
    </div>
</div>
</div>
</div></div>
<script>
           function load_list(){
                $(".list").hide();
                $("#loading").show();
                $.post("../assets/ajax/pages/history_card.php", { page : page , seri : seri })
                .done(function(data) {
                    $(".list").html('');
                    $('.list').empty().append(data);
                    $("#loading").hide();
                    $(".list").show();   
                }); 
            }

            function fitler(){
                seri = $("#seri").val();
                load_list();                                                                                                                                          
            }

            
load_list();
</script>