<div id="page-wrapper">
            <div class="container-fluid">
                <div class="row bg-title">
                    <div class="col-lg-3 col-md-4 col-sm-4 col-xs-12">
                        <h4 class="page-title">QUÊN MẬT KHẨU CẤP 2 </h4>
                    </div>
                </div>
<div class="row">
<div class="col-md-12" style="background-color:white;">    
        <div class="col-md-3"></div>
        <form id="lostpass_luauytin" novalidate="novalidate" class="col-md-6">
            <p><center style="font-weight:bold;font-size:25px;color:red;"><?php if($data_user['password_lv2'] != ""){echo "VUI LÒNG CUNG CẤP NHƯNG THÔNG TIN SAU";}else{echo "TÀI KHOẢN CỦA BẠN CHƯA CẬP NHẬT MẬT KHẨU CẤP 2. VUI LÒNG CẬP NHẬT TRƯỚC KHI SỬ DỤNG CHỨC NĂNG NÀY";}?></center></p>
            <?php if($data_user['password_lv2'] != ""){?>
            <div class="form-group">
                <label for="username" class="col-sm-12 control-label">Tài khoản(<font color="red">*</font>):</label>
                <div class="col-sm-12">
                    <input type="text" class="form-control" id="username" name="username" autocomplete="off" placeholder="Tài khoản">
                </div>
            </div>
            <div class="form-group">
                <label class="col-sm-12 control-label" for="phone">Số điện thoại(<font color="red">*</font>):</label>
                <div class="col-sm-12">
                    <input type="text" class="form-control" id="phone" name="phone" autocomplete="off" placeholder="Số điện thoại"> 
                </div>
            </div>
            <div class="form-group">
                <label class="col-sm-12 control-label" for="phone">Email(<font color="red">*</font>):</label>
                <div class="col-sm-12">
                    <input type="email" class="form-control" id="email" name="email" autocomplete="off" placeholder="Email kết nối"> 
                </div>
            </div>
            <input type="hidden" name="pass_lv2">
            <div class="form-group">
                <label class="col-sm-12 control-label" for="submit_lostpass"></label>
                <div class="col-sm-12">
                    <button type="submit" class="btn btn-success btn-block" id="submit_lostpass">GỬI YÊU CẦU</button> 
                </div>
            </div>
            <?php }?>
        </form>
        </div>
</div></div></div>
<script>
      $(document).ready(function () {
      $("#lostpass_luauytin").validate({
          submitHandler: function (e) {
          $('button[id="submit_lostpass"]').html("ĐANG XỬ LÝ...");
          $.post("/assets/ajax/client/quen-mat-khau.php", $('#lostpass_luauytin').serialize(), function(data) {
              $('button[id="submit_lostpass"]').html("GỬI YÊU CẦU");
              swal(data.title, data.msg, data.status);
              setTimeout(function () {
                    window.location.href = data.link;
                    }, 2500);	      
          }, "json");
              return false;
          }
      });
      });
      
</script>
</script>